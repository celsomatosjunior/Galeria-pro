"""Galeria Pro Clínica — organização e impressão de fotografias de exames."""
__version__ = "1.2.0"
APP_NAME = "Galeria Pro Clínica"
APP_ID = "GaleriaProClinica"
