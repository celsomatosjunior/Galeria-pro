"""Exames em disco: pasta por exame, JSON versionado, gravação atômica, rascunho
automático e histórico. Ver docs/FORMATO-EXAME.md.
"""
from __future__ import annotations

import datetime as _dt
import errno
import json
import os
import re
import shutil
import unicodedata
import uuid
from dataclasses import dataclass

from .. import __version__
from . import imageio
from .model import Exam, ImageItem, migrate_v1, new_id, now_iso

FORMAT_NAME = "galeria-pro-clinica/exame"
FORMAT_VERSION = 2
V1_BACKUP_FILE = "exame.formato1-backup.json"   # cópia guardada antes da 1ª gravação no formato 2
EXAM_FILE = "exame.json"
BACKUP_FILE = "exame.anterior.json"
DRAFT_FILE = "rascunho.json"
IMAGES_DIR = "imagens"
IDENTITY_DIR = "identidade"
TRASH_DIR = "_descartados"


class StoreError(Exception):
    """Erro com mensagem já compreensível para o usuário."""


def friendly_oserror(e: OSError, action: str) -> StoreError:
    if e.errno == errno.ENOSPC:
        msg = f"{action}: o disco está cheio. Libere espaço e tente novamente."
    elif e.errno in (errno.EACCES, errno.EPERM) or isinstance(e, PermissionError):
        msg = (f"{action}: sem permissão para gravar em “{e.filename or 'pasta'}”. "
               "Escolha outra pasta em Configurações → Pastas.")
    elif e.errno == errno.ENOENT:
        msg = f"{action}: arquivo ou pasta não encontrado ({e.filename})."
    elif e.errno == errno.EROFS:
        msg = f"{action}: a pasta é somente leitura."
    else:
        msg = f"{action}: {e.strerror or e}"
    return StoreError(msg)


def _fsync_dir(path: str) -> None:
    if os.name == "nt":
        return
    try:
        fd = os.open(path, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    except OSError:
        pass


def atomic_write_json(path: str, data: dict) -> None:
    """Grava em arquivo temporário, força para o disco e substitui (rename atômico)."""
    folder = os.path.dirname(path)
    os.makedirs(folder, exist_ok=True)
    tmp = f"{path}.{uuid.uuid4().hex[:8]}.tmp"
    payload = json.dumps(data, ensure_ascii=False, indent=1).encode("utf-8")
    try:
        with open(tmp, "wb") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
        _fsync_dir(folder)
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def read_json(path: str) -> dict:
    with open(path, "rb") as f:
        return json.loads(f.read().decode("utf-8"))


def slug(name: str, maxlen: int = 40) -> str:
    s = unicodedata.normalize("NFKD", name or "")
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = re.sub(r"[^A-Za-z0-9]+", "-", s).strip("-").upper()
    return (s or "PACIENTE")[:maxlen].rstrip("-")


def wrap_document(exam: Exam) -> dict:
    return {
        "formato": FORMAT_NAME,
        "versao_formato": FORMAT_VERSION,
        "programa": f"Galeria Pro Clínica {__version__}",
        "salvo_em": now_iso(),
        "exame": exam.to_dict(),
    }


def unwrap_document(doc: dict) -> Exam:
    if doc.get("formato") != FORMAT_NAME:
        raise StoreError("O arquivo não é um exame do Galeria Pro Clínica.")
    v = int(doc.get("versao_formato", 0))
    if v > FORMAT_VERSION:
        raise StoreError("Este exame foi salvo por uma versão mais nova do programa. "
                         "Atualize o Galeria Pro Clínica para abri-lo.")
    if v < 1:
        raise StoreError("Versão de formato desconhecida.")
    data = doc["exame"]
    if v == 1:
        data = migrate_v1(data)
    return Exam.from_dict(data)


def doc_version(path: str) -> int:
    try:
        return int(read_json(path).get("versao_formato", 0))
    except Exception:
        return 0


@dataclass
class ExamSummary:
    folder: str
    exam_id: str
    patient: str
    date: str
    images: int
    selected: int
    pages: int
    saved_at: str
    has_draft: bool
    never_saved: bool
    damaged: str = ""

    def date_br(self) -> str:
        try:
            return _dt.date.fromisoformat(self.date).strftime("%d/%m/%Y")
        except ValueError:
            return self.date


class ExamStore:
    def __init__(self, root: str):
        self.root = root

    # ------------------------------------------------------------------ criação
    def new_folder(self, patient: str, date: str) -> str:
        os.makedirs(self.root, exist_ok=True)
        for _ in range(100):
            name = f"{date}_{slug(patient)}_{uuid.uuid4().hex[:6]}"
            path = os.path.join(self.root, name)
            try:
                os.makedirs(path)          # exclusivo: nunca reaproveita uma pasta
                os.makedirs(os.path.join(path, IMAGES_DIR))
                return path
            except FileExistsError:
                continue
        raise StoreError("Não foi possível criar a pasta do exame.")

    def create(self, patient: str, date: str, identity: dict, logo_src: str | None,
               default_template: str = "6") -> tuple[Exam, str]:
        try:
            folder = self.new_folder(patient, date)
            ex = Exam(new_id(), " ".join(patient.split()), date, created_at=now_iso(),
                      default_template=default_template, identity=dict(identity))
            self.apply_identity(ex, folder, identity, logo_src)
            self.autosave(ex, folder)
            return ex, folder
        except OSError as e:
            raise friendly_oserror(e, "Criar o exame") from e

    def apply_identity(self, exam: Exam, folder: str, identity: dict, logo_src: str | None) -> None:
        """Copia a identidade visual (e o arquivo da logo) para dentro do exame."""
        ident = dict(identity)
        ident["logo_arquivo"] = ""
        if logo_src and os.path.isfile(logo_src):
            idir = os.path.join(folder, IDENTITY_DIR)
            os.makedirs(idir, exist_ok=True)
            ext = os.path.splitext(logo_src)[1].lower() or ".png"
            dest = os.path.join(idir, f"logo_{uuid.uuid4().hex[:6]}{ext}")
            shutil.copyfile(logo_src, dest)
            ident["logo_arquivo"] = f"{IDENTITY_DIR}/{os.path.basename(dest)}"
        exam.identity = ident

    @staticmethod
    def logo_path(exam: Exam, folder: str) -> str | None:
        rel = exam.identity.get("logo_arquivo") or ""
        if not rel:
            return None
        p = os.path.join(folder, rel)
        return p if os.path.isfile(p) else None

    # ------------------------------------------------------------------ imagens
    def import_image(self, exam: Exam, folder: str, src: str) -> tuple[ImageItem | None, str]:
        """Copia a imagem para o exame. Retorna (item, motivo). item=None se duplicada
        ou ilegível. Não altera a lista do exame (quem chama acrescenta)."""
        if not imageio.is_supported(src):
            return None, "formato não suportado"
        try:
            sha = imageio.sha256_file(src)
        except OSError as e:
            return None, f"não foi possível ler ({e.strerror or e})"
        if exam.find_by_hash(sha) is not None:
            return None, "já está no exame"
        try:
            w, h = imageio.probe(src)
        except (ValueError, OSError) as e:
            return None, f"imagem ilegível ({e})"
        try:
            dest = imageio.copy_into(src, os.path.join(folder, IMAGES_DIR))
        except OSError as e:
            raise friendly_oserror(e, "Copiar a imagem para o exame") from e
        rel = os.path.relpath(dest, folder).replace(os.sep, "/")
        try:
            cap = _dt.datetime.fromtimestamp(os.path.getmtime(src)).replace(microsecond=0).isoformat()
        except OSError:
            cap = ""
        now = now_iso()
        item = ImageItem(new_id(), rel, os.path.basename(src), sha, w, h,
                         source_path=os.path.abspath(src), imported_at=now, captured_at=cap or now)
        return item, ""

    # ------------------------------------------------------------------ gravação
    def save(self, exam: Exam, folder: str) -> None:
        """Salvamento explícito: exame.json (cópia anterior preservada) e remove o rascunho."""
        exam.modified_at = now_iso()
        path = os.path.join(folder, EXAM_FILE)
        try:
            bk1 = os.path.join(folder, V1_BACKUP_FILE)
            if os.path.isfile(path) and not os.path.exists(bk1) and doc_version(path) == 1:
                shutil.copyfile(path, bk1)   # migração: o arquivo do formato 1 é preservado
            if os.path.isfile(path):
                try:
                    shutil.copyfile(path, os.path.join(folder, BACKUP_FILE))
                except OSError:
                    pass
            atomic_write_json(path, wrap_document(exam))
            d = os.path.join(folder, DRAFT_FILE)
            if os.path.exists(d):
                os.remove(d)
        except OSError as e:
            raise friendly_oserror(e, "Salvar o exame") from e

    def autosave(self, exam: Exam, folder: str) -> None:
        try:
            doc = wrap_document(exam)
            doc["rascunho"] = True
            atomic_write_json(os.path.join(folder, DRAFT_FILE), doc)
        except OSError as e:
            raise friendly_oserror(e, "Salvar automaticamente") from e

    def discard_draft(self, folder: str) -> None:
        try:
            os.remove(os.path.join(folder, DRAFT_FILE))
        except FileNotFoundError:
            pass

    def is_saved(self, folder: str) -> bool:
        return os.path.isfile(os.path.join(folder, EXAM_FILE))

    def has_draft(self, folder: str) -> bool:
        return os.path.isfile(os.path.join(folder, DRAFT_FILE))

    # ------------------------------------------------------------------ leitura
    def load(self, folder: str, prefer_draft: bool = False) -> tuple[Exam, list[str]]:
        """Abre o exame. Tenta exame.json; se corrompido, a cópia anterior; por último o
        rascunho. Retorna (exame, avisos)."""
        notes: list[str] = []
        order = [EXAM_FILE, BACKUP_FILE, DRAFT_FILE]
        if prefer_draft:
            order = [DRAFT_FILE, EXAM_FILE, BACKUP_FILE]
        last_err = None
        for i, name in enumerate(order):
            p = os.path.join(folder, name)
            if not os.path.isfile(p):
                continue
            try:
                ex = unwrap_document(read_json(p))
            except StoreError as e:
                if "versão mais nova" in str(e):
                    raise
                last_err = e
                notes.append(f"{name} inválido: {e}")
                continue
            except (ValueError, KeyError, TypeError, OSError) as e:
                last_err = e
                notes.append(f"{name} danificado")
                continue
            if doc_version(p) == 1:
                notes.append("Exame da versão 1.0 aberto e convertido para o novo formato "
                             "(o arquivo original é guardado como cópia de segurança ao salvar).")
            if name == BACKUP_FILE:
                notes.append("O arquivo do exame estava danificado; foi aberta a cópia anterior.")
            elif name == DRAFT_FILE and not prefer_draft:
                notes.append("Aberto o rascunho automático (o exame ainda não tinha sido salvo).")
            missing = [it.original_name for it in ex.images
                       if not os.path.isfile(os.path.join(folder, it.file))]
            if missing:
                notes.append(f"{len(missing)} imagem(ns) não encontrada(s) na pasta do exame: "
                             + ", ".join(missing[:5]) + ("…" if len(missing) > 5 else ""))
            return ex, notes
        if last_err is not None:
            raise StoreError("O exame está danificado e não pôde ser aberto.")
        raise StoreError("Pasta sem exame do Galeria Pro Clínica.")

    # ------------------------------------------------------------------ histórico
    def list_exams(self) -> list[ExamSummary]:
        out: list[ExamSummary] = []
        if not os.path.isdir(self.root):
            return out
        for name in os.listdir(self.root):
            folder = os.path.join(self.root, name)
            if name.startswith(("_", ".")) or not os.path.isdir(folder):
                continue
            saved = os.path.isfile(os.path.join(folder, EXAM_FILE))
            draft = os.path.isfile(os.path.join(folder, DRAFT_FILE))
            if not saved and not draft:
                continue
            src = EXAM_FILE if saved else DRAFT_FILE
            try:
                doc = read_json(os.path.join(folder, src))
                e = doc["exame"]
                imgs = e.get("imagens", [])
                if int(doc.get("versao_formato", 1)) >= 2:
                    used = len({x for p in e.get("paginas", []) for x in (p.get("posicoes") or []) if x})
                else:
                    used = sum(1 for i in imgs if i.get("selecionada"))
                out.append(ExamSummary(folder, str(e.get("id", "")), str(e.get("paciente", "")),
                                       str(e.get("data_exame", "")), len(imgs), used,
                                       len(e.get("paginas", [])), str(doc.get("salvo_em", "")),
                                       draft, not saved))
            except Exception:
                out.append(ExamSummary(folder, "", name, name[:10], 0, 0, 0, "", draft, not saved,
                                       damaged="danificado"))
        out.sort(key=lambda s: (s.date, s.saved_at), reverse=True)
        return out

    def discard(self, folder: str) -> str:
        """Nunca apaga: move a pasta para _descartados (recuperável manualmente)."""
        dest_root = os.path.join(self.root, TRASH_DIR)
        os.makedirs(dest_root, exist_ok=True)
        dest = os.path.join(dest_root, os.path.basename(folder))
        k = 2
        while os.path.exists(dest):
            dest = os.path.join(dest_root, f"{os.path.basename(folder)}_{k}")
            k += 1
        shutil.move(folder, dest)
        return dest
