"""Composição da impressão: páginas com células explícitas (podem ficar vazias).

Duas ordens independentes:
- GALERIA  = exam.images (fotos disponíveis no exame; pode ser ordenada à vontade);
- IMPRESSÃO = exam.pages[*].slots (quais fotos, em que página e em que célula).

Reordenar a galeria nunca mexe na impressão, e vice-versa. Nenhuma operação daqui perde
foto ou a duplica; lacunas só são fechadas pela ação explícita compact()
("Reorganizar e preencher espaços").
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

from .model import TEMPLATES, Exam, Page, capacity

Cell = tuple[int, int]   # (página, célula)


@dataclass
class Report:
    pages_added: int = 0
    pages_removed: int = 0
    moved: int = 0               # fotos que mudaram de página/posição por efeito colateral
    returned: int = 0            # fotos devolvidas à galeria (fora da impressão)
    messages: list[str] = field(default_factory=list)
    error: str = ""

    def text(self) -> str:
        if self.error:
            return self.error
        parts = list(self.messages)
        if self.moved:
            parts.append(f"{self.moved} foto(s) mudaram de posição")
        if self.pages_added:
            parts.append(f"{self.pages_added} página(s) criada(s)")
        if self.pages_removed:
            parts.append(f"{self.pages_removed} página(s) vazia(s) removida(s)")
        if self.returned:
            parts.append(f"{self.returned} foto(s) voltaram a ficar disponíveis na galeria")
        return "; ".join(parts)


# ============================================================ consultas
def stats(exam: Exam) -> tuple[int, int, int]:
    """(fotos na composição, páginas, células vazias)."""
    return len(exam.sequence()), len(exam.pages), exam.free_cells()


def status_text(exam: Exam) -> str:
    n, p, f = stats(exam)
    return f"{n} foto(s) na composição · {p} página(s) · {f} espaço(s) disponível(is)"


def first_free(exam: Exam, start: Cell = (0, 0)) -> Cell | None:
    for pi in range(start[0], len(exam.pages)):
        s0 = start[1] if pi == start[0] else 0
        for si in range(s0, capacity(exam.pages[pi].template)):
            if not exam.pages[pi].slots[si]:
                return pi, si
    return None


def cell_of(exam: Exam, image_id: str) -> Cell | None:
    return exam.placements().get(image_id)


def classify_drop(exam: Exam, image_id: str, cell: Cell) -> str:
    """O que acontecerá ao soltar `image_id` na célula: colocar | mover | trocar | substituir | nada."""
    pi, si = cell
    if not (0 <= pi < len(exam.pages)) or not (0 <= si < capacity(exam.pages[pi].template)):
        return "nada"
    target = exam.pages[pi].slots[si]
    cur = cell_of(exam, image_id)
    if target == image_id:
        return "nada"
    if not target:
        return "mover" if cur else "colocar"
    return "trocar" if cur else "substituir"


DROP_LABEL = {"colocar": "Colocar aqui", "mover": "Mover para cá", "trocar": "Trocar de lugar",
              "substituir": "Substituir (a atual volta à galeria)", "nada": ""}


# ============================================================ galeria (não toca na impressão)
def _natural(s: str):
    return [int(t) if t.isdigit() else t.casefold() for t in re.split(r"(\d+)", s or "")]


def sort_gallery(exam: Exam, mode: str) -> Report:
    order = {it.id: k for k, it in enumerate(exam.images)}
    if mode == "nome":
        exam.images.sort(key=lambda it: (_natural(it.original_name), order[it.id]))
    elif mode == "captura":
        exam.images.sort(key=lambda it: (it.captured_at or it.imported_at, _natural(it.original_name)))
    elif mode == "importacao":
        exam.images.sort(key=lambda it: (it.imported_at, order[it.id]))
    exam.gallery_sort = mode
    return Report()


def move_images(exam: Exam, ids: list[str], before_index: int) -> Report:
    """Reordena a GALERIA (arrastar miniaturas). A impressão não muda."""
    s = set(ids)
    moving = [it for it in exam.images if it.id in s]
    k = sum(1 for it in exam.images[:max(0, before_index)] if it.id not in s)
    rest = [it for it in exam.images if it.id not in s]
    exam.images = rest[:k] + moving + rest[k:]
    exam.gallery_sort = "personalizada"
    return Report()


# ============================================================ inclusão e retirada
def _new_page(exam: Exam, template: str | None) -> Page:
    t = template if template in TEMPLATES else exam.default_template
    pg = Page(t)
    exam.pages.append(pg)
    return pg


def add_to_composition(exam: Exam, ids: list[str], target: Cell | None = None,
                       template: str | None = None) -> Report:
    """Seleção manual: cada foto ocupa a próxima célula vazia (na ordem das páginas e
    células), começando em `target` se indicado; sem espaço, cria a página seguinte.
    As fotos já posicionadas não se mexem. Fotos já na composição não são repetidas."""
    rep = Report()
    placed: list[Cell] = []
    start = target if target else (0, 0)
    for iid in ids:
        if exam.image(iid) is None or exam.is_used(iid):
            continue
        cell = None
        if target and not exam.pages[target[0]].slots[target[1]]:
            cell = target
            target = None
        if cell is None:
            cell = first_free(exam, start) or first_free(exam)
        if cell is None:
            _new_page(exam, template)
            rep.pages_added += 1
            cell = (len(exam.pages) - 1, 0)
        exam.pages[cell[0]].slots[cell[1]] = iid
        placed.append(cell)
        start = cell
    if 0 < len(placed) <= 3:
        rep.messages.append("Incluída(s) em " + ", ".join(f"P{p + 1} · posição {s + 1}" for p, s in placed))
    elif placed:
        rep.messages.append(f"{len(placed)} foto(s) incluída(s)")
    return rep


def remove_from_composition(exam: Exam, ids: list[str]) -> Report:
    """Retirar da página: a célula fica vazia; as outras fotos não se mexem."""
    s = set(ids)
    for pg in exam.pages:
        for i, x in enumerate(pg.slots):
            if x in s:
                pg.slots[i] = None
    return Report()


def clear_composition(exam: Exam) -> Report:
    n = len(exam.sequence())
    exam.pages = []
    rep = Report()
    if n:
        rep.messages.append(f"{n} foto(s) retiradas da impressão (continuam na galeria)")
    return rep


def place(exam: Exam, image_id: str, cell: Cell) -> Report:
    """Solta a foto numa célula. Vazia: coloca/move. Ocupada: troca (se a foto arrastada já
    está na composição) ou substitui (a anterior volta para a galeria)."""
    rep = Report()
    kind = classify_drop(exam, image_id, cell)
    if kind == "nada":
        return rep
    pi, si = cell
    cur = cell_of(exam, image_id)
    target = exam.pages[pi].slots[si]
    if kind in ("colocar", "mover"):
        if cur:
            exam.pages[cur[0]].slots[cur[1]] = None
        exam.pages[pi].slots[si] = image_id
    elif kind == "trocar":
        exam.pages[cur[0]].slots[cur[1]] = target
        exam.pages[pi].slots[si] = image_id
    else:  # substituir
        exam.pages[pi].slots[si] = image_id
        rep.returned = 1
    return rep


def swap_cells(exam: Exam, a: Cell, b: Cell) -> Report:
    pa, sa = a
    pb, sb = b
    exam.pages[pa].slots[sa], exam.pages[pb].slots[sb] = exam.pages[pb].slots[sb], exam.pages[pa].slots[sa]
    return Report()


def move_to_page(exam: Exam, image_id: str, page_idx: int) -> Report:
    """Move para a primeira célula vazia da página indicada (sem empurrar ninguém)."""
    if not (0 <= page_idx < len(exam.pages)):
        return Report(error="Página inexistente.")
    pg = exam.pages[page_idx]
    for si in range(capacity(pg.template)):
        if not pg.slots[si]:
            return place(exam, image_id, (page_idx, si))
    return Report(error=f"A página {page_idx + 1} não tem célula vazia. Arraste a foto sobre outra "
                        "para trocá-las, ou retire uma foto daquela página.")


def shift(exam: Exam, image_id: str, delta: int) -> Report:
    """Anda uma célula para trás/frente na ordem de leitura (troca com a vizinha)."""
    cur = cell_of(exam, image_id)
    if not cur:
        return Report()
    cells = [(pi, si) for pi, pg in enumerate(exam.pages) for si in range(capacity(pg.template))]
    k = cells.index(cur) + delta
    if not 0 <= k < len(cells):
        return Report()
    return swap_cells(exam, cur, cells[k])


# ============================================================ seleção automática
def auto_select(exam: Exam, gallery_ids: list[str], n: int, template: str, mode: str) -> Report:
    """Selecionar fotos: `n` é o TOTAL desejado na composição.

    mode="refazer": monta do zero com as n primeiras fotos da galeria (ordem visível);
    mode="completar": mantém tudo e acrescenta só o necessário até chegar a n, com fotos
    ainda não usadas, preenchendo primeiro as células vazias.
    Nunca duplica foto nem amplia fotos para ocupar células vazias."""
    assert template in TEMPLATES
    rep = Report()
    n = max(0, int(n))
    exam.default_template = template
    if mode == "refazer" or not exam.pages:
        chosen = [i for i in gallery_ids if exam.image(i) is not None][:n]
        cap = capacity(template)
        npages = math.ceil(len(chosen) / cap) if chosen else 0
        exam.pages = [Page(template) for _ in range(npages)]
        for k, iid in enumerate(chosen):
            exam.pages[k // cap].slots[k % cap] = iid
        rep.messages.append(f"{len(chosen)} foto(s) selecionada(s) em {npages} página(s)")
        if len(chosen) < n:
            rep.messages.append(f"pedido: {n}; só há {len(chosen)} foto(s) na galeria")
        free = exam.free_cells()
        if free:
            rep.messages.append(f"{free} célula(s) vazia(s) para preencher")
        return rep
    have = len(exam.sequence())
    if have >= n:
        rep.messages.append(f"A composição já tem {have} foto(s) (pedido: {n}); nada foi alterado")
        return rep
    need = n - have
    cand = [i for i in gallery_ids if exam.image(i) is not None and not exam.is_used(i)][:need]
    r = add_to_composition(exam, cand, template=template)
    rep.pages_added = r.pages_added
    rep.messages.append(f"{len(cand)} foto(s) acrescentada(s); total {have + len(cand)}")
    if len(cand) < need:
        rep.messages.append(f"pedido: {n}; não há mais fotos disponíveis na galeria")
    return rep


# ============================================================ modelos de página
def _fit(pg: Page, template: str, incoming: list[str] | None = None) -> list[str]:
    """Aplica o modelo à página, recebendo `incoming` no início. Devolve o excedente
    (em ordem). Para caber, elimina primeiro células vazias do fim, depois as do meio."""
    pg.template = template
    cap = capacity(template)
    slots = list(incoming or []) + list(pg.slots)
    while len(slots) > cap and None in slots:
        for k in range(len(slots) - 1, -1, -1):
            if slots[k] is None:
                del slots[k]
                break
    overflow = [x for x in slots[cap:] if x]
    slots = slots[:cap]
    pg.slots = slots + [None] * (cap - len(slots))
    return overflow


def _cascade(exam: Exam, start_page: int, items: list[str], new_template: str, rep: Report) -> None:
    """Coloca `items` no início da página start_page; o que não couber segue adiante.
    Páginas posteriores mantêm seus modelos; páginas novas seguem o modelo da última página
    existente (ou new_template, se não houver páginas)."""
    i = start_page
    while items:
        if i >= len(exam.pages):
            exam.pages.append(Page(exam.pages[-1].template if exam.pages else new_template))
            rep.pages_added += 1
        pg = exam.pages[i]
        before = [x for x in pg.slots if x]
        items = _fit(pg, pg.template, items)
        rep.moved += sum(1 for x in before if x not in pg.slots)
        i += 1


def set_template(exam: Exam, page_idx: int, template: str) -> Report:
    """Muda o modelo só desta página. Se a capacidade diminuir, o excedente vai para o
    início da página seguinte (e assim por diante); nada se perde."""
    assert template in TEMPLATES
    rep = Report()
    if not (0 <= page_idx < len(exam.pages)):
        return rep
    overflow = _fit(exam.pages[page_idx], template)
    if overflow:
        rep.moved += len(overflow)
        _cascade(exam, page_idx + 1, overflow, template, rep)
    exam.default_template = template
    return rep


def set_template_all(exam: Exam, template: str) -> Report:
    """Aplica o modelo a todas as páginas, na ordem, preservando a sequência e as lacunas
    possíveis. Aumentar a capacidade cria células vazias (use Reorganizar para juntar)."""
    assert template in TEMPLATES
    rep = Report()
    carry: list[str] = []
    for pg in exam.pages:
        before = [x for x in pg.slots if x]
        carry = _fit(pg, template, carry)
        rep.moved += sum(1 for x in before if x not in pg.slots)
    while carry:
        pg = Page(template)
        exam.pages.append(pg)
        rep.pages_added += 1
        carry = _fit(pg, template, carry)
    exam.default_template = template
    return rep


def compact(exam: Exam) -> Report:
    """Reorganizar e preencher espaços: fecha as lacunas deslocando as fotos seguintes,
    mantendo a sequência relativa e os modelos; remove páginas que sobrarem vazias."""
    rep = Report()
    seq = [it.id for it in exam.sequence()]
    before = exam.placements()
    k = 0
    for pg in exam.pages:
        cap = capacity(pg.template)
        chunk = seq[k:k + cap]
        k += cap
        pg.slots = chunk + [None] * (cap - len(chunk))
    while exam.pages and not exam.pages[-1].used():
        exam.pages.pop()
        rep.pages_removed += 1
    after = exam.placements()
    rep.moved = sum(1 for x in seq if before.get(x) != after.get(x))
    if not rep.moved and not rep.pages_removed:
        rep.messages.append("Não havia espaços a preencher")
    return rep


# ============================================================ páginas
def add_page(exam: Exam, after_idx: int, template: str | None = None) -> Report:
    t = template if template in TEMPLATES else exam.default_template
    idx = min(max(after_idx + 1, 0), len(exam.pages))
    exam.pages.insert(idx, Page(t))
    return Report()


def delete_page(exam: Exam, idx: int, keep_photos: bool) -> Report:
    """keep_photos=True: as fotos vão para o início da página seguinte (cascata).
    False: voltam para a galeria (ficam disponíveis)."""
    rep = Report()
    if not (0 <= idx < len(exam.pages)):
        return rep
    items = exam.pages[idx].used()
    t = exam.pages[idx].template
    exam.pages.pop(idx)
    if keep_photos and items:
        _cascade(exam, idx, items, t, rep)
    elif items:
        rep.returned = len(items)
    return rep


def move_page(exam: Exam, idx: int, new_idx: int) -> Report:
    n = len(exam.pages)
    if 0 <= idx < n and 0 <= new_idx < n and idx != new_idx:
        exam.pages.insert(new_idx, exam.pages.pop(idx))
    return Report()


def remove_images(exam: Exam, ids: list[str]) -> Report:
    """Remove da galeria DESTE EXAME (e da impressão, deixando a célula vazia).
    O arquivo de origem nunca é apagado."""
    s = set(ids)
    rep = Report()
    for pg in exam.pages:
        for i, x in enumerate(pg.slots):
            if x in s:
                pg.slots[i] = None
    exam.images = [it for it in exam.images if it.id not in s]
    return rep
