"""Desenho de uma página — o MESMO código para prévia, PDF e impressão.

O painter recebe um retângulo-alvo que representa a folha A4 inteira; todo o resto é
calculado em milímetros por core.layout e convertido aqui.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from functools import lru_cache

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QFontMetricsF, QImage, QPainter, QPen

from ..core import layout as L
from ..core.model import Exam, ImageItem

U = 100.0  # unidades lógicas por milímetro (fontes com precisão de 0,01 mm)


@lru_cache(maxsize=64)
def _font(family: str, size_pt: float, bold: bool) -> QFont:
    f = QFont(family)
    f.setPixelSize(max(1, int(round(size_pt * L.PT_TO_MM * U))))
    f.setBold(bold)
    f.setHintingPreference(QFont.HintingPreference.PreferNoHinting)
    f.setKerning(True)
    return f


@lru_cache(maxsize=64)
def _fm(family: str, size_pt: float, bold: bool) -> QFontMetricsF:
    return QFontMetricsF(_font(family, size_pt, bold))


class QtMeasurer:
    def width(self, text: str, family: str, size_pt: float, bold: bool = False) -> float:
        return _fm(family, size_pt, bold).horizontalAdvance(text) / U

    def line_height(self, family: str, size_pt: float) -> float:
        return _fm(family, size_pt, False).lineSpacing() / U


MEASURER = QtMeasurer()


class ImageProvider:
    """Interface: devolve a imagem JÁ editada (rotação+recorte).

    max_px=None → resolução original (PDF/impressão). Senão, uma versão reduzida."""

    def edited(self, item: ImageItem, max_px: int | None) -> QImage | None:  # pragma: no cover
        raise NotImplementedError

    def logo(self) -> QImage | None:  # pragma: no cover
        return None


@dataclass
class Placed:
    image_id: str
    cell: L.Rect
    rect: L.Rect          # área efetivamente ocupada pela foto
    dpi: float
    slot: int = 0         # índice da célula na página (ordem de leitura)


@dataclass
class PageRender:
    geometry: L.PageGeometry
    placed: list[Placed] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    drawn: list[tuple[str, QImage]] = field(default_factory=list)  # ordem de desenho (saídas)


def page_count(exam: Exam) -> int:
    return max(1, len(exam.pages))


def page_geometry(exam: Exam, page_idx: int, logo: QImage | None) -> L.PageGeometry:
    tpl = exam.pages[page_idx].template if page_idx < len(exam.pages) else exam.default_template
    lp = (logo.width(), logo.height()) if logo is not None and not logo.isNull() else None
    return L.compute_geometry(exam.identity, exam.patient, exam.date_br(), tpl,
                              page_idx + 1, page_count(exam), MEASURER, lp)


def plan_page(exam: Exam, page_idx: int, logo: QImage | None) -> PageRender:
    geo = page_geometry(exam, page_idx, logo)
    slots = exam.pages[page_idx].slots if page_idx < len(exam.pages) else []
    pr = PageRender(geo)
    for si, (iid, cell) in enumerate(zip(slots, geo.cells)):
        if not iid:
            continue   # célula vazia: nada é desenhado na saída
        it = exam.image(iid)
        if it is None:
            continue
        w, h = it.edited_size()
        r = L.fit_rect(w, h, cell)
        pr.placed.append(Placed(iid, cell, r, L.effective_dpi(w, r.w), si))
    return pr


def _r(r: L.Rect) -> QRectF:
    return QRectF(r.x * U, r.y * U, r.w * U, r.h * U)


def paint_page(p: QPainter, target: QRectF, exam: Exam, page_idx: int,
               provider: ImageProvider, max_px: int | None = None) -> PageRender:
    """Desenha a página `page_idx` em `target` (retângulo da folha inteira, em coordenadas
    do dispositivo). max_px: limite de resolução das imagens (None = originais)."""
    logo = provider.logo()
    plan = plan_page(exam, page_idx, logo)
    geo = plan.geometry

    p.save()
    p.translate(target.x(), target.y())
    s = target.width() / (geo.page_w * U)
    p.scale(s, s)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)

    p.fillRect(QRectF(0, 0, geo.page_w * U, geo.page_h * U), QColor("#FFFFFF"))

    # logo (com transparência, se houver)
    if logo is not None and not logo.isNull() and geo.logo_zone.w > 0:
        p.drawImage(_r(geo.logo_zone), logo)
        if max_px is None:
            plan.drawn.append(("__logo__", logo))

    # linhas separadoras
    pen = QPen(QColor("#7F8A99"))
    pen.setWidthF(0.25 * U)
    p.setPen(pen)
    for y in geo.sep_lines:
        p.drawLine(QPointF(geo.content.x * U, y * U), QPointF(geo.content.right * U, y * U))

    # identificação
    for run in geo.id_runs:
        f = _font(run.family, run.size_pt, run.bold)
        p.setFont(f)
        p.setPen(QColor(run.color))
        fm = _fm(run.family, run.size_pt, run.bold)
        p.drawText(QPointF(run.x * U, run.baseline_top * U + fm.ascent()), run.text)

    # rodapé e numeração
    content = geo.content
    lines = list(geo.footer_lines) + ([geo.number_line] if geo.number_line else [])
    for ln in lines:
        if not ln.text:
            continue
        f = _font(ln.family, ln.size_pt, False)
        fm = _fm(ln.family, ln.size_pt, False)
        w = fm.horizontalAdvance(ln.text) / U
        if ln.align == "esquerda":
            x = content.x
        elif ln.align == "centro":
            x = content.x + (content.w - w) / 2
        else:
            x = content.right - w
        p.setFont(f)
        p.setPen(QColor(ln.color))
        p.drawText(QPointF(x * U, ln.y * U + fm.ascent()), ln.text)

    # fotos
    for pl in plan.placed:
        it = exam.image(pl.image_id)
        img = provider.edited(it, max_px) if it else None
        if img is None or img.isNull():
            plan.missing.append(pl.image_id)
            p.setPen(QPen(QColor("#C0392B"), 0.4 * U))
            p.setBrush(QColor("#FDEDEC"))
            p.drawRect(_r(pl.cell))
            p.setFont(_font("Arial", 9, True))
            p.drawText(_r(pl.cell), Qt.AlignmentFlag.AlignCenter, "Imagem ausente")
            p.setBrush(Qt.BrushStyle.NoBrush)
            continue
        p.drawImage(_r(pl.rect), img)
        if max_px is None:
            plan.drawn.append((pl.image_id, img))

    p.restore()
    return plan


class FileImageProvider(ImageProvider):
    """Lê as imagens da pasta do exame. Guarda em cache as versões reduzidas (prévia)."""

    def __init__(self, exam_dir: str, logo_path: str | None, cache_limit: int = 160):
        from collections import OrderedDict
        from ..core import imageio
        self._io = imageio
        self.exam_dir = exam_dir
        self.logo_path = logo_path
        self._cache: "OrderedDict[tuple, QImage]" = OrderedDict()
        self._limit = cache_limit
        self._logo: QImage | None = None
        self._logo_loaded_from = None

    def set_logo_path(self, path: str | None) -> None:
        self.logo_path = path
        self._logo = None
        self._logo_loaded_from = None

    def logo(self) -> QImage | None:
        if self._logo_loaded_from != self.logo_path:
            self._logo_loaded_from = self.logo_path
            self._logo = None
            if self.logo_path and os.path.isfile(self.logo_path):
                img = QImage(self.logo_path)
                self._logo = None if img.isNull() else img
        return self._logo

    def path_of(self, item: ImageItem) -> str:
        return os.path.join(self.exam_dir, item.file)

    def invalidate(self, image_id: str | None = None) -> None:
        if image_id is None:
            self._cache.clear()
        else:
            for k in [k for k in self._cache if k[0] == image_id]:
                del self._cache[k]

    def edited(self, item: ImageItem, max_px: int | None) -> QImage | None:
        key = (item.id, item.rotation, item.crop.to_dict().__repr__(), max_px)
        if max_px is not None and key in self._cache:
            self._cache.move_to_end(key)
            return self._cache[key]
        path = self.path_of(item)
        try:
            if max_px is None:
                img = self._io.load_full(path)
            else:
                # carrega com folga para o recorte não perder detalhe na prévia
                factor = 1.0 / max(min(item.crop.w, item.crop.h), 0.05)
                img = self._io.load_scaled(path, int(min(max_px * factor, 8000)))
        except (ValueError, OSError):
            return None
        out = self._io.apply_edits(img, item)
        if max_px is not None:
            self._cache[key] = out
            while len(self._cache) > self._limit:
                self._cache.popitem(last=False)
        return out
