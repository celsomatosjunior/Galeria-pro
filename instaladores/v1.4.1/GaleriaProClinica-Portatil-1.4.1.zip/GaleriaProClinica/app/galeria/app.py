"""Inicialização: log, instância única, tradução, tema e janela principal."""
from __future__ import annotations

import logging
import os
import sys
import traceback

from . import APP_ID, APP_NAME, __version__


def _setup_logging(folder: str) -> str:
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, "galeria.log")
    try:
        if os.path.isfile(path) and os.path.getsize(path) > 2_000_000:
            os.replace(path, path + ".1")
    except OSError:
        pass
    logging.basicConfig(filename=path, level=logging.INFO, encoding="utf-8",
                        format="%(asctime)s %(levelname)s %(message)s")
    logging.info("%s %s iniciando (Python %s)", APP_NAME, __version__, sys.version.split()[0])
    return path


class SingleInstance:
    """Trava de instância única por arquivo (evita dois programas editando o mesmo exame)."""

    def __init__(self, folder: str):
        self.path = os.path.join(folder, "instancia.lock")
        self.fh = None

    def acquire(self) -> bool:
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self.fh = open(self.path, "a+")
        try:
            if os.name == "nt":
                import msvcrt
                self.fh.seek(0)
                msvcrt.locking(self.fh.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except OSError:
            self.fh.close()
            self.fh = None
            return False


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv if argv is None else argv)
    selftest_src = None
    if "--autoteste" in argv:
        i = argv.index("--autoteste")
        selftest_src = os.path.abspath(argv[i + 1] if i + 1 < len(argv) else ".")
        out = os.path.join(selftest_src, "autoteste_saida")
        os.makedirs(out, exist_ok=True)
        os.environ["GALERIA_CONFIG_DIR"] = os.path.join(out, "config")
    from .core.settings import Settings, config_dir

    cfg = config_dir()
    log_path = _setup_logging(cfg)

    from PySide6.QtCore import QLibraryInfo, QLocale, Qt, QTranslator
    from PySide6.QtGui import QFont, QIcon
    from PySide6.QtWidgets import QApplication, QMessageBox

    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(APP_ID)
    app.setApplicationVersion(__version__)
    app.setStyle("Fusion")
    QLocale.setDefault(QLocale(QLocale.Language.Portuguese, QLocale.Country.Brazil))
    tr = QTranslator(app)
    if tr.load("qtbase_pt_BR", QLibraryInfo.path(QLibraryInfo.LibraryPath.TranslationsPath)):
        app.installTranslator(tr)
    icon_path = os.path.join(os.path.dirname(__file__), "resources", "icon.png")
    if os.path.isfile(icon_path):
        app.setWindowIcon(QIcon(icon_path))
    f = QFont("Segoe UI" if os.name == "nt" else app.font().family())
    f.setPointSizeF(9.5)
    app.setFont(f)

    from .ui.theme import QSS
    app.setStyleSheet(QSS)

    lock = SingleInstance(cfg)
    if not lock.acquire():
        QMessageBox.information(None, APP_NAME, f"O {APP_NAME} já está aberto neste computador.")
        return 0

    def excepthook(t, v, tb):
        logging.error("Erro inesperado:\n%s", "".join(traceback.format_exception(t, v, tb)))
        try:
            QMessageBox.critical(None, APP_NAME,
                                 f"Ocorreu um erro inesperado:\n{v}\n\nO trabalho é salvo automaticamente. "
                                 f"Detalhes em:\n{log_path}")
        except Exception:
            pass
    sys.excepthook = excepthook

    settings = Settings(cfg)
    if selftest_src:
        out = os.path.join(selftest_src, "autoteste_saida")
        settings["pasta_exames"] = os.path.join(out, "exames")
        settings["pasta_pdfs"] = out
        settings["abrir_pdf_apos_gerar"] = False
    from .ui.main_window import MainWindow
    win = MainWindow(settings)
    win.show()
    if selftest_src:
        from PySide6.QtCore import QTimer as _T
        from . import selftest

        def _go():
            rc = selftest.run(win, selftest_src, os.path.join(selftest_src, "autoteste_saida"), app)
            logging.info("autoteste terminou: %s", rc)
            win.dirty = False
            win.s.end_session()
            os._exit(rc)
        _T.singleShot(800, _go)
        return app.exec()
    if settings.load_note:
        QMessageBox.warning(win, APP_NAME, settings.load_note)
    from PySide6.QtCore import QTimer
    QTimer.singleShot(200, win.offer_recovery)
    rc = app.exec()
    logging.info("encerrado (código %s)", rc)
    return rc
