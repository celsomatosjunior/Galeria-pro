"""Fidelidade das imagens no PDF.

O QPdfWriter (Qt) sempre recomprime as imagens em JPEG. Depois que a página é desenhada
pela composição única, este módulo troca cada imagem embutida por uma versão sem perda:

- JPEG original sem edição → os BYTES ORIGINAIS do arquivo (DCTDecode, bit a bit);
- demais casos (PNG, BMP, imagem recortada/girada, logo) → pixels exatos em Flate
  (o fluxo IDAT de um PNG gerado na hora, com preditor PNG — sem perda).

A correspondência é feita pela ordem dos comandos "Do" no conteúdo de cada página, que
segue a ordem de desenho, e confirmada pelas dimensões. Se algo não confere, a imagem
original do Qt é mantida e um aviso é devolvido (nunca uma imagem errada).
"""
from __future__ import annotations

import re
import struct
import zlib

from PySide6.QtCore import QBuffer, QByteArray, QIODevice
from PySide6.QtGui import QImage
from pypdf import PdfReader, PdfWriter
from pypdf.generic import ArrayObject, DictionaryObject, NameObject, NumberObject

_DO = re.compile(rb"/([A-Za-z0-9_.\-]+)\s+Do\b")


class Source:
    """O que foi desenhado numa posição: bytes de JPEG original ou um QImage."""

    def __init__(self, image: QImage | None = None, jpeg_bytes: bytes | None = None,
                 jpeg_size: tuple[int, int] | None = None, jpeg_components: int = 3):
        self.image = image
        self.jpeg_bytes = jpeg_bytes
        self.jpeg_size = jpeg_size
        self.jpeg_components = jpeg_components


def jpeg_info(data: bytes) -> tuple[int, int, int, bool] | None:
    """(largura, altura, componentes, adobe) a partir do marcador SOF; None se não for JPEG."""
    if not data.startswith(b"\xff\xd8"):
        return None
    i = 2
    adobe = False
    n = len(data)
    while i + 4 <= n:
        if data[i] != 0xFF:
            i += 1
            continue
        marker = data[i + 1]
        if marker in (0xD8, 0x01) or 0xD0 <= marker <= 0xD7:
            i += 2
            continue
        seglen = struct.unpack(">H", data[i + 2:i + 4])[0]
        if marker == 0xEE:
            adobe = True
        if marker in (0xC0, 0xC1, 0xC2):
            h, w = struct.unpack(">HH", data[i + 5:i + 9])
            comps = data[i + 9]
            return w, h, comps, adobe
        if marker == 0xDA:
            return None
        i += 2 + seglen
    return None


def _png_idat(img: QImage) -> tuple[bytes, int, int, int] | None:
    """Codifica como PNG (sem perda) e devolve (IDAT, cores, largura, altura)."""
    gray = img.isGrayscale()
    conv = img.convertToFormat(QImage.Format.Format_Grayscale8 if gray else QImage.Format.Format_RGB888)
    ba = QByteArray()
    buf = QBuffer(ba)
    buf.open(QIODevice.OpenModeFlag.WriteOnly)
    if not conv.save(buf, "PNG"):
        return None
    data = bytes(ba.data())
    pos = 8
    idat = []
    colortype = bitdepth = interlace = None
    w = h = 0
    while pos + 8 <= len(data):
        ln = struct.unpack(">I", data[pos:pos + 4])[0]
        typ = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + ln]
        if typ == b"IHDR":
            w, h, bitdepth, colortype, _c, _f, interlace = struct.unpack(">IIBBBBB", body)
        elif typ == b"IDAT":
            idat.append(body)
        pos += 12 + ln
    if bitdepth != 8 or interlace != 0 or colortype not in (0, 2):
        return None
    return b"".join(idat), (1 if colortype == 0 else 3), w, h


def _alpha_mask(img: QImage) -> bytes | None:
    if not img.hasAlphaChannel():
        return None
    a = img.convertToFormat(QImage.Format.Format_Alpha8)
    rows = []
    bpl = a.bytesPerLine()
    raw = bytes(a.constBits())
    for y in range(a.height()):
        rows.append(raw[y * bpl:y * bpl + a.width()])
    return zlib.compress(b"".join(rows), 6)


def _set_stream(writer: PdfWriter, xo, data: bytes, filt: str, colors: int, w: int, h: int,
                decode_parms: dict | None) -> None:
    xo[NameObject("/Filter")] = NameObject(filt)
    if decode_parms:
        xo[NameObject("/DecodeParms")] = DictionaryObject(
            {NameObject(k): NumberObject(v) for k, v in decode_parms.items()})
    elif "/DecodeParms" in xo:
        del xo["/DecodeParms"]
    xo[NameObject("/ColorSpace")] = NameObject("/DeviceGray" if colors == 1 else "/DeviceRGB")
    xo[NameObject("/BitsPerComponent")] = NumberObject(8)
    xo[NameObject("/Width")] = NumberObject(w)
    xo[NameObject("/Height")] = NumberObject(h)
    if "/Decode" in xo:
        del xo["/Decode"]
    xo._data = data  # dados já codificados com o filtro indicado
    xo[NameObject("/Length")] = NumberObject(len(data))


def replace_images(path: str, pages_sources: list[list[Source]]) -> list[str]:
    """Substitui as imagens do PDF em `path` (in-place). pages_sources[i] = fontes na
    ordem de desenho da página i. Retorna avisos."""
    warnings: list[str] = []
    reader = PdfReader(path)
    writer = PdfWriter(clone_from=reader)
    done: set = set()
    for pi, page in enumerate(writer.pages):
        if pi >= len(pages_sources):
            break
        sources = pages_sources[pi]
        res = page.get("/Resources")
        res = res.get_object() if res is not None else None
        xobjs = res.get("/XObject") if res is not None else None
        xobjs = xobjs.get_object() if xobjs is not None else {}
        contents = page.get_contents()
        stream = contents.get_data() if contents is not None else b""
        names = [m.group(1).decode() for m in _DO.finditer(stream)]
        # só imagens (formas são ignoradas)
        names = [n for n in names if f"/{n}" in xobjs and
                 xobjs[f"/{n}"].get_object().get("/Subtype") == "/Image"]
        if len(names) != len(sources):
            warnings.append(f"Página {pi + 1}: {len(names)} imagens no PDF, {len(sources)} esperadas; "
                            "mantida a codificação padrão")
            continue
        for name, src in zip(names, sources):
            ref = xobjs.raw_get(f"/{name}")
            key = getattr(ref, "idnum", id(ref))
            if key in done:
                continue
            xo = ref.get_object()
            w = int(xo.get("/Width", 0))
            h = int(xo.get("/Height", 0))
            try:
                if src.jpeg_bytes is not None and src.jpeg_size == (w, h):
                    _set_stream(writer, xo, src.jpeg_bytes, "/DCTDecode", src.jpeg_components, w, h, None)
                elif src.image is not None and (src.image.width(), src.image.height()) == (w, h):
                    enc = _png_idat(src.image)
                    if enc is None:
                        raise ValueError("codificação PNG indisponível")
                    idat, colors, ew, eh = enc
                    _set_stream(writer, xo, idat, "/FlateDecode", colors, ew, eh,
                                {"/Predictor": 15, "/Colors": colors, "/BitsPerComponent": 8, "/Columns": ew})
                    if src.image.hasAlphaChannel() and "/SMask" in xo:
                        mask = _alpha_mask(src.image)
                        sm = xo["/SMask"].get_object()
                        if mask is not None and int(sm.get("/Width", 0)) == ew:
                            sm[NameObject("/Filter")] = NameObject("/FlateDecode")
                            if "/DecodeParms" in sm:
                                del sm["/DecodeParms"]
                            sm._data = mask
                            sm[NameObject("/Length")] = NumberObject(len(mask))
                else:
                    warnings.append(f"Página {pi + 1}: dimensões não conferem ({w}×{h}); "
                                    "mantida a codificação padrão")
                    continue
                done.add(key)
            except Exception as e:  # nunca estraga o PDF: mantém o objeto do Qt
                warnings.append(f"Página {pi + 1}: {e}")
    with open(path, "wb") as f:
        writer.write(f)
    return warnings


_ = ArrayObject  # (reexport silencioso)
