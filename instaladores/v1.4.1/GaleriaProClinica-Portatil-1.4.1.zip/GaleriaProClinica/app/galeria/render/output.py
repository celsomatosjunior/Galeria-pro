"""Saídas: PDF e impressão. Ambas chamam compose.paint_page (mesma composição da prévia)."""
from __future__ import annotations

import os
import re
import unicodedata

from PySide6.QtCore import QMarginsF, QRectF, QSizeF
from PySide6.QtGui import QPageLayout, QPageSize, QPainter, QPdfWriter

from ..core import layout as L
from ..core.model import Exam
from . import compose, pdf_fidelity


def _source_for(exam: Exam, provider, key: str, img) -> "pdf_fidelity.Source":
    """JPEG original sem edição → bytes originais; senão, os pixels desenhados."""
    if key != "__logo__":
        it = exam.image(key)
        path = provider.path_of(it) if (it is not None and hasattr(provider, "path_of")) else None
        if it is not None and path and not it.has_edits() and \
                os.path.splitext(path)[1].lower() in (".jpg", ".jpeg"):
            try:
                with open(path, "rb") as f:
                    data = f.read()
                info = pdf_fidelity.jpeg_info(data)
                if info and info[2] in (1, 3) and not info[3] and (info[0], info[1]) == (img.width(), img.height()):
                    return pdf_fidelity.Source(jpeg_bytes=data, jpeg_size=(info[0], info[1]),
                                               jpeg_components=info[2])
            except OSError:
                pass
    return pdf_fidelity.Source(image=img)

PDF_DPI = 1200          # só define a grade de coordenadas; as imagens entram na resolução original
_INVALID = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}


def safe_filename(name: str, maxlen: int = 80) -> str:
    """Nome de arquivo válido no Windows, sem acentos problemáticos para outros sistemas."""
    s = unicodedata.normalize("NFKD", name or "")
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = _INVALID.sub(" ", s)
    s = re.sub(r"\s+", " ", s).strip().strip(".")
    s = s.replace(" ", "_")
    if not s:
        s = "Paciente"
    if s.upper() in _RESERVED:
        s = "_" + s
    return s[:maxlen]


def suggested_pdf_name(exam: Exam) -> str:
    return f"{safe_filename(exam.patient)}_{exam.date}.pdf"


def a4_layout() -> QPageLayout:
    return QPageLayout(QPageSize(QPageSize.PageSizeId.A4), QPageLayout.Orientation.Portrait,
                       QMarginsF(0, 0, 0, 0), QPageLayout.Unit.Millimeter)


def export_pdf(exam: Exam, provider: compose.ImageProvider, path: str,
               pages: list[int] | None = None, progress=None) -> list[str]:
    """Gera o PDF. Escreve num arquivo temporário e só então substitui o destino.
    Retorna avisos (ex.: imagens ausentes). Lança OSError em falha de gravação."""
    n = compose.page_count(exam)
    idx = [i for i in (pages if pages is not None else range(n)) if 0 <= i < n]
    if not idx:
        raise ValueError("Nenhuma página para exportar.")
    folder = os.path.dirname(os.path.abspath(path)) or "."
    os.makedirs(folder, exist_ok=True)
    tmp = path + ".gerando.pdf"
    warnings: list[str] = []
    w = QPdfWriter(tmp)
    w.setResolution(PDF_DPI)
    w.setPageLayout(a4_layout())
    w.setTitle(f"{exam.patient} — {exam.date_br()}")
    w.setCreator("Galeria Pro Clínica")
    p = QPainter()
    if not p.begin(w):
        raise OSError(f"Não foi possível criar o arquivo PDF em {folder}.")
    sources: list[list[pdf_fidelity.Source]] = []
    try:
        full = QRectF(0, 0, w.width(), w.height())
        for k, i in enumerate(idx):
            if k:
                w.newPage()
            plan = compose.paint_page(p, full, exam, i, provider, None)
            sources.append([_source_for(exam, provider, key, img) for key, img in plan.drawn])
            if plan.missing:
                warnings.append(f"Página {i + 1}: {len(plan.missing)} imagem(ns) ausente(s)")
            if progress:
                progress(k + 1, len(idx) + 1)
    finally:
        p.end()
    del w
    if not os.path.isfile(tmp) or os.path.getsize(tmp) < 100:
        raise OSError("O PDF não foi gravado (disco cheio ou sem permissão?).")
    try:
        fw = pdf_fidelity.replace_images(tmp, sources)
    except OSError:
        os.remove(tmp)
        raise
    if fw:  # imagens mantidas na codificação do Qt: registra, mas o PDF é válido
        warnings.append("Algumas imagens ficaram com compressão padrão: " + "; ".join(fw[:3]))
    if progress:
        progress(len(idx) + 1, len(idx) + 1)
    try:
        os.replace(tmp, path)
    except PermissionError:
        os.remove(tmp)
        raise PermissionError("O PDF de destino está aberto em outro programa ou a pasta não "
                              "permite gravação. Feche o arquivo e tente novamente.")
    return warnings


def print_target(paper: QRectF, printable: QRectF, identity: dict) -> tuple[QRectF, float]:
    """Retângulo (no papel) onde a folha A4 inteira é desenhada.

    Normalmente é o próprio papel (escala 1). Se a área imprimível da impressora não contém
    o conteúdo (área dentro das margens configuradas), a folha é reduzida proporcionalmente
    e centralizada na área imprimível — o cabeçalho e o rodapé nunca são cortados."""
    dpmm_x = paper.width() / L.A4_W_MM
    dpmm_y = paper.height() / L.A4_H_MM
    ident = L.sanitize_identity(identity)
    need = QRectF(paper.x() + ident["margem_esq_mm"] * dpmm_x, paper.y() + ident["margem_sup_mm"] * dpmm_y,
                  (L.A4_W_MM - ident["margem_esq_mm"] - ident["margem_dir_mm"]) * dpmm_x,
                  (L.A4_H_MM - ident["margem_sup_mm"] - ident["margem_inf_mm"]) * dpmm_y)
    if printable.contains(need):
        return QRectF(paper), 1.0
    s = min(printable.width() / need.width(), printable.height() / need.height(), 1.0)
    # conteúdo escalado, centralizado na área imprimível
    cx = printable.center().x() - (need.center().x() - paper.x()) * s
    cy = printable.center().y() - (need.center().y() - paper.y()) * s
    return QRectF(cx, cy, paper.width() * s, paper.height() * s), s


def print_pages(exam: Exam, provider: compose.ImageProvider, printer, pages: list[int],
                copies: int = 1) -> list[str]:
    """Imprime com a mesma composição. A folha A4 é mapeada no papel inteiro; se a
    impressora não alcançar as margens configuradas, a página é reduzida de forma
    proporcional e centralizada — nada do cabeçalho/rodapé é cortado."""
    from PySide6.QtPrintSupport import QPrinter

    warnings: list[str] = []
    printer.setFullPage(True)
    printer.setPageLayout(a4_layout())
    printer.setCopyCount(1)  # cópias feitas aqui, por documento inteiro (agrupadas)
    paper = printer.paperRect(QPrinter.Unit.DevicePixel)
    printable = printer.pageRect(QPrinter.Unit.DevicePixel)
    target, scale = print_target(paper, printable, exam.identity)
    if scale < 0.999:
        warnings.append(f"A impressora não alcança as margens configuradas; a página foi "
                        f"reduzida para {scale * 100:.0f}% para não cortar nada.")
    p = QPainter()
    if not p.begin(printer):
        raise OSError("Não foi possível iniciar a impressão.")
    try:
        first = True
        for _c in range(max(1, copies)):
            for i in pages:
                if not first:
                    printer.newPage()
                first = False
                plan = compose.paint_page(p, target, exam, i, provider, None)
                if plan.missing:
                    warnings.append(f"Página {i + 1}: {len(plan.missing)} imagem(ns) ausente(s)")
    finally:
        p.end()
    return warnings
