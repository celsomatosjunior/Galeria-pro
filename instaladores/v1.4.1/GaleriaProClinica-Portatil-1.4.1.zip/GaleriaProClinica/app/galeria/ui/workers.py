"""Tarefas em segundo plano: importação de imagens e geração de PDF."""
from __future__ import annotations

import os

from PySide6.QtCore import QThread, Signal

from ..core import imageio
from ..core.model import Exam
from ..core.store import ExamStore, StoreError


def expand_paths(paths: list[str], max_depth: int = 3) -> list[str]:
    """Arquivos de imagem a partir de arquivos e pastas (pastas: inclui subpastas)."""
    out: list[str] = []
    seen = set()
    for p in paths:
        if os.path.isdir(p):
            base_depth = p.rstrip(os.sep).count(os.sep)
            for dp, dn, fn in os.walk(p):
                if dp.count(os.sep) - base_depth >= max_depth:
                    dn[:] = []
                dn[:] = sorted(d for d in dn if not d.startswith((".", "_")))
                for f in sorted(fn):
                    full = os.path.join(dp, f)
                    if imageio.is_supported(f) and full not in seen:
                        seen.add(full)
                        out.append(full)
        elif os.path.isfile(p) and imageio.is_supported(p) and p not in seen:
            seen.add(p)
            out.append(p)
    return out


class ImportWorker(QThread):
    item_ready = Signal(object, bool)        # ImageItem, veio do acompanhamento
    progress = Signal(int, int)
    finished_report = Signal(dict)

    def __init__(self, store: ExamStore, exam: Exam, folder: str, paths: list[str],
                 from_watch: bool = False, parent=None):
        super().__init__(parent)
        self.store = store
        # cópia leve só para a verificação de duplicatas
        self.hashes = {it.sha256 for it in exam.images}
        self.shadow = Exam(exam.id, exam.patient, exam.date)
        self.folder = folder
        self.paths = paths
        self.from_watch = from_watch
        self._cancel = False

    def cancel(self) -> None:
        self._cancel = True

    def run(self) -> None:
        rep = {"importadas": 0, "duplicadas": 0, "falhas": [], "erro": ""}
        files = expand_paths(self.paths)
        total = len(files)
        for k, src in enumerate(files):
            if self._cancel:
                break
            self.progress.emit(k, total)
            try:
                self.shadow.images = []
                it, why = self._import_one(src)
            except StoreError as e:
                rep["erro"] = str(e)
                break
            if it is None:
                if why == "já está no exame":
                    rep["duplicadas"] += 1
                else:
                    rep["falhas"].append(f"{os.path.basename(src)}: {why}")
                continue
            self.hashes.add(it.sha256)
            rep["importadas"] += 1
            self.item_ready.emit(it, self.from_watch)
        self.progress.emit(total, total)
        rep["total"] = total
        self.finished_report.emit(rep)

    def _import_one(self, src: str):
        try:
            sha = imageio.sha256_file(src)
        except OSError as e:
            return None, f"não foi possível ler ({e.strerror or e})"
        if sha in self.hashes:
            return None, "já está no exame"
        return self.store.import_image(self.shadow, self.folder, src)


class PdfWorker(QThread):
    done = Signal(list, str)          # avisos, erro
    progress = Signal(int, int)

    def __init__(self, exam: Exam, folder: str, logo: str | None, path: str, pages: list[int], parent=None):
        super().__init__(parent)
        self.exam = Exam.from_dict(exam.to_dict())   # cópia independente
        self.folder = folder
        self.logo = logo
        self.path = path
        self.pages = pages

    def run(self) -> None:
        from ..render import compose, output
        prov = compose.FileImageProvider(self.folder, self.logo)
        try:
            w = output.export_pdf(self.exam, prov, self.path, self.pages,
                                  progress=lambda a, b: self.progress.emit(a, b))
            self.done.emit(w, "")
        except Exception as e:  # mensagem compreensível
            msg = str(e)
            if isinstance(e, OSError) and getattr(e, "errno", None) == 28:
                msg = "Disco cheio: não foi possível gravar o PDF."
            self.done.emit([], msg or "Falha ao gerar o PDF.")
