"""Configurações: identidade da clínica, rodapé, página e impressão, pastas.

À direita, uma prévia ao vivo da folha com fotos de exemplo (cinzas).
"""
from __future__ import annotations

import copy
import os

from PySide6.QtCore import QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPixmap
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox,
                               QFileDialog, QFontComboBox, QFormLayout, QHBoxLayout, QLabel,
                               QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QSpinBox,
                               QTabWidget, QVBoxLayout, QWidget)

from ..core import layout as L
from ..core.model import TEMPLATES, TEMPLATE_LABEL, Exam, ImageItem, Page, new_id
from ..render import compose

ALIGN = [("esquerda", "Esquerda"), ("centro", "Centro"), ("direita", "Direita")]


class _SampleProvider(compose.ImageProvider):
    def __init__(self, logo_path: str | None):
        self._logo = QImage(logo_path) if logo_path else None
        if self._logo is not None and self._logo.isNull():
            self._logo = None
        self._img = QImage(400, 300, QImage.Format.Format_RGB32)
        self._img.fill(QColor("#3A3F47"))
        p = QPainter(self._img)
        p.setPen(QColor("#9AA3AF"))
        p.drawEllipse(110, 60, 180, 180)
        p.end()

    def logo(self):
        return self._logo

    def edited(self, item, max_px):
        return self._img


def sample_exam(ident: dict, template: str) -> Exam:
    ex = Exam(new_id(), "NOME DO PACIENTE DE EXEMPLO", "2026-10-20", identity=ident,
              default_template=template)
    from ..core.model import capacity
    for _ in range(capacity(template)):
        ex.images.append(ImageItem(new_id(), "", "", "", 400, 300))
    ex.pages = [Page(template, [it.id for it in ex.images])]
    return ex


def _dspin(lo, hi, step=0.5, dec=1, suffix=" mm") -> QDoubleSpinBox:
    s = QDoubleSpinBox()
    s.setRange(lo, hi)
    s.setSingleStep(step)
    s.setDecimals(dec)
    s.setSuffix(suffix)
    return s


def _combo(items) -> QComboBox:
    c = QComboBox()
    for k, v in items:
        c.addItem(v, k)
    return c


def _set_combo(c: QComboBox, key) -> None:
    i = c.findData(key)
    c.setCurrentIndex(max(0, i))


class SettingsDialog(QDialog):
    def __init__(self, settings, parent=None, start_tab: int = 0):
        super().__init__(parent)
        self.setWindowTitle("Configurações")
        self.resize(1040, 680)
        self.s = settings
        self.ident = settings.identity()
        self.logo = settings.logo_file()
        self.new_logo_src: str | None = None
        self.logo_removed = False

        root = QHBoxLayout(self)
        left = QVBoxLayout()
        root.addLayout(left, 3)
        self.tabs = QTabWidget()
        left.addWidget(self.tabs, 1)
        self.tabs.addTab(self._tab_identity(), "Identidade da clínica")
        self.tabs.addTab(self._tab_footer(), "Rodapé")
        self.tabs.addTab(self._tab_page(), "Página e impressão")
        self.tabs.addTab(self._tab_folders(), "Pastas")
        self.tabs.setCurrentIndex(start_tab)
        self.warn = QLabel("")
        self.warn.setObjectName("warn")
        self.warn.setWordWrap(True)
        left.addWidget(self.warn)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.button(QDialogButtonBox.StandardButton.Ok).setText("Salvar configurações")
        bb.button(QDialogButtonBox.StandardButton.Ok).setObjectName("primary")
        bb.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        bb.accepted.connect(self._accept)
        bb.rejected.connect(self.reject)
        left.addWidget(bb)

        right = QVBoxLayout()
        root.addLayout(right, 2)
        t = QLabel("Prévia da folha")
        t.setObjectName("panelTitle")
        right.addWidget(t)
        self.prev_tpl = _combo([(k, TEMPLATE_LABEL[k]) for k in TEMPLATES])
        _set_combo(self.prev_tpl, settings["modelo_inicial"])
        right.addWidget(self.prev_tpl)
        self.preview = QLabel()
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setStyleSheet("background:#7B8594;border-radius:6px;")
        self.preview.setMinimumSize(300, 420)
        right.addWidget(self.preview, 1)
        self.prev_tpl.currentIndexChanged.connect(self._schedule)

        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(120)
        self._timer.timeout.connect(self._render)
        self._load()
        self._connect_all()
        self._render()

    # ------------------------------------------------------------ abas
    def _tab_identity(self) -> QWidget:
        w = QWidget()
        f = QFormLayout(w)
        row = QHBoxLayout()
        self.logo_lbl = QLabel()
        self.logo_lbl.setFixedSize(180, 70)
        self.logo_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.logo_lbl.setStyleSheet("background:#fff;border:1px dashed #AAB4C3;border-radius:6px;")
        b1 = QPushButton("Escolher logo…")
        b2 = QPushButton("Remover logo")
        b1.clicked.connect(self._pick_logo)
        b2.clicked.connect(self._remove_logo)
        col = QVBoxLayout()
        col.addWidget(b1)
        col.addWidget(b2)
        row.addWidget(self.logo_lbl)
        row.addLayout(col)
        row.addStretch(1)
        f.addRow("Logo (PNG ou JPEG):", row)
        hint = QLabel("PNG com fundo transparente é respeitado. A logo é copiada para o programa; "
                      "o arquivo escolhido não é alterado.")
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        f.addRow("", hint)
        self.e_header = _dspin(*L.LIMITS["cabecalho_altura_mm"])
        self.e_logo_h = _dspin(*L.LIMITS["logo_altura_mm"])
        self.e_logo_w = QSpinBox()
        self.e_logo_w.setRange(*[int(x) for x in L.LIMITS["logo_largura_max_pct"]])
        self.e_logo_w.setSuffix(" % da largura")
        self.e_logo_al = _combo(ALIGN)
        self.e_dx = _dspin(*L.LIMITS["logo_deslocamento_mm"])
        self.e_dy = _dspin(*L.LIMITS["logo_deslocamento_mm"])
        self.e_id_pt = _dspin(*L.LIMITS["id_tamanho_pt"], step=0.5, suffix=" pt")
        self.e_id_font = QFontComboBox()
        f.addRow("Altura do cabeçalho:", self.e_header)
        f.addRow("Altura máxima da logo:", self.e_logo_h)
        f.addRow("Largura máxima da logo:", self.e_logo_w)
        f.addRow("Posição da logo:", self.e_logo_al)
        f.addRow("Ajuste horizontal:", self.e_dx)
        f.addRow("Ajuste vertical:", self.e_dy)
        f.addRow("Fonte da identificação:", self.e_id_font)
        f.addRow("Tamanho (Paciente/Data):", self.e_id_pt)
        return w

    def _tab_footer(self) -> QWidget:
        w = QWidget()
        f = QFormLayout(w)
        self.e_ft = QPlainTextEdit()
        self.e_ft.setPlaceholderText("Ex.: endereço, telefone, responsável técnico…\n(pode ter várias linhas)")
        self.e_ft.setMinimumHeight(110)
        self.e_ff = QFontComboBox()
        self.e_fpt = _dspin(*L.LIMITS["rodape_tamanho_pt"], step=0.5, suffix=" pt")
        self.e_fal = _combo(ALIGN)
        self.e_num = QCheckBox("Mostrar “Página X de Y”")
        self.e_npos = _combo(ALIGN)
        self.e_npt = _dspin(*L.LIMITS["numeracao_tamanho_pt"], step=0.5, suffix=" pt")
        f.addRow("Texto do rodapé:", self.e_ft)
        f.addRow("Fonte:", self.e_ff)
        f.addRow("Tamanho:", self.e_fpt)
        f.addRow("Alinhamento:", self.e_fal)
        f.addRow("Numeração:", self.e_num)
        f.addRow("Posição da numeração:", self.e_npos)
        f.addRow("Tamanho da numeração:", self.e_npt)
        return w

    def _tab_page(self) -> QWidget:
        w = QWidget()
        f = QFormLayout(w)
        lo, hi = L.LIMITS["margem"]
        self.e_mt, self.e_mb, self.e_ml, self.e_mr = (_dspin(lo, hi) for _ in range(4))
        self.e_gap = _dspin(*L.LIMITS["espacamento"])
        self.e_lines = QCheckBox("Linhas separadoras no cabeçalho")
        self.e_tpl = _combo([(k, TEMPLATE_LABEL[k]) for k in TEMPLATES])
        self.e_printer = QComboBox()
        self.e_printer.addItem("Padrão do Windows", "")
        try:
            from PySide6.QtPrintSupport import QPrinterInfo
            for n in QPrinterInfo.availablePrinterNames():
                self.e_printer.addItem(n, n)
        except Exception:
            pass
        f.addRow("Papel:", QLabel("A4 retrato (210 × 297 mm)"))
        f.addRow("Margem superior:", self.e_mt)
        f.addRow("Margem inferior:", self.e_mb)
        f.addRow("Margem esquerda:", self.e_ml)
        f.addRow("Margem direita:", self.e_mr)
        f.addRow("Espaço entre fotos:", self.e_gap)
        f.addRow("", self.e_lines)
        f.addRow("Modelo inicial:", self.e_tpl)
        f.addRow("Impressora preferida:", self.e_printer)
        hint = QLabel("Se a impressora não alcançar uma margem pequena, a folha é reduzida "
                      "proporcionalmente na impressão para nada ser cortado (o programa avisa).")
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        f.addRow("", hint)
        return w

    def _tab_folders(self) -> QWidget:
        w = QWidget()
        f = QFormLayout(w)
        self.e_cap = self._folder_row(f, "Pasta de capturas (Capture Pro):")
        self.e_exams = self._folder_row(f, "Pasta dos exames:")
        self.e_pdfs = self._folder_row(f, "Pasta padrão para PDFs:")
        self.e_openpdf = QCheckBox("Abrir o PDF depois de gerar")
        f.addRow("", self.e_openpdf)
        hint = QLabel("Cada exame fica numa pasta própria, com cópia das fotos utilizadas. "
                      "Mudar a pasta dos exames não move exames antigos.")
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        f.addRow("", hint)
        return w

    def _folder_row(self, form: QFormLayout, label: str) -> QLineEdit:
        row = QHBoxLayout()
        e = QLineEdit()
        b = QPushButton("Escolher…")
        b.clicked.connect(lambda: self._browse(e))
        row.addWidget(e, 1)
        row.addWidget(b)
        form.addRow(label, row)
        return e

    def _browse(self, e: QLineEdit) -> None:
        d = QFileDialog.getExistingDirectory(self, "Escolher pasta", e.text() or os.path.expanduser("~"))
        if d:
            e.setText(os.path.normpath(d))

    # ------------------------------------------------------------ dados
    def _load(self) -> None:
        d = self.ident
        self.e_header.setValue(d["cabecalho_altura_mm"])
        self.e_logo_h.setValue(d["logo_altura_mm"])
        self.e_logo_w.setValue(int(d["logo_largura_max_pct"]))
        _set_combo(self.e_logo_al, d["logo_alinhamento"])
        self.e_dx.setValue(d["logo_deslocamento_x_mm"])
        self.e_dy.setValue(d["logo_deslocamento_y_mm"])
        self.e_id_font.setCurrentFont(QFont(d["id_fonte"]))
        self.e_id_pt.setValue(d["id_tamanho_pt"])
        self.e_ft.setPlainText(d.get("rodape_texto", ""))
        self.e_ff.setCurrentFont(QFont(d["rodape_fonte"]))
        self.e_fpt.setValue(d["rodape_tamanho_pt"])
        _set_combo(self.e_fal, d["rodape_alinhamento"])
        self.e_num.setChecked(bool(d["numeracao"]))
        _set_combo(self.e_npos, d["numeracao_posicao"])
        self.e_npt.setValue(d["numeracao_tamanho_pt"])
        self.e_mt.setValue(d["margem_sup_mm"])
        self.e_mb.setValue(d["margem_inf_mm"])
        self.e_ml.setValue(d["margem_esq_mm"])
        self.e_mr.setValue(d["margem_dir_mm"])
        self.e_gap.setValue(d["espacamento_mm"])
        self.e_lines.setChecked(bool(d.get("linhas_separadoras", True)))
        _set_combo(self.e_tpl, self.s["modelo_inicial"])
        _set_combo(self.e_printer, self.s.get("impressora", ""))
        self.e_cap.setText(self.s["pasta_capturas"])
        self.e_exams.setText(self.s["pasta_exames"])
        self.e_pdfs.setText(self.s["pasta_pdfs"])
        self.e_openpdf.setChecked(bool(self.s.get("abrir_pdf_apos_gerar", True)))
        self._logo_thumb()

    def _connect_all(self) -> None:
        for wdg in (self.e_header, self.e_logo_h, self.e_logo_w, self.e_dx, self.e_dy, self.e_id_pt,
                    self.e_fpt, self.e_npt, self.e_mt, self.e_mb, self.e_ml, self.e_mr, self.e_gap):
            wdg.valueChanged.connect(self._schedule)
        for c in (self.e_logo_al, self.e_fal, self.e_npos):
            c.currentIndexChanged.connect(self._schedule)
        self.e_id_font.currentFontChanged.connect(self._schedule)
        self.e_ff.currentFontChanged.connect(self._schedule)
        self.e_ft.textChanged.connect(self._schedule)
        self.e_num.toggled.connect(self._schedule)
        self.e_lines.toggled.connect(self._schedule)

    def collect(self) -> dict:
        d = copy.deepcopy(self.ident)
        d.update({
            "cabecalho_altura_mm": self.e_header.value(), "logo_altura_mm": self.e_logo_h.value(),
            "logo_largura_max_pct": self.e_logo_w.value(), "logo_alinhamento": self.e_logo_al.currentData(),
            "logo_deslocamento_x_mm": self.e_dx.value(), "logo_deslocamento_y_mm": self.e_dy.value(),
            "id_fonte": self.e_id_font.currentFont().family(), "id_tamanho_pt": self.e_id_pt.value(),
            "rodape_texto": self.e_ft.toPlainText(), "rodape_fonte": self.e_ff.currentFont().family(),
            "rodape_tamanho_pt": self.e_fpt.value(), "rodape_alinhamento": self.e_fal.currentData(),
            "numeracao": self.e_num.isChecked(), "numeracao_posicao": self.e_npos.currentData(),
            "numeracao_tamanho_pt": self.e_npt.value(),
            "margem_sup_mm": self.e_mt.value(), "margem_inf_mm": self.e_mb.value(),
            "margem_esq_mm": self.e_ml.value(), "margem_dir_mm": self.e_mr.value(),
            "espacamento_mm": self.e_gap.value(), "linhas_separadoras": self.e_lines.isChecked(),
        })
        return L.sanitize_identity(d)

    def _current_logo(self) -> str | None:
        if self.new_logo_src:
            return self.new_logo_src
        if self.logo_removed:
            return None
        return self.logo

    def _logo_thumb(self) -> None:
        p = self._current_logo()
        img = QImage(p) if p else QImage()
        if img.isNull():
            self.logo_lbl.setText("sem logo")
            self.logo_lbl.setPixmap(QPixmap())
        else:
            self.logo_lbl.setPixmap(QPixmap.fromImage(img).scaled(
                170, 62, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def _pick_logo(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Escolher logo da clínica", os.path.expanduser("~"),
                                              "Imagens (*.png *.jpg *.jpeg)")
        if not path:
            return
        img = QImage(path)
        if img.isNull():
            QMessageBox.warning(self, "Logo", "Não foi possível ler esta imagem.")
            return
        self.new_logo_src = path
        self.logo_removed = False
        self._logo_thumb()
        self._schedule()

    def _remove_logo(self) -> None:
        self.new_logo_src = None
        self.logo_removed = True
        self._logo_thumb()
        self._schedule()

    def _schedule(self, *_):
        self._timer.start()

    def _render(self) -> None:
        d = self.collect()
        tpl = self.prev_tpl.currentData()
        ex = sample_exam(d, tpl)
        prov = _SampleProvider(self._current_logo())
        geo = compose.page_geometry(ex, 0, prov.logo())
        self.warn.setText(" ".join(geo.warnings))
        h = max(300, self.preview.height() - 16)
        w = int(h * L.A4_W_MM / L.A4_H_MM)
        dpr = self.devicePixelRatioF()
        img = QImage(int(w * dpr), int(h * dpr), QImage.Format.Format_RGB32)
        p = QPainter(img)
        compose.paint_page(p, QRectF(0, 0, img.width(), img.height()), ex, 0, prov, 600)
        p.end()
        img.setDevicePixelRatio(dpr)
        self.preview.setPixmap(QPixmap.fromImage(img))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._schedule()

    def _accept(self) -> None:
        d = self.collect()
        geo = compose.page_geometry(sample_exam(d, "12"), 0, None)
        if geo.warnings:
            QMessageBox.warning(self, "Configurações", " ".join(geo.warnings))
            return
        for e, label in ((self.e_exams, "dos exames"), (self.e_pdfs, "dos PDFs")):
            path = e.text().strip()
            if not path:
                QMessageBox.warning(self, "Pastas", f"Informe a pasta {label}.")
                return
            try:
                os.makedirs(path, exist_ok=True)
                probe = os.path.join(path, ".teste_gravacao")
                with open(probe, "w") as fh:
                    fh.write("ok")
                os.remove(probe)
            except OSError as ex:
                QMessageBox.warning(self, "Pastas", f"Sem permissão para gravar na pasta {label}:\n{path}\n\n{ex}")
                return
        if self.new_logo_src:
            try:
                self.s["logo_padrao"] = self.s.store_logo(self.new_logo_src)
            except OSError as ex:
                QMessageBox.warning(self, "Logo", f"Não foi possível copiar a logo: {ex}")
                return
        elif self.logo_removed:
            self.s["logo_padrao"] = ""
        self.s["identidade"] = d
        self.s["modelo_inicial"] = self.e_tpl.currentData()
        self.s["impressora"] = self.e_printer.currentData() or ""
        self.s["pasta_capturas"] = self.e_cap.text().strip()
        self.s["pasta_exames"] = self.e_exams.text().strip()
        self.s["pasta_pdfs"] = self.e_pdfs.text().strip()
        self.s["abrir_pdf_apos_gerar"] = self.e_openpdf.isChecked()
        try:
            self.s.save()
        except OSError as ex:
            QMessageBox.warning(self, "Configurações", f"Não foi possível salvar as configurações: {ex}")
            return
        self.accept()
