"""Prévia das folhas (mesma composição do PDF/impressão) com interação por arrastar.

Destaques de seleção, células vazias e avisos são desenhados POR CIMA da imagem da
página — nunca entram no PDF nem na impressão.
"""
from __future__ import annotations

import json

from PySide6.QtCore import QByteArray, QMimeData, QPoint, QPointF, QRect, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QDrag, QFont, QImage, QPainter, QPen, QPixmap
from PySide6.QtWidgets import QApplication, QScrollArea, QWidget

from ..core import layout as L
from ..core import composition as C
from ..core.model import Exam
from ..render import compose
from . import icons
from .gallery import MIME_IDS

MIME_CELL = "application/x-galeria-celula"   # ocorrência arrastada da prévia: "página,célula"
from .theme import ACCENT, WARN

GAP = 18
MARGIN = 22


class PreviewCanvas(QWidget):
    """Folhas da composição. Uma célula (vazia ou ocupada) pode ser selecionada com o clique."""
    cell_selected = Signal(int, int, str)          # página, célula, id ('' = vazia)
    page_clicked = Signal(int)
    drop_requested = Signal(list, int, int)        # ids (da galeria), página, célula
    cell_drop_requested = Signal(int, int, int, int)  # origem (página, célula) → destino
    open_requested = Signal(str)
    context_requested = Signal(str, int, int, QPoint)  # id ('' = vazia/página), página, célula (-1), posição
    delete_requested = Signal(list)                # [(página, célula)] — só aquelas ocorrências

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("previewCanvas")
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, False)
        self.setMouseTracking(True)
        self.setAcceptDrops(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.exam: Exam | None = None
        self.provider: compose.ImageProvider | None = None
        self.scale = 2.0                     # pixels (lógicos) por mm
        self.current_page = 0
        self.selected_cell: tuple[int, int] | None = None
        self._hover: tuple[int, int] | None = None   # (página, célula)
        self._drop: tuple[int, int] | None = None
        self._drop_label = ""
        self._cache: dict[int, tuple[str, QImage]] = {}
        self._plans: dict[int, tuple[str, compose.PageRender]] = {}
        self._press: QPoint | None = None
        self._press_id = ""
        self.empty_text = "Use “Selecionar fotos” ou clique nas fotos da galeria"

    @property
    def selected_id(self) -> str:
        if not self.exam or not self.selected_cell:
            return ""
        pi, si = self.selected_cell
        if pi < len(self.exam.pages) and si < len(self.exam.pages[pi].slots):
            return self.exam.pages[pi].slots[si] or ""
        return ""

    def selected_empty_cell(self) -> tuple[int, int] | None:
        if self.selected_cell and not self.selected_id and self.exam and \
                self.selected_cell[0] < len(self.exam.pages):
            return self.selected_cell
        return None

    def select_cell(self, cell: tuple[int, int] | None) -> None:
        self.selected_cell = cell
        self.update()

    # ------------------------------------------------------------ dados
    def set_exam(self, exam: Exam | None, provider) -> None:
        self.exam = exam
        self.provider = provider
        self.selected_cell = None
        self.invalidate()

    def invalidate(self) -> None:
        self._cache.clear()
        self._plans.clear()
        if self.exam and self.selected_cell:
            pi, si = self.selected_cell
            if pi >= len(self.exam.pages):
                self.selected_cell = None
        self._relayout()
        self.update()

    def n_pages(self) -> int:
        return compose.page_count(self.exam) if self.exam else 0

    def page_px(self) -> tuple[int, int]:
        return int(round(L.A4_W_MM * self.scale)), int(round(L.A4_H_MM * self.scale))

    def page_rect(self, i: int) -> QRect:
        pw, ph = self.page_px()
        x = max(MARGIN, (self.width() - pw) // 2)
        return QRect(x, MARGIN + i * (ph + GAP), pw, ph)

    def _relayout(self) -> None:
        pw, ph = self.page_px()
        n = max(1, self.n_pages())
        self.setMinimumSize(pw + 2 * MARGIN, n * (ph + GAP) - GAP + 2 * MARGIN)
        self.resize(max(self.parentWidget().width() if self.parentWidget() else 0, pw + 2 * MARGIN),
                    n * (ph + GAP) - GAP + 2 * MARGIN)

    def set_scale(self, s: float) -> None:
        s = max(0.6, min(12.0, s))
        if abs(s - self.scale) < 1e-3:
            return
        self.scale = s
        self._cache.clear()
        self._relayout()
        self.update()

    # ------------------------------------------------------------ assinatura (cache)
    def _sig(self, i: int) -> str:
        ex = self.exam
        slots = ex.pages[i].slots if i < len(ex.pages) else []
        imgs = []
        for iid in slots:
            it = ex.image(iid) if iid else None
            imgs.append((iid, it.rotation, it.crop.to_dict()) if it else None)
        tpl = ex.pages[i].template if i < len(ex.pages) else ex.default_template
        return json.dumps([ex.patient, ex.date, tpl, imgs, ex.identity, self.n_pages(),
                           getattr(self.provider, "logo_path", None)], sort_keys=True, default=str)

    def plan(self, i: int) -> compose.PageRender:
        sig = self._sig(i)
        c = self._plans.get(i)
        if c and c[0] == sig:
            return c[1]
        pr = compose.plan_page(self.exam, i, self.provider.logo() if self.provider else None)
        self._plans[i] = (sig, pr)
        return pr

    def _render(self, i: int) -> QImage:
        sig = self._sig(i) + f"|{self.scale:.4f}|{self.devicePixelRatioF():.2f}"
        c = self._cache.get(i)
        if c and c[0] == sig:
            return c[1]
        dpr = self.devicePixelRatioF()
        pw, ph = self.page_px()
        img = QImage(int(pw * dpr), int(ph * dpr), QImage.Format.Format_RGB32)
        img.fill(QColor("#FFFFFF"))
        p = QPainter(img)
        # resolução das fotos na prévia: suficiente para a escala atual (nítido e rápido)
        max_px = max(320, int(pw * dpr * 1.05))
        compose.paint_page(p, QRectF(0, 0, img.width(), img.height()), self.exam, i, self.provider, max_px)
        p.end()
        img.setDevicePixelRatio(dpr)
        self._cache[i] = (sig, img)
        return img

    # ------------------------------------------------------------ geometria
    def _mm_to_px(self, i: int, r: L.Rect) -> QRectF:
        pr = self.page_rect(i)
        return QRectF(pr.x() + r.x * self.scale, pr.y() + r.y * self.scale, r.w * self.scale, r.h * self.scale)

    def cell_rect(self, i: int, ci: int) -> QRectF:
        return self._mm_to_px(i, self.plan(i).geometry.cells[ci])

    def hit(self, pos: QPoint) -> tuple[int, int, str]:
        """(página, célula, id da foto) sob o ponto; -1 quando não há.
        Só páginas reais da composição têm células selecionáveis."""
        if not self.exam or not self.exam.pages:
            return -1, -1, ""
        n = len(self.exam.pages)
        pw, ph = self.page_px()
        i = (pos.y() - MARGIN + GAP // 2) // (ph + GAP)
        if i < 0 or i >= n or not self.page_rect(i).adjusted(-8, -GAP // 2, 8, GAP // 2).contains(pos):
            return -1, -1, ""
        plan = self.plan(i)
        slots = self.exam.pages[i].slots
        for ci, cell in enumerate(plan.geometry.cells):
            if self._mm_to_px(i, cell).contains(QPointF(pos)):
                return i, ci, (slots[ci] or "") if ci < len(slots) else ""
        return i, -1, ""

    def page_at_viewport_center(self, vp_top: int, vp_h: int) -> int:
        pw, ph = self.page_px()
        c = vp_top + vp_h // 2
        return max(0, min(self.n_pages() - 1, (c - MARGIN) // (ph + GAP)))

    # ------------------------------------------------------------ desenho
    def paintEvent(self, e):
        p = QPainter(self)
        p.fillRect(e.rect(), QColor("#7B8594"))
        if not self.exam:
            p.setPen(QColor("#F2F4F7"))
            f = QFont(self.font())
            f.setPointSizeF(12)
            p.setFont(f)
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter,
                       "Nenhum exame aberto\n\nClique em “Novo exame” (Ctrl+N) ou “Abrir exame” (Ctrl+O)")
            return
        n = self.n_pages()
        for i in range(n):
            pr = self.page_rect(i)
            if not pr.adjusted(-6, -6, 6, 6).intersects(e.rect()):
                continue
            p.fillRect(pr.translated(3, 4), QColor(0, 0, 0, 60))   # sombra
            p.drawImage(pr, self._render(i))
            self._overlay(p, i, pr)
        p.end()

    def _overlay(self, p: QPainter, i: int, pr: QRect) -> None:
        """Somente na tela: células vazias, seleção, destino do arraste, avisos."""
        plan = self.plan(i)
        real = i < len(self.exam.pages)
        p.save()
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        if real and i == self.current_page and len(self.exam.pages) > 1:
            p.setPen(QPen(QColor(ACCENT), 2.5))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(QRectF(pr).adjusted(-2, -2, 2, 2))
        f = QFont(self.font())
        f.setPointSizeF(8.5)
        p.setFont(f)
        occupied = {pl.slot for pl in plan.placed}
        dash = QPen(QColor("#9AA6B6"), 1.2, Qt.PenStyle.DashLine)
        for ci, cell in enumerate(plan.geometry.cells):
            if ci in occupied:
                continue
            r = self._mm_to_px(i, cell).adjusted(1, 1, -1, -1)
            p.setPen(dash)
            p.setBrush(QColor(240, 244, 249, 160) if real else Qt.BrushStyle.NoBrush)
            p.drawRect(r)
            if real and r.height() > 30:
                p.setPen(QColor("#7D8899"))
                p.drawText(r, Qt.AlignmentFlag.AlignCenter, f"vazia\nposição {ci + 1}")
        if not self.exam.sequence() and i == 0:
            body = self._mm_to_px(i, plan.geometry.body)
            fm = p.fontMetrics()
            tw = fm.horizontalAdvance(self.empty_text) + 28
            box = QRectF(body.center().x() - tw / 2, body.center().y() - 18, tw, 36)
            p.setPen(QPen(QColor("#C9D3E0"), 1))
            p.setBrush(QColor("#F4F7FB"))
            p.drawRoundedRect(box, 8, 8)
            p.setPen(QColor("#4D5B6E"))
            p.drawText(box, Qt.AlignmentFlag.AlignCenter, self.empty_text)
        # numeração das posições de impressão (só na tela): nº de ordem de leitura, por CÉLULA
        # (a mesma foto usada 3 vezes recebe 3 números)
        order = {}
        if real:
            n0 = sum(len(pg.used()) for pg in self.exam.pages[:i])
            for si, x in enumerate(self.exam.pages[i].slots):
                if x:
                    n0 += 1
                    order[si] = n0
        fb = QFont(self.font())
        fb.setBold(True)
        fb.setPointSizeF(9)
        for pl in plan.placed:
            rr = self._mm_to_px(i, pl.rect)
            n = order.get(pl.slot)
            if n and rr.width() > 40:
                p.setFont(fb)
                txt = str(n)
                bw = max(22, p.fontMetrics().horizontalAdvance(txt) + 12)
                badge = QRectF(rr.left() + 4, rr.top() + 4, bw, 22)
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QColor(26, 115, 232, 225))
                p.drawRoundedRect(badge, 11, 11)
                p.setPen(QColor("#FFFFFF"))
                p.drawText(badge, Qt.AlignmentFlag.AlignCenter, txt)
                p.setFont(f)
            if pl.dpi and pl.dpi < L.LOW_DPI:
                icon_r = QRectF(rr.right() - 22, rr.top() + 4, 18, 18)
                p.setBrush(QColor(255, 255, 255, 220))
                p.setPen(Qt.PenStyle.NoPen)
                p.drawEllipse(icon_r.adjusted(-3, -3, 3, 3))
                p.drawPixmap(icon_r.toRect(), icons.pixmap("warn", 18, WARN))
        # seleção de célula
        if self.selected_cell and self.selected_cell[0] == i and self.selected_cell[1] < len(plan.geometry.cells):
            r = self._mm_to_px(i, plan.geometry.cells[self.selected_cell[1]])
            p.setPen(QPen(QColor(ACCENT), 3))
            p.setBrush(QColor(31, 95, 173, 30) if not self.selected_id else Qt.BrushStyle.NoBrush)
            p.drawRect(r.adjusted(-1.5, -1.5, 1.5, 1.5))
        # passar o mouse
        if self._hover and self._hover[0] == i and 0 <= self._hover[1] < len(plan.geometry.cells) \
                and self._hover != self.selected_cell and not self._drop:
            r = self._mm_to_px(i, plan.geometry.cells[self._hover[1]])
            p.setPen(QPen(QColor(31, 95, 173, 110), 1.5))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(r.adjusted(1, 1, -1, -1))
        # destino do arraste, com o que vai acontecer
        if self._drop and self._drop[0] == i and 0 <= self._drop[1] < len(plan.geometry.cells):
            r = self._mm_to_px(i, plan.geometry.cells[self._drop[1]])
            p.setPen(QPen(QColor(ACCENT), 3))
            p.setBrush(QColor(31, 95, 173, 45))
            p.drawRect(r.adjusted(1, 1, -1, -1))
            if self._drop_label:
                f2 = QFont(self.font())
                f2.setBold(True)
                f2.setPointSizeF(9)
                p.setFont(f2)
                tw = p.fontMetrics().horizontalAdvance(self._drop_label) + 18
                box = QRectF(r.center().x() - tw / 2, r.center().y() - 13, tw, 26)
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QColor(ACCENT))
                p.drawRoundedRect(box, 6, 6)
                p.setPen(QColor("#FFFFFF"))
                p.drawText(box, Qt.AlignmentFlag.AlignCenter, self._drop_label)
        p.restore()

    # ------------------------------------------------------------ mouse
    def mousePressEvent(self, e):
        self.setFocus()
        pg, ci, iid = self.hit(e.position().toPoint())
        if e.button() == Qt.MouseButton.LeftButton:
            self._press = e.position().toPoint()
            self._press_id = iid
            self._press_cell = (pg, ci)
            if pg >= 0:
                self.current_page = pg
                self.page_clicked.emit(pg)
            if ci >= 0:
                self.selected_cell = (pg, ci)
                self.cell_selected.emit(pg, ci, iid)
            self.update()
        elif e.button() == Qt.MouseButton.RightButton and pg >= 0:
            self.current_page = pg
            self.page_clicked.emit(pg)
            if ci >= 0:
                self.selected_cell = (pg, ci)
                self.cell_selected.emit(pg, ci, iid)
            self.update()
            self.context_requested.emit(iid, pg, ci, e.globalPosition().toPoint())

    def mouseMoveEvent(self, e):
        pos = e.position().toPoint()
        if self._press is not None and self._press_id and \
                (pos - self._press).manhattanLength() >= QApplication.startDragDistance():
            iid = self._press_id
            self._press = None
            md = QMimeData()
            pc = self._press_cell
            md.setData(MIME_CELL, QByteArray(f"{pc[0]},{pc[1]},{iid}".encode()))
            drag = QDrag(self)
            drag.setMimeData(md)
            it = self.exam.image(iid)
            if it and self.provider:
                img = self.provider.edited(it, 160)
                if img is not None:
                    pm = QPixmap.fromImage(img).scaled(120, 100, Qt.AspectRatioMode.KeepAspectRatio,
                                                       Qt.TransformationMode.SmoothTransformation)
                    drag.setPixmap(pm)
                    drag.setHotSpot(QPoint(pm.width() // 2, pm.height() // 2))
            drag.exec(Qt.DropAction.MoveAction)
            return
        pg, ci, _ = self.hit(pos)
        h = (pg, ci) if pg >= 0 and ci >= 0 else None
        if h != self._hover:
            self._hover = h
            self.update()

    def mouseReleaseEvent(self, e):
        self._press = None

    def leaveEvent(self, e):
        self._hover = None
        self.update()

    def mouseDoubleClickEvent(self, e):
        _pg, _ci, iid = self.hit(e.position().toPoint())
        if iid:
            self.open_requested.emit(iid)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Delete and self.selected_id:
            self.delete_requested.emit([tuple(self.selected_cell)])
            return
        if e.key() == Qt.Key.Key_Escape and self.selected_cell:
            self.selected_cell = None
            self.cell_selected.emit(-1, -1, "")
            self.update()
            return
        super().keyPressEvent(e)

    # ------------------------------------------------------------ soltar
    def _ids(self, md) -> list[str]:
        if md.hasFormat(MIME_CELL):
            return [self._src(md)[2]]
        return [x for x in bytes(md.data(MIME_IDS)).decode().split("\n") if x]

    @staticmethod
    def _src(md):
        try:
            a, b, iid = bytes(md.data(MIME_CELL)).decode().split(",", 2)
            return int(a), int(b), iid
        except Exception:
            return -1, -1, ""

    def dragEnterEvent(self, e):
        md = e.mimeData()
        if (md.hasFormat(MIME_IDS) or md.hasFormat(MIME_CELL)) and self.exam and self.exam.pages:
            e.acceptProposedAction()
        else:
            e.ignore()

    def dragMoveEvent(self, e):
        pg, ci, _ = self.hit(e.position().toPoint())
        ids = self._ids(e.mimeData())
        if pg >= 0 and ci >= 0 and ids:
            self._drop = (pg, ci)
            src = None
            if e.mimeData().hasFormat(MIME_CELL):
                a, b, _ = self._src(e.mimeData())
                src = (a, b)
            if len(ids) == 1:
                kind = C.classify_drop(self.exam, ids[0], (pg, ci), src)
                self._drop_label = C.DROP_LABEL.get(kind, "")
            else:
                self._drop_label = f"Colocar {len(ids)} fotos a partir daqui"
            self.update()
            e.acceptProposedAction()
        else:
            self._drop = None
            self._drop_label = ""
            self.update()
            e.ignore()

    def dragLeaveEvent(self, e):
        self._drop = None
        self._drop_label = ""
        self.update()

    def dropEvent(self, e):
        self._drop = None
        self._drop_label = ""
        self.update()
        ids = self._ids(e.mimeData())
        pg, ci, _target = self.hit(e.position().toPoint())
        if pg < 0 or ci < 0 or not ids:
            return
        e.acceptProposedAction()
        if e.mimeData().hasFormat(MIME_CELL):
            a, b, _ = self._src(e.mimeData())
            self.cell_drop_requested.emit(a, b, pg, ci)
        else:
            self.drop_requested.emit(ids, pg, ci)


def n_pages_gt1(c: PreviewCanvas) -> bool:
    return c.n_pages() > 1


class PreviewArea(QScrollArea):
    """Área rolável com modos de ajuste (página, largura, percentual)."""
    zoom_changed = Signal(int)
    current_page_changed = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("previewArea")
        self.canvas = PreviewCanvas(self)
        self.setWidget(self.canvas)
        self.setWidgetResizable(False)
        self.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        self.mode = "pagina"     # pagina | largura | livre
        # barra vertical sempre visível: ela aparecendo/sumindo mudaria a largura útil e
        # realimentaria o ajuste da página (oscilação = "piscadas")
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.verticalScrollBar().valueChanged.connect(self._scrolled)
        self._last_page = -1
        self._fit_timer = QTimer(self)
        self._fit_timer.setSingleShot(True)
        self._fit_timer.setInterval(60)
        self._fit_timer.timeout.connect(self.apply_fit)

    def percent(self) -> int:
        # 100% = tamanho real aproximado (96 px/pol)
        return int(round(self.canvas.scale / (96 / 25.4) * 100))

    def set_mode(self, mode: str) -> None:
        self.mode = mode
        self.apply_fit()

    def apply_fit(self) -> None:
        vw = self.viewport().width() - 2 * MARGIN
        vh = self.viewport().height() - 2 * MARGIN
        if self.mode == "pagina":
            s = min(vw / L.A4_W_MM, vh / L.A4_H_MM)
        elif self.mode == "largura":
            s = vw / L.A4_W_MM
        else:
            s = self.canvas.scale
        page = self.canvas.current_page
        if self.mode == "largura":
            s = max(0.6, s)
            # largura exata cabe sem barra horizontal
        if abs(s - self.canvas.scale) / max(self.canvas.scale, 1e-6) >= 0.004:
            self.canvas.set_scale(s)     # mudança desprezível não redesenha (evita ciclos)
            self.canvas._relayout()
        self.zoom_changed.emit(self.percent())
        if self.mode != "livre":
            self.go_to(page)

    def zoom_by(self, factor: float) -> None:
        self.mode = "livre"
        page = self.canvas.current_page
        self.canvas.set_scale(self.canvas.scale * factor)
        self.zoom_changed.emit(self.percent())
        self.go_to(page)

    def set_percent(self, pct: int) -> None:
        self.mode = "livre"
        self.canvas.set_scale(pct / 100 * (96 / 25.4))
        self.zoom_changed.emit(self.percent())

    def go_to(self, i: int) -> None:
        if not self.canvas.exam:
            return
        i = max(0, min(self.canvas.n_pages() - 1, i))
        self.canvas.current_page = i
        r = self.canvas.page_rect(i)
        self.verticalScrollBar().setValue(max(0, r.top() - MARGIN // 2))
        self.canvas.update()

    def _scrolled(self, v: int) -> None:
        if not self.canvas.exam:
            return
        pg = self.canvas.page_at_viewport_center(v, self.viewport().height())
        if pg != self._last_page:
            self._last_page = pg
            self.current_page_changed.emit(pg)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.canvas._relayout()
        if self.mode != "livre":
            self._fit_timer.start()

    def wheelEvent(self, e):
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self.zoom_by(1.12 if e.angleDelta().y() > 0 else 1 / 1.12)
            return
        super().wheelEvent(e)
