"""Ícones próprios (SVG desenhado aqui), coloridos conforme o tema."""
from __future__ import annotations

from functools import lru_cache

from PySide6.QtCore import QByteArray, QRectF, QSize, Qt
from PySide6.QtGui import QIcon, QImage, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer

_P = {  # caminhos em viewBox 24x24, traço
    "new": '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/><path d="M12 11v6M9 14h6"/>',
    "open": '<path d="M3 7h6l2 2h10v10H3z"/><path d="M3 7V5h6l2 2"/>',
    "save": '<path d="M5 3h12l2 2v16H5z"/><path d="M8 3v5h7V3"/><rect x="8" y="13" width="8" height="6"/>',
    "pdf": '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/><path d="M9 13h6M9 16h6M9 10h3"/>',
    "print": '<path d="M7 8V3h10v5"/><rect x="3" y="8" width="18" height="8" rx="1"/><path d="M7 13h10v8H7z"/>',
    "settings": '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
    "about": '<circle cx="12" cy="12" r="9"/><path d="M12 11v6"/><path d="M12 7.5v.5"/>',
    "add": '<rect x="3" y="5" width="18" height="14" rx="1"/><path d="M8 15l3-3 2 2 3-3 3 3"/><path d="M12 2v0"/>',
    "folder": '<path d="M3 7h6l2 2h10v10H3z"/>',
    "check_all": '<rect x="3" y="3" width="8" height="8"/><rect x="13" y="3" width="8" height="8"/><rect x="3" y="13" width="8" height="8"/><rect x="13" y="13" width="8" height="8"/><path d="M5 7l2 2 3-4M15 7l2 2 3-4M5 17l2 2 3-4M15 17l2 2 3-4"/>',
    "uncheck_all": '<rect x="3" y="3" width="8" height="8"/><rect x="13" y="3" width="8" height="8"/><rect x="3" y="13" width="8" height="8"/><rect x="13" y="13" width="8" height="8"/>',
    "zoom_in": '<circle cx="10" cy="10" r="6"/><path d="M15 15l6 6M10 7v6M7 10h6"/>',
    "zoom_out": '<circle cx="10" cy="10" r="6"/><path d="M15 15l6 6M7 10h6"/>',
    "fit_page": '<rect x="6" y="3" width="12" height="18"/><path d="M3 8V3h3M21 8V3h-3M3 16v5h3M21 16v5h-3"/>',
    "fit_width": '<rect x="5" y="4" width="14" height="16"/><path d="M2 12h5M17 12h5M4 10l-2 2 2 2M20 10l2 2-2 2"/>',
    "prev": '<path d="M15 5l-7 7 7 7"/>',
    "next": '<path d="M9 5l7 7-7 7"/>',
    "up": '<path d="M5 15l7-7 7 7"/>',
    "down": '<path d="M5 9l7 7 7-7"/>',
    "page_add": '<path d="M6 3h12v18H6z"/><path d="M12 9v6M9 12h6"/>',
    "page_del": '<path d="M6 3h12v18H6z"/><path d="M9 12h6"/>',
    "auto": '<path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4z"/><path d="M15 16h5M17.5 13.5v5"/>',
    "undo": '<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 010 12h-3"/>',
    "redo": '<path d="M15 14l5-5-5-5"/><path d="M20 9H10a6 6 0 000 12h3"/>',
    "rotate": '<path d="M20 12a8 8 0 11-3-6.2"/><path d="M20 4v5h-5"/>',
    "rotate_l": '<path d="M4 12a8 8 0 103-6.2"/><path d="M4 4v5h5"/>',
    "crop": '<path d="M6 2v16h16"/><path d="M2 6h16v16"/>',
    "expand": '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
    "remove": '<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/>',
    "watch": '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    "pause": '<path d="M9 5v14M15 5v14"/>',
    "restore": '<path d="M4 12a8 8 0 108-8"/><path d="M4 4v5h5"/>',
    "warn": '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/>',
}


def _svg(name: str, color: str) -> bytes:
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
            f'stroke="{color}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'
            f'{_P[name]}</svg>').encode()


@lru_cache(maxsize=256)
def pixmap(name: str, size: int = 20, color: str = "#2B3A55") -> QPixmap:
    r = QSvgRenderer(QByteArray(_svg(name, color)))
    img = QImage(size * 2, size * 2, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    r.render(p, QRectF(0, 0, size * 2, size * 2))
    p.end()
    pm = QPixmap.fromImage(img)
    pm.setDevicePixelRatio(2.0)
    return pm


@lru_cache(maxsize=256)
def icon(name: str, color: str = "#2B3A55", disabled: str = "#A9B1BD", active: str | None = None) -> QIcon:
    ic = QIcon()
    for sz in (16, 20, 24, 32):
        ic.addPixmap(pixmap(name, sz, color), QIcon.Mode.Normal)
        ic.addPixmap(pixmap(name, sz, disabled), QIcon.Mode.Disabled)
        if active:
            ic.addPixmap(pixmap(name, sz, active), QIcon.Mode.Active)
    return ic


def template_pixmap(template: str, w: int = 30, color: str = "#2B3A55", fill: str = "#DCE6F5") -> QPixmap:
    """Miniatura do modelo de página (grade dentro de uma folha)."""
    from ..core.model import TEMPLATE_GRID
    h = int(w * 297 / 210)
    img = QImage(w * 2, h * 2, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    from PySide6.QtGui import QColor, QPen
    p.setPen(QPen(QColor(color), 2))
    p.setBrush(QColor("#FFFFFF"))
    p.drawRect(QRectF(1, 1, w * 2 - 2, h * 2 - 2))
    cols, rows = TEMPLATE_GRID[template]
    top = h * 2 * 0.17
    m = 5.0
    g = 3.0
    bw = w * 2 - 2 * m
    bh = h * 2 - top - m
    cw = (bw - (cols - 1) * g) / cols
    ch = (bh - (rows - 1) * g) / rows
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(color))
    p.drawRect(QRectF(m, m, bw, top - 2 * m + 2))
    p.setBrush(QColor(fill))
    p.setPen(QPen(QColor(color), 1))
    for r in range(rows):
        for c in range(cols):
            p.drawRect(QRectF(m + c * (cw + g), top + r * (ch + g), cw, ch))
    p.end()
    pm = QPixmap.fromImage(img)
    pm.setDevicePixelRatio(2.0)
    return pm


def size(s: int) -> QSize:
    return QSize(s, s)
