"""Tema claro, profissional (consultório/recepção). Azul institucional neutro."""

ACCENT = "#1F5FAD"
ACCENT_DARK = "#174A87"
INK = "#1E2A3B"
MUTED = "#5F6B7A"
LINE = "#D5DBE3"
OK = "#1E8E4E"
WARN = "#B9770E"
ERR = "#C0392B"

QSS = f"""
* {{ font-family: "Segoe UI", "Noto Sans", Arial; font-size: 9.5pt; color: {INK}; }}
QMainWindow, QWidget#root {{ background: #EEF1F5; }}
QDialog {{ background: #F7F9FB; }}
QToolBar {{ background: #FFFFFF; border: none; border-bottom: 1px solid {LINE}; spacing: 4px; padding: 4px 6px; }}
QToolBar QToolButton {{ padding: 5px 9px; border-radius: 6px; border: 1px solid transparent; }}
QToolBar QToolButton:hover {{ background: #EAF1FB; border-color: #C9DAF1; }}
QToolBar QToolButton:pressed {{ background: #D7E5F7; }}
QToolBar QToolButton#primaryTool {{ background: {ACCENT}; color: #FFFFFF; font-weight: 600; }}
QToolBar QToolButton#primaryTool:hover {{ background: {ACCENT_DARK}; }}
QFrame#idstrip {{ background: #FFFFFF; border-bottom: 1px solid {LINE}; }}
QFrame#panel {{ background: #FFFFFF; border: 1px solid {LINE}; border-radius: 8px; }}
QLabel#panelTitle {{ font-weight: 700; font-size: 10pt; color: {INK}; padding: 2px 0; }}
QLabel#muted {{ color: {MUTED}; }}
QLabel#hint {{ color: {MUTED}; font-size: 8.5pt; }}
QLabel#warn {{ color: {WARN}; }}
QLabel#statusOk {{ color: {OK}; font-weight: 600; }}
QLabel#statusPending {{ color: {WARN}; font-weight: 600; }}
QLabel#statusErr {{ color: {ERR}; font-weight: 700; }}
QLineEdit, QPlainTextEdit {{
  background: #FFFFFF; border: 1px solid #C3CBD6; border-radius: 6px; padding: 4px 7px;
  selection-background-color: {ACCENT}; selection-color: #FFFFFF;
}}
QLineEdit:focus, QPlainTextEdit:focus {{ border-color: {ACCENT}; }}
QLineEdit#patientName {{ font-size: 12pt; font-weight: 600; padding: 5px 9px; }}
QPushButton {{ background: #FFFFFF; border: 1px solid #C3CBD6; border-radius: 6px; padding: 5px 11px; }}
QPushButton:hover {{ background: #F1F5FA; border-color: #9FB1C8; }}
QPushButton:pressed {{ background: #E3EAF3; }}
QPushButton:disabled {{ color: #A3ACB8; background: #F6F7F9; border-color: #DDE2E8; }}
QPushButton:checked {{ background: #DCE8F7; border-color: {ACCENT}; color: {ACCENT_DARK}; font-weight: 600; }}
QPushButton#primary {{ background: {ACCENT}; color: #FFFFFF; border-color: {ACCENT_DARK}; font-weight: 600; }}
QPushButton#primary:hover {{ background: {ACCENT_DARK}; }}
QToolButton#tpl {{ border: 1px solid #C3CBD6; border-radius: 6px; background: #FFFFFF; padding: 3px; }}
QToolButton#tpl:hover {{ background: #F1F5FA; }}
QToolButton#tpl:checked {{ background: #DCE8F7; border: 2px solid {ACCENT}; }}
QListView, QListWidget {{ background: #FFFFFF; border: 1px solid {LINE}; border-radius: 6px; }}
QListWidget::item {{ padding: 4px; border-radius: 4px; }}
QListWidget::item:selected {{ background: #DCE8F7; color: {INK}; }}
QSplitter::handle {{ background: #E1E6ED; }}
QSplitter::handle:hover {{ background: #B9C9DE; }}
QStatusBar {{ background: #FFFFFF; border-top: 1px solid {LINE}; }}
QStatusBar QLabel {{ padding: 0 8px; }}
QScrollArea#previewArea {{ background: #7B8594; border: none; }}
QWidget#previewCanvas {{ background: #7B8594; }}
QTabWidget::pane {{ border: 1px solid {LINE}; border-radius: 6px; background: #FFFFFF; top: -1px; }}
QTabBar::tab {{ padding: 6px 14px; border: 1px solid {LINE}; border-bottom: none; background: #EEF1F5;
  border-top-left-radius: 6px; border-top-right-radius: 6px; margin-right: 2px; }}
QTabBar::tab:selected {{ background: #FFFFFF; font-weight: 600; }}
QHeaderView::section {{ background: #EEF1F5; border: none; border-bottom: 1px solid {LINE}; padding: 5px; font-weight: 600; }}
QTableView {{ background: #FFFFFF; border: 1px solid {LINE}; border-radius: 6px; gridline-color: #EDF0F4;
  selection-background-color: #DCE8F7; selection-color: {INK}; }}
QMenu {{ background: #FFFFFF; border: 1px solid #C3CBD6; padding: 4px; }}
QMenu::item {{ padding: 5px 22px 5px 10px; border-radius: 4px; }}
QMenu::item:selected {{ background: #DCE8F7; }}
QCheckBox::indicator {{ width: 16px; height: 16px; }}
QFrame#banner {{ background: #FFF6E5; border: 1px solid #F0D49A; border-radius: 6px; }}
QFrame#infoBanner {{ background: #EAF2FC; border: 1px solid #BFD4EF; border-radius: 6px; }}
"""
