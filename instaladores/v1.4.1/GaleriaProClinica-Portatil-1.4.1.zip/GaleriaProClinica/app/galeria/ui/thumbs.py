"""Miniaturas geradas em segundo plano (a interface nunca trava)."""
from __future__ import annotations

import os

from PySide6.QtCore import QObject, QRunnable, QThreadPool, Signal
from PySide6.QtGui import QImage, QPixmap

from ..core import imageio
from ..core.model import ImageItem

BASE_PX = 360
CACHE_DIR = ".miniaturas"


class _Emitter(QObject):
    done = Signal(str, QImage)      # id, miniatura base (sem edição)
    failed = Signal(str, str)


class _Job(QRunnable):
    def __init__(self, emitter: _Emitter, image_id: str, src: str, cache: str):
        super().__init__()
        self.e, self.id, self.src, self.cache = emitter, image_id, src, cache
        self.setAutoDelete(True)

    def run(self) -> None:
        try:
            img = None
            if os.path.isfile(self.cache) and os.path.getmtime(self.cache) >= os.path.getmtime(self.src):
                c = QImage(self.cache)
                if not c.isNull():
                    img = c
            if img is None:
                img = imageio.load_scaled(self.src, BASE_PX)
                if max(img.width(), img.height()) > BASE_PX:
                    from PySide6.QtCore import Qt
                    img = img.scaled(BASE_PX, BASE_PX, Qt.AspectRatioMode.KeepAspectRatio,
                                     Qt.TransformationMode.SmoothTransformation)
                try:
                    os.makedirs(os.path.dirname(self.cache), exist_ok=True)
                    img.save(self.cache, "JPG", 88)
                except Exception:
                    pass
            self.e.done.emit(self.id, img)
        except Exception as ex:  # arquivo ausente/corrompido
            self.e.failed.emit(self.id, str(ex))


class ThumbService(QObject):
    ready = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.pool = QThreadPool(self)
        self.pool.setMaxThreadCount(max(2, min(4, QThreadPool.globalInstance().maxThreadCount())))
        self._em = _Emitter()
        self._em.done.connect(self._on_done)
        self._em.failed.connect(self._on_failed)
        self.folder = ""
        self._base: dict[str, QImage] = {}
        self._edited: dict[tuple, QPixmap] = {}
        self._pending: set[str] = set()
        self.broken: set[str] = set()

    def reset(self, folder: str) -> None:
        self.pool.clear()
        self.folder = folder
        self._base.clear()
        self._edited.clear()
        self._pending.clear()
        self.broken.clear()

    def _on_done(self, iid: str, img: QImage) -> None:
        self._pending.discard(iid)
        self._base[iid] = img
        self.ready.emit(iid)

    def _on_failed(self, iid: str, _msg: str) -> None:
        self._pending.discard(iid)
        self.broken.add(iid)
        self.ready.emit(iid)

    def pending_count(self) -> int:
        return len(self._pending)

    def get(self, item: ImageItem) -> QPixmap | None:
        base = self._base.get(item.id)
        if base is None:
            if item.id not in self._pending and item.id not in self.broken and self.folder:
                self._pending.add(item.id)
                src = os.path.join(self.folder, item.file)
                cache = os.path.join(self.folder, CACHE_DIR, f"{item.id}.jpg")
                self.pool.start(_Job(self._em, item.id, src, cache))
            return None
        key = (item.id, item.rotation, repr(item.crop.to_dict()))
        pm = self._edited.get(key)
        if pm is None:
            pm = QPixmap.fromImage(imageio.apply_edits(base, item))
            self._edited[key] = pm
        return pm

    def base_image(self, iid: str) -> QImage | None:
        return self._base.get(iid)
