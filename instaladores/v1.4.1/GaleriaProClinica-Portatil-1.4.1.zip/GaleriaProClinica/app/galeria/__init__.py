"""Galeria Pro Clínica — organização e impressão de fotografias de exames."""
__version__ = "1.4.1"
__year__ = "2026"          # ano da versão (aparece em “Sobre”)
APP_NAME = "Galeria Pro Clínica"
APP_ID = "GaleriaProClinica"
