"""Leitura de imagens, hash, cópia para o exame e aplicação de recorte/rotação.

O arquivo de origem nunca é alterado. Recorte e rotação são instruções aplicadas na
hora de desenhar.
"""
from __future__ import annotations

import hashlib
import os
import shutil

from PySide6.QtCore import QRect, QSize
from PySide6.QtGui import QImage, QImageReader, QTransform

from .model import ImageItem

SUPPORTED_EXT = (".png", ".jpg", ".jpeg", ".bmp")
QImageReader.setAllocationLimit(2048)  # MB — imagens grandes de câmeras/placas


def is_supported(path: str) -> bool:
    return os.path.splitext(path)[1].lower() in SUPPORTED_EXT


def sha256_file(path: str, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def probe(path: str) -> tuple[int, int]:
    """Dimensões (já considerando a orientação EXIF). Lança ValueError se ilegível."""
    r = QImageReader(path)
    r.setAutoTransform(True)
    if not r.canRead():
        raise ValueError(r.errorString() or "formato não reconhecido")
    sz = r.size()
    if not sz.isValid() or sz.width() <= 0:
        img = r.read()
        if img.isNull():
            raise ValueError(r.errorString() or "imagem ilegível")
        return img.width(), img.height()
    t = r.transformation()
    # rotações de 90/270 pela EXIF invertem as dimensões
    from PySide6.QtGui import QImageIOHandler
    if t & QImageIOHandler.Transformation.TransformationRotate90:
        return sz.height(), sz.width()
    return sz.width(), sz.height()


def load_full(path: str) -> QImage:
    r = QImageReader(path)
    r.setAutoTransform(True)
    img = r.read()
    if img.isNull():
        raise ValueError(r.errorString() or f"não foi possível ler {os.path.basename(path)}")
    return img


def load_scaled(path: str, max_px: int) -> QImage:
    """Carrega já reduzido (rápido para JPEG grandes). Nunca amplia."""
    r = QImageReader(path)
    r.setAutoTransform(True)
    sz = r.size()
    if sz.isValid() and max(sz.width(), sz.height()) > max_px:
        s = max_px / max(sz.width(), sz.height())
        # o tamanho de escala é aplicado antes da transformação EXIF
        r.setScaledSize(QSize(max(1, round(sz.width() * s)), max(1, round(sz.height() * s))))
    img = r.read()
    if img.isNull():
        raise ValueError(r.errorString() or f"não foi possível ler {os.path.basename(path)}")
    return img


def apply_edits(img: QImage, item: ImageItem) -> QImage:
    """Rotação (passos de 90°, sem perda) seguida do recorte normalizado."""
    out = img
    if item.rotation:
        out = out.transformed(QTransform().rotate(item.rotation))
    c = item.crop
    if not c.is_full():
        w, h = out.width(), out.height()
        x0 = int(round(c.x * w))
        y0 = int(round(c.y * h))
        x1 = int(round((c.x + c.w) * w))
        y1 = int(round((c.y + c.h) * h))
        rect = QRect(x0, y0, max(1, x1 - x0), max(1, y1 - y0)).intersected(QRect(0, 0, w, h))
        out = out.copy(rect)
    return out


def unique_dest(folder: str, name: str) -> str:
    base, ext = os.path.splitext(name)
    cand = os.path.join(folder, name)
    k = 2
    while os.path.exists(cand):
        cand = os.path.join(folder, f"{base}_{k}{ext}")
        k += 1
    return cand


def copy_into(src: str, folder: str) -> str:
    """Copia o arquivo (bit a bit) para a pasta do exame. Retorna o caminho de destino."""
    os.makedirs(folder, exist_ok=True)
    name = os.path.basename(src)
    dest = unique_dest(folder, name)
    tmp = dest + ".parcial"
    try:
        shutil.copyfile(src, tmp)
        with open(tmp, "rb+") as f:
            os.fsync(f.fileno())
        os.replace(tmp, dest)
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
    return dest
