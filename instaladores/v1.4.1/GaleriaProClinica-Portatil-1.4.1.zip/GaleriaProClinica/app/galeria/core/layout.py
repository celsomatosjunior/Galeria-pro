"""Geometria da folha (em milímetros). Sem Qt: a medição de texto é injetada.

Esta é a fonte única das posições usadas pela prévia, pelo PDF e pela impressão.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

from .model import TEMPLATE_GRID

A4_W_MM = 210.0
A4_H_MM = 297.0
PT_TO_MM = 25.4 / 72.0
MIN_BODY_MM = 40.0          # corpo mínimo (largura e altura) para uma composição válida
LOW_DPI = 150.0             # abaixo disto, aviso discreto de resolução baixa

# limites de configuração (impedem composição inválida)
LIMITS = {
    "margem": (3.0, 40.0),
    "espacamento": (0.0, 15.0),
    "cabecalho_altura_mm": (0.0, 80.0),
    "logo_altura_mm": (5.0, 80.0),
    "logo_largura_max_pct": (10, 100),
    "id_tamanho_pt": (7.0, 20.0),
    "rodape_tamanho_pt": (6.0, 16.0),
    "numeracao_tamanho_pt": (6.0, 12.0),
    "logo_deslocamento_mm": (-60.0, 60.0),
}


class Measurer(Protocol):
    def width(self, text: str, family: str, size_pt: float, bold: bool = False) -> float: ...
    def line_height(self, family: str, size_pt: float) -> float: ...
    # opcional: def ascent(self, family, size_pt, bold) -> float (mm, para alinhar a linha de base)


@dataclass
class Rect:
    x: float
    y: float
    w: float
    h: float

    @property
    def right(self) -> float:
        return self.x + self.w

    @property
    def bottom(self) -> float:
        return self.y + self.h


@dataclass
class TextRun:
    text: str
    x: float
    baseline_top: float     # topo da linha (o desenho usa o retângulo da linha)
    bold: bool
    family: str
    size_pt: float
    color: str = "#000000"
    width: float = 0.0
    line_h: float = 0.0


@dataclass
class TextLine:
    y: float
    h: float
    align: str               # esquerda | centro | direita
    text: str
    family: str
    size_pt: float
    color: str = "#000000"


@dataclass
class PageGeometry:
    page_w: float
    page_h: float
    content: Rect
    logo_zone: Rect
    id_runs: list[TextRun]
    sep_lines: list[float]           # coordenadas y das linhas separadoras
    body: Rect
    footer_lines: list[TextLine]
    number_line: TextLine | None
    cells: list[Rect] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def sanitize_identity(ident: dict) -> dict:
    """Aplica os limites a uma identidade (cópia)."""
    d = dict(ident)
    lo, hi = LIMITS["margem"]
    for k in ("margem_sup_mm", "margem_inf_mm", "margem_esq_mm", "margem_dir_mm"):
        d[k] = clamp(float(d.get(k, 8.0)), lo, hi)
    d["espacamento_mm"] = clamp(float(d.get("espacamento_mm", 2.0)), *LIMITS["espacamento"])
    d["cabecalho_altura_mm"] = clamp(float(d.get("cabecalho_altura_mm", 30.0)), *LIMITS["cabecalho_altura_mm"])
    d["logo_altura_mm"] = clamp(float(d.get("logo_altura_mm", 26.0)), *LIMITS["logo_altura_mm"])
    d["logo_largura_max_pct"] = clamp(float(d.get("logo_largura_max_pct", 45)), *LIMITS["logo_largura_max_pct"])
    for k in ("logo_deslocamento_x_mm", "logo_deslocamento_y_mm"):
        d[k] = clamp(float(d.get(k, 0.0)), *LIMITS["logo_deslocamento_mm"])
    d["id_tamanho_pt"] = clamp(float(d.get("id_tamanho_pt", 11)), *LIMITS["id_tamanho_pt"])
    d["rodape_tamanho_pt"] = clamp(float(d.get("rodape_tamanho_pt", 8)), *LIMITS["rodape_tamanho_pt"])
    d["numeracao_tamanho_pt"] = clamp(float(d.get("numeracao_tamanho_pt", 7.5)), *LIMITS["numeracao_tamanho_pt"])
    for k, opts in (("logo_alinhamento", ("esquerda", "centro", "direita")),
                    ("rodape_alinhamento", ("esquerda", "centro", "direita")),
                    ("numeracao_posicao", ("esquerda", "centro", "direita"))):
        if d.get(k) not in opts:
            d[k] = "direita" if k != "rodape_alinhamento" else "centro"
    return d


def wrap_words(text: str, max_w: float, measure_w, first_max_w: float | None = None) -> list[str]:
    """Quebra por palavras; palavras maiores que a linha são quebradas por caractere."""
    lines: list[str] = []
    cur = ""
    limit = first_max_w if first_max_w is not None else max_w
    for word in text.split():
        cand = word if not cur else cur + " " + word
        if measure_w(cand) <= limit:
            cur = cand
            continue
        if cur:
            lines.append(cur)
            limit = max_w
            cur = ""
        # palavra sozinha pode não caber: quebra por caractere
        piece = ""
        for ch in word:
            if measure_w(piece + ch) <= limit or not piece:
                piece += ch
            else:
                lines.append(piece)
                limit = max_w
                piece = ch
        cur = piece
    if cur or not lines:
        lines.append(cur)
    return lines


def compute_geometry(ident: dict, patient: str, date_br: str, template: str,
                     page_no: int, page_count: int, m: Measurer,
                     logo_px: tuple[int, int] | None = None) -> PageGeometry:
    d = sanitize_identity(ident)
    W, H = A4_W_MM, A4_H_MM
    content = Rect(d["margem_esq_mm"], d["margem_sup_mm"],
                   W - d["margem_esq_mm"] - d["margem_dir_mm"],
                   H - d["margem_sup_mm"] - d["margem_inf_mm"])
    warnings: list[str] = []
    y = content.y

    # ---- logo ----
    hz = d["cabecalho_altura_mm"]
    logo_zone = Rect(content.x, y, 0.0, 0.0)
    if logo_px and logo_px[0] > 0 and logo_px[1] > 0 and hz > 0:
        max_h = min(d["logo_altura_mm"], hz)
        max_w = content.w * d["logo_largura_max_pct"] / 100.0
        lw, lh = logo_px
        s = min(max_w / lw, max_h / lh)
        w, h = lw * s, lh * s
        if d["logo_alinhamento"] == "esquerda":
            x = content.x
        elif d["logo_alinhamento"] == "centro":
            x = content.x + (content.w - w) / 2
        else:
            x = content.right - w
        ly = y + (hz - h) / 2
        x = clamp(x + d["logo_deslocamento_x_mm"], 0.0, W - w)
        ly = clamp(ly + d["logo_deslocamento_y_mm"], 0.0, H - h)
        logo_zone = Rect(x, ly, w, h)
    y += hz

    seps: list[float] = []
    if d["linhas_separadoras"]:
        seps.append(y)
    y += 1.6

    # ---- identificação ----
    fam, pt, col = d["id_fonte"], d["id_tamanho_pt"], d["id_cor"]
    lh = m.line_height(fam, pt)
    # Duas áreas independentes (1.4.1): ESQUERDA = "Paciente: nome", alinhada à margem
    # esquerda; DIREITA = "Data: DD/MM/AAAA", com a extremidade direita presa à margem direita
    # da área útil (o mesmo limite das fotos). A data não depende do nome: nome longo é
    # ajustado só dentro da área dele (fonte reduzida até 80%; depois reticências), sempre
    # numa linha — o cabeçalho tem altura fixa e o nome nunca invade a área da data.
    lab_p, lab_d = "Paciente: ", "Data: "
    name = " ".join((patient or "").split()) or "—"
    w_lab_p = m.width(lab_p, fam, pt)
    w_lab_d = m.width(lab_d, fam, pt)
    w_date = m.width(date_br, fam, pt, True)
    gap = 6.0                                    # folga mínima entre as duas áreas (mm)
    x_date = content.right - w_date
    x_lab_d = x_date - w_lab_d
    name_max = max(0.0, x_lab_d - gap - (content.x + w_lab_p))
    asc = getattr(m, "ascent", None)

    def ascent(size: float) -> float:
        return asc(fam, size, True) if asc else m.line_height(fam, size) * 0.8
    npt = pt
    w_name = m.width(name, fam, npt, True)
    while w_name > name_max and npt > pt * 0.8 + 1e-6:
        npt = max(pt * 0.8, round(npt - 0.25, 2))
        w_name = m.width(name, fam, npt, True)
    shown = name
    if w_name > name_max:
        ell = "…"
        k = len(name)
        while k > 0 and m.width(name[:k].rstrip() + ell, fam, npt, True) > name_max:
            k -= 1
        shown = (name[:k].rstrip() + ell) if k > 0 else ell
        w_name = m.width(shown, fam, npt, True)
    name_top = y + (ascent(pt) - ascent(npt))   # mesma linha de base do restante do cabeçalho
    runs: list[TextRun] = [
        TextRun(lab_p, content.x, y, False, fam, pt, col, w_lab_p, lh),
        TextRun(shown, content.x + w_lab_p, name_top, True, fam, npt, col, w_name, lh),
        TextRun(lab_d, x_lab_d, y, False, fam, pt, col, w_lab_d, lh),
        TextRun(date_br, x_date, y, True, fam, pt, col, w_date, lh),
    ]
    y += lh
    y += 1.4
    if d["linhas_separadoras"]:
        seps.append(y)
    y += 2.0
    body_top = y

    # ---- rodapé (de baixo para cima) ----
    bottom = content.bottom
    number_line = None
    if d["numeracao"]:
        npt = d["numeracao_tamanho_pt"]
        nh = m.line_height(fam, npt)
        bottom -= nh
        number_line = TextLine(bottom, nh, d["numeracao_posicao"],
                               f"Página {page_no} de {page_count}", d["rodape_fonte"], npt, "#555555")
    flines: list[TextLine] = []
    ftext = (d.get("rodape_texto") or "").replace("\r\n", "\n").rstrip("\n")
    if ftext.strip():
        ffam, fpt = d["rodape_fonte"], d["rodape_tamanho_pt"]
        flh = m.line_height(ffam, fpt)
        wrapped: list[str] = []
        for para in ftext.split("\n"):
            if not para.strip():
                wrapped.append("")
                continue
            wrapped += wrap_words(para, content.w, lambda s: m.width(s, ffam, fpt))
        fh = flh * len(wrapped)
        top = bottom - fh - (0.8 if number_line else 0.0)
        for i, ln in enumerate(wrapped):
            flines.append(TextLine(top + i * flh, flh, d["rodape_alinhamento"], ln, ffam, fpt, "#222222"))
        bottom = top
    if flines or number_line:
        bottom -= 2.5
    body = Rect(content.x, body_top, content.w, bottom - body_top)
    if body.h < MIN_BODY_MM:
        warnings.append("Cabeçalho e rodapé ocupam espaço demais: reduza a altura do cabeçalho, "
                        "o texto do rodapé ou as margens.")
        body.h = max(body.h, 10.0)

    geo = PageGeometry(W, H, content, logo_zone, runs, seps, body, flines, number_line, warnings=warnings)
    geo.cells = grid_cells(body, template, d["espacamento_mm"])
    return geo


def grid_cells(body: Rect, template: str, gap: float) -> list[Rect]:
    cols, rows = TEMPLATE_GRID[template]
    gap = max(0.0, gap)
    cw = (body.w - (cols - 1) * gap) / cols
    ch = (body.h - (rows - 1) * gap) / rows
    cells = []
    for r in range(rows):              # leitura: esquerda→direita, cima→baixo
        for c in range(cols):
            cells.append(Rect(body.x + c * (cw + gap), body.y + r * (ch + gap), cw, ch))
    return cells


def fit_rect(img_w: float, img_h: float, cell: Rect) -> Rect:
    """Maior retângulo com a proporção da imagem, centralizado, dentro da célula.
    Nunca deforma e nunca corta."""
    if img_w <= 0 or img_h <= 0:
        return Rect(cell.x, cell.y, 0, 0)
    s = min(cell.w / img_w, cell.h / img_h)
    w, h = img_w * s, img_h * s
    return Rect(cell.x + (cell.w - w) / 2, cell.y + (cell.h - h) / 2, w, h)


def effective_dpi(img_px_w: float, drawn_w_mm: float) -> float:
    if drawn_w_mm <= 0:
        return 0.0
    return img_px_w / (drawn_w_mm / 25.4)
