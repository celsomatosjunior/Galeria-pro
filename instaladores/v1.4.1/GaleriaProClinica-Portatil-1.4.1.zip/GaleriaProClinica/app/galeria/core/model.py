"""Modelo de dados do exame (sem dependência de Qt).

Todas as estruturas convertem-se para/de dicionários simples (JSON).
"""
from __future__ import annotations

import copy
import datetime as _dt
import uuid
from dataclasses import dataclass, field

TEMPLATES = ("1", "2", "6", "9", "12")
TEMPLATE_GRID = {"1": (1, 1), "2": (1, 2), "6": (2, 3), "9": (3, 3), "12": (3, 4)}  # (colunas, linhas)
TEMPLATE_LABEL = {
    "1": "1 foto", "2": "2 fotos", "6": "6 fotos", "9": "9 fotos", "12": "12 fotos",
}


def capacity(template: str) -> int:
    c, r = TEMPLATE_GRID[template]
    return c * r


def new_id() -> str:
    return uuid.uuid4().hex


@dataclass
class Crop:
    """Recorte normalizado (0..1) sobre a imagem JÁ girada."""
    x: float = 0.0
    y: float = 0.0
    w: float = 1.0
    h: float = 1.0

    def is_full(self) -> bool:
        return self.x <= 1e-6 and self.y <= 1e-6 and self.w >= 1 - 1e-6 and self.h >= 1 - 1e-6

    def normalized(self) -> "Crop":
        x = min(max(self.x, 0.0), 0.99)
        y = min(max(self.y, 0.0), 0.99)
        w = min(max(self.w, 0.01), 1.0 - x)
        h = min(max(self.h, 0.01), 1.0 - y)
        return Crop(x, y, w, h)

    def to_dict(self) -> dict:
        return {"x": round(self.x, 6), "y": round(self.y, 6), "w": round(self.w, 6), "h": round(self.h, 6)}

    @staticmethod
    def from_dict(d: dict | None) -> "Crop":
        if not d:
            return Crop()
        return Crop(float(d.get("x", 0)), float(d.get("y", 0)),
                    float(d.get("w", 1)), float(d.get("h", 1))).normalized()


@dataclass
class ImageItem:
    id: str
    file: str                 # caminho relativo à pasta do exame (cópia)
    original_name: str
    sha256: str
    width: int                # dimensões do arquivo original (sem edição)
    height: int
    source_path: str = ""     # de onde veio (só informativo; o exame não depende dele)
    imported_at: str = ""
    captured_at: str = ""     # data de modificação do arquivo de origem (≈ data da captura)
    rotation: int = 0         # 0, 90, 180, 270 (sentido horário)
    crop: Crop = field(default_factory=Crop)

    def edited_size(self) -> tuple[float, float]:
        """Tamanho em pixels após rotação e recorte (para encaixe e aviso de resolução)."""
        w, h = (self.height, self.width) if self.rotation in (90, 270) else (self.width, self.height)
        return (w * self.crop.w, h * self.crop.h)

    def has_edits(self) -> bool:
        return self.rotation != 0 or not self.crop.is_full()

    def to_dict(self) -> dict:
        return {
            "id": self.id, "arquivo": self.file, "nome_original": self.original_name,
            "sha256": self.sha256, "largura": self.width, "altura": self.height,
            "origem": self.source_path, "importada_em": self.imported_at,
            "data_captura": self.captured_at, "rotacao": self.rotation, "recorte": self.crop.to_dict(),
        }

    @staticmethod
    def from_dict(d: dict) -> "ImageItem":
        rot = int(d.get("rotacao", 0)) % 360
        if rot not in (0, 90, 180, 270):
            rot = 0
        return ImageItem(
            id=str(d["id"]), file=str(d["arquivo"]), original_name=str(d.get("nome_original", "")),
            sha256=str(d.get("sha256", "")), width=int(d.get("largura", 0)), height=int(d.get("altura", 0)),
            source_path=str(d.get("origem", "")), imported_at=str(d.get("importada_em", "")),
            captured_at=str(d.get("data_captura", "") or d.get("importada_em", "")), rotation=rot,
            crop=Crop.from_dict(d.get("recorte")),
        )


@dataclass
class Page:
    """Uma folha: modelo + células. slots[i] = id da imagem na célula i (ordem de leitura),
    ou None para célula vazia. len(slots) == capacidade do modelo."""
    template: str = "6"
    slots: list = field(default_factory=list)

    def __post_init__(self) -> None:
        self.fit_slots()

    def fit_slots(self) -> None:
        cap = capacity(self.template)
        if len(self.slots) < cap:
            self.slots = list(self.slots) + [None] * (cap - len(self.slots))

    def used(self) -> list[str]:
        return [x for x in self.slots if x]

    def free(self) -> int:
        return sum(1 for x in self.slots[:capacity(self.template)] if not x)

    def to_dict(self) -> dict:
        return {"modelo": self.template, "posicoes": list(self.slots)}

    @staticmethod
    def from_dict(d: dict) -> "Page":
        t = str(d.get("modelo", "6"))
        t = t if t in TEMPLATES else "6"
        slots = [str(x) if x else None for x in (d.get("posicoes") or [])]
        return Page(t, slots)


def default_identity() -> dict:
    """Identidade visual e parâmetros de página (copiados para cada exame)."""
    return {
        "logo_arquivo": "",           # relativo à pasta do exame (cópia) ou caminho em config
        "logo_altura_mm": 26.0,       # altura máxima da logo
        "logo_largura_max_pct": 45,   # largura máxima, % da largura útil
        "logo_alinhamento": "direita",  # esquerda | centro | direita
        "logo_deslocamento_x_mm": 0.0,
        "logo_deslocamento_y_mm": 0.0,
        "cabecalho_altura_mm": 30.0,  # altura reservada para a logo
        "id_fonte": "Arial",
        "id_tamanho_pt": 11.0,
        "id_cor": "#1F3A68",
        "rodape_texto": "",
        "rodape_fonte": "Arial",
        "rodape_tamanho_pt": 8.0,
        "rodape_alinhamento": "centro",
        "numeracao": True,
        "numeracao_posicao": "direita",   # esquerda | centro | direita
        "numeracao_tamanho_pt": 7.5,
        "margem_sup_mm": 8.0,
        "margem_inf_mm": 8.0,
        "margem_esq_mm": 8.0,
        "margem_dir_mm": 8.0,
        "espacamento_mm": 2.0,
        "linhas_separadoras": True,
    }


@dataclass
class Exam:
    id: str
    patient: str
    date: str                       # ISO AAAA-MM-DD
    created_at: str = ""
    modified_at: str = ""
    images: list[ImageItem] = field(default_factory=list)
    pages: list[Page] = field(default_factory=list)
    default_template: str = "6"
    gallery_sort: str = "importacao"      # importacao | nome | captura | personalizada
    identity: dict = field(default_factory=default_identity)

    # ---------- consultas ----------
    def image(self, image_id: str) -> ImageItem | None:
        for it in self.images:
            if it.id == image_id:
                return it
        return None

    def placements(self) -> dict[str, tuple[int, int]]:
        """id → (página, célula) da PRIMEIRA ocorrência de cada foto na composição."""
        out: dict[str, tuple[int, int]] = {}
        for pi, pg in enumerate(self.pages):
            for si, iid in enumerate(pg.slots):
                if iid and iid not in out:
                    out[iid] = (pi, si)
        return out

    def occurrences(self) -> dict[str, list[tuple[int, int]]]:
        """id → todas as células em que a foto aparece (1.4: uma foto pode ser usada várias
        vezes, na mesma página ou em páginas diferentes; cada célula é uma ocorrência)."""
        out: dict[str, list[tuple[int, int]]] = {}
        for pi, pg in enumerate(self.pages):
            for si, iid in enumerate(pg.slots):
                if iid:
                    out.setdefault(iid, []).append((pi, si))
        return out

    def has_repeats(self) -> bool:
        ids = [x for pg in self.pages for x in pg.slots if x]
        return len(ids) != len(set(ids))

    def sequence(self) -> list[ImageItem]:
        """Ocorrências da composição na ordem de impressão (páginas, depois células).
        Uma foto usada 3 vezes aparece 3 vezes."""
        by_id = {it.id: it for it in self.images}
        out = []
        for pg in self.pages:
            for iid in pg.slots:
                if iid and iid in by_id:
                    out.append(by_id[iid])
        return out

    def is_used(self, image_id: str) -> bool:
        return any(image_id in pg.slots for pg in self.pages)

    def use_count(self, image_id: str) -> int:
        return sum(pg.slots.count(image_id) for pg in self.pages)

    def free_cells(self) -> int:
        return sum(pg.free() for pg in self.pages)

    def find_by_hash(self, sha: str) -> ImageItem | None:
        for it in self.images:
            if it.sha256 == sha:
                return it
        return None

    def date_br(self) -> str:
        try:
            return _dt.date.fromisoformat(self.date).strftime("%d/%m/%Y")
        except ValueError:
            return self.date

    # ---------- serialização ----------
    def to_dict(self) -> dict:
        return {
            "id": self.id, "paciente": self.patient, "data_exame": self.date,
            "criado_em": self.created_at, "modificado_em": self.modified_at,
            "modelo_padrao": self.default_template,
            "ordem_galeria": self.gallery_sort,
            "imagens": [i.to_dict() for i in self.images],
            "paginas": [p.to_dict() for p in self.pages],
            "identidade": copy.deepcopy(self.identity),
        }

    @staticmethod
    def from_dict(d: dict) -> "Exam":
        ident = default_identity()
        ident.update(d.get("identidade") or {})
        t = str(d.get("modelo_padrao", "6"))
        ex = Exam(
            id=str(d["id"]), patient=str(d.get("paciente", "")), date=str(d.get("data_exame", "")),
            created_at=str(d.get("criado_em", "")), modified_at=str(d.get("modificado_em", "")),
            images=[ImageItem.from_dict(x) for x in d.get("imagens", [])],
            pages=[Page.from_dict(x) for x in d.get("paginas", [])],
            default_template=t if t in TEMPLATES else "6",
            gallery_sort=str(d.get("ordem_galeria", "importacao")),
            identity=ident,
        )
        # ids duplicados (arquivo editado à mão) não podem quebrar o programa
        seen = set()
        uniq = []
        for it in ex.images:
            if it.id in seen:
                continue
            seen.add(it.id)
            uniq.append(it)
        ex.images = uniq
        ex.sanitize_slots()
        return ex

    def sanitize_slots(self) -> None:
        """Células apontando para imagens inexistentes ficam vazias; cada página tem
        exatamente as células do seu modelo. A mesma foto PODE ocupar várias células (1.4)."""
        known = {it.id for it in self.images}
        for pg in self.pages:
            pg.fit_slots()
            cap = capacity(pg.template)
            extra = [x for x in pg.slots[cap:] if x]
            pg.slots = pg.slots[:cap]
            for i, x in enumerate(pg.slots):
                if x and x not in known:
                    pg.slots[i] = None
            if extra:  # não deveria ocorrer; nunca descarta: vai para células livres
                for x in extra:
                    if x in known and None in pg.slots:
                        pg.slots[pg.slots.index(None)] = x

    # estado usado por desfazer/refazer (composição e edição)
    def snapshot(self) -> dict:
        return {"imagens": [i.to_dict() for i in self.images],
                "paginas": [p.to_dict() for p in self.pages],
                "modelo_padrao": self.default_template, "ordem_galeria": self.gallery_sort}

    def restore(self, snap: dict) -> None:
        self.images = [ImageItem.from_dict(x) for x in snap["imagens"]]
        self.pages = [Page.from_dict(x) for x in snap["paginas"]]
        self.default_template = snap.get("modelo_padrao", self.default_template)
        self.gallery_sort = snap.get("ordem_galeria", self.gallery_sort)


def migrate_v1(d: dict) -> dict:
    """Formato 1 (1.0.0) → formato 2. Na 1.0 a impressão eram as imagens marcadas, na ordem
    da galeria, escorrendo pelas páginas. Aqui isso vira posições explícitas — o resultado
    impresso é exatamente o mesmo."""
    d = copy.deepcopy(d)
    imgs = d.get("imagens", [])
    seq = [x["id"] for x in imgs if x.get("selecionada")]
    default = str(d.get("modelo_padrao", "6"))
    default = default if default in TEMPLATES else "6"
    pages_in = [str(p.get("modelo", "6")) for p in d.get("paginas", [])]
    pages_out = []
    k = 0
    for t in pages_in:
        t = t if t in TEMPLATES else "6"
        cap = capacity(t)
        chunk = seq[k:k + cap]
        k += cap
        pages_out.append({"modelo": t, "posicoes": chunk + [None] * (cap - len(chunk))})
    while k < len(seq):
        cap = capacity(default)
        chunk = seq[k:k + cap]
        k += cap
        pages_out.append({"modelo": default, "posicoes": chunk + [None] * (cap - len(chunk))})
    for x in imgs:
        x.pop("selecionada", None)
        x.setdefault("data_captura", x.get("importada_em", ""))
    d["paginas"] = pages_out
    d["ordem_galeria"] = "personalizada"
    return d


def now_iso() -> str:
    return _dt.datetime.now().replace(microsecond=0).isoformat()
