"""Acompanhamento da pasta de capturas.

O Capture Pro grava a foto diretamente no nome final. Por isso uma imagem nova só é
entregue quando: (1) tamanho e data de modificação ficaram iguais em duas verificações
seguidas, (2) o arquivo termina corretamente (PNG com IEND, JPEG com FFD9, BMP com o
tamanho declarado) e (3) pode ser aberto para leitura.

Imagens que já existiam quando o acompanhamento começou (ou no último "novo exame")
nunca são entregues automaticamente — ficam na "linha de base".
"""
from __future__ import annotations

import os
import struct
import time

from .imageio import is_supported


def file_complete(path: str) -> bool:
    try:
        size = os.path.getsize(path)
        if size < 32:
            return False
        ext = os.path.splitext(path)[1].lower()
        with open(path, "rb") as f:
            head = f.read(32)
            f.seek(max(0, size - 16))
            tail = f.read(16)
        if ext == ".png":
            return head.startswith(b"\x89PNG") and b"IEND" in tail
        if ext in (".jpg", ".jpeg"):
            return head.startswith(b"\xff\xd8") and tail.rstrip(b"\x00").endswith(b"\xff\xd9")
        if ext == ".bmp":
            if not head.startswith(b"BM"):
                return False
            declared = struct.unpack("<I", head[2:6])[0]
            return declared == 0 or size >= declared
        return True
    except OSError:
        return False


class FolderScanner:
    """Lógica do acompanhamento (sem threads — testável). Chame tick() periodicamente."""

    def __init__(self, folder: str):
        self.folder = folder
        self.baseline: set[str] = set()
        self.reported: set[str] = set()
        self._pending: dict[str, tuple[int, float, int]] = {}
        self.error = ""

    def _list(self) -> dict[str, tuple[int, float]]:
        out = {}
        with os.scandir(self.folder) as it:
            for e in it:
                if not e.is_file() or not is_supported(e.name) or e.name.startswith("~"):
                    continue
                try:
                    st = e.stat()
                except OSError:
                    continue
                out[e.name] = (st.st_size, st.st_mtime)
        return out

    def reset_baseline(self) -> int:
        """Tudo o que existe agora passa a ser 'antigo'. Retorna quantas imagens há."""
        try:
            files = self._list()
            self.error = ""
        except OSError as e:
            self.error = str(e)
            files = {}
        self.baseline = set(files)
        self.reported.clear()
        self._pending.clear()
        return len(files)

    def existing(self) -> list[str]:
        return sorted(os.path.join(self.folder, n) for n in self.baseline)

    def tick(self) -> list[str]:
        """Retorna caminhos de novas imagens prontas (cada uma só uma vez)."""
        try:
            files = self._list()
            self.error = ""
        except OSError as e:
            self.error = f"Pasta de capturas inacessível: {e.strerror or e}"
            return []
        ready = []
        for name, (size, mtime) in files.items():
            if name in self.baseline or name in self.reported:
                continue
            prev = self._pending.get(name)
            if prev and prev[0] == size and prev[1] == mtime and size > 0:
                stable = prev[2] + 1
            else:
                stable = 0
            self._pending[name] = (size, mtime, stable)
            if stable >= 1:
                path = os.path.join(self.folder, name)
                if file_complete(path):
                    self.reported.add(name)
                    self._pending.pop(name, None)
                    ready.append(path)
        for name in list(self._pending):
            if name not in files:
                del self._pending[name]
        return sorted(ready)


try:
    from PySide6.QtCore import QThread, Signal

    class FolderWatcherThread(QThread):
        """Executa o FolderScanner em segundo plano; emite novas imagens prontas."""
        found = Signal(list)
        problem = Signal(str)

        def __init__(self, folder: str, interval: float = 1.2, parent=None):
            super().__init__(parent)
            self.scanner = FolderScanner(folder)
            self.interval = interval
            self._stop = False
            self._paused = False
            self._reset = False

        def run(self) -> None:
            last_err = ""
            while not self._stop:
                if self._reset:
                    self._reset = False
                    self.scanner.reset_baseline()
                if not self._paused:
                    ready = self.scanner.tick()
                    if ready:
                        self.found.emit(ready)
                    if self.scanner.error != last_err:
                        last_err = self.scanner.error
                        self.problem.emit(last_err)
                t0 = time.monotonic()
                while not self._stop and time.monotonic() - t0 < self.interval:
                    self.msleep(100)

        def request_reset(self) -> None:
            self._reset = True

        def set_paused(self, v: bool) -> None:
            self._paused = v

        def stop(self) -> None:
            self._stop = True
            self.wait(3000)
except ImportError:  # pragma: no cover
    pass
