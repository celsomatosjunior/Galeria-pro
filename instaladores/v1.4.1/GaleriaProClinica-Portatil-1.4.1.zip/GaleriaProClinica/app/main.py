"""Ponto de entrada (usado pelo GaleriaProClinica.exe e em desenvolvimento)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from galeria.app import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
