"""Diálogos: novo exame, histórico, ampliar, recortar, exportar, sobre."""
from __future__ import annotations

import datetime as _dt
import os

from PySide6.QtCore import QDate, QPointF, QRectF, QSize, Qt, Signal, QSortFilterProxyModel
from PySide6.QtGui import (QColor, QImage, QKeySequence, QPainter, QPainterPath, QPen, QPixmap,
                           QShortcut, QStandardItem, QStandardItemModel)
from PySide6.QtWidgets import (QAbstractItemView, QButtonGroup, QCheckBox, QDateEdit, QDialog,
                               QDialogButtonBox, QFormLayout, QHBoxLayout, QHeaderView, QLabel,
                               QLineEdit, QMessageBox, QPushButton, QRadioButton, QSpinBox,
                               QTableView, QVBoxLayout, QWidget)

from .. import APP_NAME, __version__
from ..core import imageio
from ..core.model import Crop, ImageItem
from ..core.store import ExamSummary
from . import icons
from .theme import ACCENT


# ------------------------------------------------------------------ novo exame
class NewExamDialog(QDialog):
    def __init__(self, parent=None, name: str = "", date: _dt.date | None = None,
                 title: str = "Novo exame"):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(460)
        lay = QVBoxLayout(self)
        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        self.name = QLineEdit(name)
        self.name.setObjectName("patientName")
        self.name.setPlaceholderText("Nome completo do paciente")
        self.name.setMaxLength(160)
        self.date = QDateEdit()
        self.date.setCalendarPopup(True)
        self.date.setDisplayFormat("dd/MM/yyyy")
        d = date or _dt.date.today()
        self.date.setDate(QDate(d.year, d.month, d.day))
        form.addRow("Nome do paciente:", self.name)
        form.addRow("Data do exame:", self.date)
        lay.addLayout(form)
        self.err = QLabel("")
        self.err.setObjectName("warn")
        lay.addWidget(self.err)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.button(QDialogButtonBox.StandardButton.Ok).setText("Criar exame" if title == "Novo exame" else "OK")
        bb.button(QDialogButtonBox.StandardButton.Ok).setObjectName("primary")
        bb.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        bb.accepted.connect(self._ok)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _ok(self) -> None:
        if not " ".join(self.name.text().split()):
            self.err.setText("Informe o nome do paciente.")
            self.name.setFocus()
            return
        self.accept()

    def values(self) -> tuple[str, str]:
        q = self.date.date()
        return " ".join(self.name.text().split()), _dt.date(q.year(), q.month(), q.day()).isoformat()


# ------------------------------------------------------------------ histórico
class _Proxy(QSortFilterProxyModel):
    def __init__(self):
        super().__init__()
        self.text = ""
        self.date: str | None = None

    def filterAcceptsRow(self, row, parent):
        m = self.sourceModel()
        name = (m.index(row, 1, parent).data() or "").lower()
        iso = m.index(row, 0, parent).data(Qt.ItemDataRole.UserRole) or ""
        if self.text and not all(t in _fold(name) for t in _fold(self.text).split()):
            return False
        if self.date and iso != self.date:
            return False
        return True


def _fold(s: str) -> str:
    import unicodedata
    s = unicodedata.normalize("NFKD", s or "")
    return "".join(c for c in s if not unicodedata.combining(c)).lower()


class OpenExamDialog(QDialog):
    def __init__(self, summaries: list[ExamSummary], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Abrir exame")
        self.resize(780, 520)
        self.chosen: ExamSummary | None = None
        self.action = "abrir"
        lay = QVBoxLayout(self)
        top = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Buscar por nome do paciente…")
        self.search.setClearButtonEnabled(True)
        self.use_date = QCheckBox("Filtrar pela data:")
        self.date = QDateEdit(QDate.currentDate())
        self.date.setCalendarPopup(True)
        self.date.setDisplayFormat("dd/MM/yyyy")
        self.date.setEnabled(False)
        top.addWidget(self.search, 1)
        top.addWidget(self.use_date)
        top.addWidget(self.date)
        lay.addLayout(top)

        self.model = QStandardItemModel(0, 4)
        self.model.setHorizontalHeaderLabels(["Data", "Paciente", "Fotos", "Páginas"])
        self._by_row: list[ExamSummary] = []
        for s in summaries:
            d = QStandardItem(s.date_br())
            d.setData(s.date, Qt.ItemDataRole.UserRole)
            d.setData(s.date + s.saved_at, Qt.ItemDataRole.UserRole + 2)
            name = s.patient + ("   (rascunho não salvo)" if s.never_saved else "") + \
                ("   (danificado)" if s.damaged else "")
            n = QStandardItem(name)
            f = QStandardItem(f"{s.selected} de {s.images}" if s.images else "0")
            f.setData(s.images, Qt.ItemDataRole.UserRole + 2)
            p = QStandardItem(str(s.pages))
            p.setData(s.pages, Qt.ItemDataRole.UserRole + 2)
            for it in (d, n, f, p):
                it.setEditable(False)
                it.setData(len(self._by_row), Qt.ItemDataRole.UserRole + 1)
            self.model.appendRow([d, n, f, p])
            self._by_row.append(s)
        self.proxy = _Proxy()
        self.proxy.setSourceModel(self.model)
        self.proxy.setSortRole(Qt.ItemDataRole.UserRole + 2)
        self.table = QTableView()
        self.table.setModel(self.proxy)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setSortingEnabled(True)
        self.table.sortByColumn(0, Qt.SortOrder.DescendingOrder)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        h = self.table.horizontalHeader()
        h.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        lay.addWidget(self.table, 1)
        self.count = QLabel("")
        self.count.setObjectName("hint")
        lay.addWidget(self.count)

        bb = QHBoxLayout()
        self.b_pdf = QPushButton(icons.icon("pdf"), "Gerar PDF")
        self.b_print = QPushButton(icons.icon("print"), "Imprimir")
        self.b_open = QPushButton(icons.icon("open", "#FFFFFF"), "Abrir / continuar")
        self.b_open.setObjectName("primary")
        cancel = QPushButton("Fechar")
        bb.addWidget(self.b_pdf)
        bb.addWidget(self.b_print)
        bb.addStretch(1)
        bb.addWidget(cancel)
        bb.addWidget(self.b_open)
        lay.addLayout(bb)
        cancel.clicked.connect(self.reject)
        self.b_open.clicked.connect(lambda: self._done("abrir"))
        self.b_pdf.clicked.connect(lambda: self._done("pdf"))
        self.b_print.clicked.connect(lambda: self._done("imprimir"))
        self.table.doubleClicked.connect(lambda _ix: self._done("abrir"))
        self.search.textChanged.connect(self._filter)
        self.use_date.toggled.connect(self._filter)
        self.use_date.toggled.connect(self.date.setEnabled)
        self.date.dateChanged.connect(self._filter)
        self.table.selectionModel().selectionChanged.connect(self._sel)
        self._filter()
        if self.proxy.rowCount():
            self.table.selectRow(0)
        self._sel()
        self.search.setFocus()

    def _filter(self, *_):
        self.proxy.text = self.search.text().strip()
        q = self.date.date()
        self.proxy.date = (_dt.date(q.year(), q.month(), q.day()).isoformat()
                           if self.use_date.isChecked() else None)
        self.proxy.invalidate()
        self.count.setText(f"{self.proxy.rowCount()} exame(s)")
        if self.proxy.rowCount() and not self.table.selectionModel().hasSelection():
            self.table.selectRow(0)
        self._sel()

    def _sel(self, *_):
        ok = self.table.selectionModel().hasSelection()
        for b in (self.b_open, self.b_pdf, self.b_print):
            b.setEnabled(ok)

    def _done(self, action: str) -> None:
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return
        k = rows[0].data(Qt.ItemDataRole.UserRole + 1)
        self.chosen = self._by_row[k]
        if self.chosen.damaged and action != "abrir":
            QMessageBox.warning(self, "Exame danificado", "Abra o exame primeiro para tentar recuperá-lo.")
            return
        self.action = action
        self.accept()


# ------------------------------------------------------------------ ampliar
class ImageViewer(QDialog):
    """Ampliação para inspeção: roda do mouse = zoom, arrastar = mover, Esc fecha."""

    def __init__(self, img: QImage, title: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.img = img
        self.scale = 1.0
        self.offset = QPointF(0, 0)
        self.fit = True
        self._drag = None
        self.resize(1100, 800)
        self.setStyleSheet("background:#111418;")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.info = QLabel(f"{img.width()} × {img.height()} pixels   ·   roda do mouse: ampliar   ·   "
                           "arrastar: mover   ·   duplo clique: ajustar   ·   Esc: fechar")
        self.info.setStyleSheet("color:#C9D1DB;padding:6px 10px;background:#1B2027;")
        lay.addStretch(1)
        lay.addWidget(self.info)
        QShortcut(QKeySequence(Qt.Key.Key_Escape), self, self.close)

    def _fit_scale(self) -> float:
        h = self.height() - self.info.height()
        return min(self.width() / self.img.width(), h / self.img.height())

    def paintEvent(self, e):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor("#111418"))
        h = self.height() - self.info.height()
        if self.fit:
            self.scale = self._fit_scale()
            self.offset = QPointF((self.width() - self.img.width() * self.scale) / 2,
                                  (h - self.img.height() * self.scale) / 2)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, self.scale < 2)
        p.drawImage(QRectF(self.offset.x(), self.offset.y(), self.img.width() * self.scale,
                           self.img.height() * self.scale), self.img)

    def wheelEvent(self, e):
        f = 1.2 if e.angleDelta().y() > 0 else 1 / 1.2
        pos = e.position()
        new = max(0.05, min(16.0, self.scale * f))
        self.offset = pos - (pos - self.offset) * (new / self.scale)
        self.scale = new
        self.fit = False
        self.update()

    def mousePressEvent(self, e):
        self._drag = e.position()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            self.offset += e.position() - self._drag
            self._drag = e.position()
            self.fit = False
            self.update()

    def mouseReleaseEvent(self, e):
        self._drag = None

    def mouseDoubleClickEvent(self, e):
        self.fit = True
        self.update()


# ------------------------------------------------------------------ recortar / girar
class CropCanvas(QWidget):
    changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(560, 420)
        self.setMouseTracking(True)
        self.img: QImage | None = None    # imagem já girada
        self.crop = Crop()
        self._drag = None
        self._start = None
        self._crop0 = None

    def set_image(self, img: QImage, crop: Crop) -> None:
        self.img = img
        self.crop = crop
        self.update()

    def _img_rect(self) -> QRectF:
        if not self.img:
            return QRectF()
        s = min((self.width() - 20) / self.img.width(), (self.height() - 20) / self.img.height())
        w, h = self.img.width() * s, self.img.height() * s
        return QRectF((self.width() - w) / 2, (self.height() - h) / 2, w, h)

    def _crop_rect(self) -> QRectF:
        r = self._img_rect()
        c = self.crop
        return QRectF(r.x() + c.x * r.width(), r.y() + c.y * r.height(), c.w * r.width(), c.h * r.height())

    def paintEvent(self, e):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor("#20252C"))
        if not self.img:
            return
        ir = self._img_rect()
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        p.drawImage(ir, self.img)
        cr = self._crop_rect()
        path = QPainterPath()
        path.addRect(ir)
        inner = QPainterPath()
        inner.addRect(cr)
        p.fillPath(path.subtracted(inner), QColor(0, 0, 0, 140))
        p.setPen(QPen(QColor("#4FC3F7"), 2))
        p.drawRect(cr)
        p.setBrush(QColor("#4FC3F7"))
        for pt in self._handles(cr).values():
            p.drawRect(QRectF(pt.x() - 5, pt.y() - 5, 10, 10))

    @staticmethod
    def _handles(cr: QRectF) -> dict:
        return {"tl": cr.topLeft(), "tr": cr.topRight(), "bl": cr.bottomLeft(), "br": cr.bottomRight(),
                "t": QPointF(cr.center().x(), cr.top()), "b": QPointF(cr.center().x(), cr.bottom()),
                "l": QPointF(cr.left(), cr.center().y()), "r": QPointF(cr.right(), cr.center().y())}

    def mousePressEvent(self, e):
        pos = e.position()
        cr = self._crop_rect()
        for k, pt in self._handles(cr).items():
            if abs(pt.x() - pos.x()) <= 9 and abs(pt.y() - pos.y()) <= 9:
                self._drag = k
                break
        else:
            self._drag = "move" if cr.contains(pos) else "new"
        self._start = pos
        self._crop0 = Crop(self.crop.x, self.crop.y, self.crop.w, self.crop.h)

    def mouseMoveEvent(self, e):
        if not self._drag or not self.img:
            return
        ir = self._img_rect()
        dx = (e.position().x() - self._start.x()) / ir.width()
        dy = (e.position().y() - self._start.y()) / ir.height()
        c0 = self._crop0
        x0, y0, x1, y1 = c0.x, c0.y, c0.x + c0.w, c0.y + c0.h
        k = self._drag
        if k == "move":
            w, h = c0.w, c0.h
            nx = min(max(0.0, x0 + dx), 1 - w)
            ny = min(max(0.0, y0 + dy), 1 - h)
            x0, y0, x1, y1 = nx, ny, nx + w, ny + h
        elif k == "new":
            sx = (self._start.x() - ir.x()) / ir.width()
            sy = (self._start.y() - ir.y()) / ir.height()
            ex = sx + dx
            ey = sy + dy
            x0, x1 = sorted((sx, ex))
            y0, y1 = sorted((sy, ey))
        else:
            if "l" in k:
                x0 += dx
            if "r" in k:
                x1 += dx
            if "t" in k:
                y0 += dy
            if "b" in k:
                y1 += dy
        x0, x1 = max(0.0, min(x0, 1.0)), max(0.0, min(x1, 1.0))
        y0, y1 = max(0.0, min(y0, 1.0)), max(0.0, min(y1, 1.0))
        if x1 - x0 < 0.03 or y1 - y0 < 0.03:
            return
        self.crop = Crop(x0, y0, x1 - x0, y1 - y0)
        self.changed.emit()
        self.update()

    def mouseReleaseEvent(self, e):
        self._drag = None


class CropDialog(QDialog):
    """Recorte e rotação não destrutivos (o arquivo original não é alterado)."""

    def __init__(self, item: ImageItem, path: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Recortar e girar — {item.original_name}")
        self.resize(980, 720)
        self.item = item
        try:
            self.base = imageio.load_scaled(path, 1800)
        except (ValueError, OSError) as e:
            self.base = None
            QMessageBox.warning(parent, "Imagem", f"Não foi possível abrir a imagem: {e}")
        self.rotation = item.rotation
        self.result_crop = Crop(item.crop.x, item.crop.y, item.crop.w, item.crop.h)
        lay = QVBoxLayout(self)
        tip = QLabel("Arraste os cantos ou as bordas para recortar; arraste por dentro para mover. "
                     "O arquivo original nunca é alterado.")
        tip.setObjectName("hint")
        lay.addWidget(tip)
        self.canvas = CropCanvas()
        lay.addWidget(self.canvas, 1)
        row = QHBoxLayout()
        bl = QPushButton(icons.icon("rotate_l"), "Girar à esquerda")
        br = QPushButton(icons.icon("rotate"), "Girar à direita")
        bfull = QPushButton("Imagem inteira")
        brest = QPushButton(icons.icon("restore"), "Restaurar original")
        self.size_lbl = QLabel("")
        self.size_lbl.setObjectName("muted")
        for b in (bl, br, bfull, brest):
            row.addWidget(b)
        row.addStretch(1)
        row.addWidget(self.size_lbl)
        lay.addLayout(row)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.button(QDialogButtonBox.StandardButton.Ok).setText("Aplicar")
        bb.button(QDialogButtonBox.StandardButton.Ok).setObjectName("primary")
        bb.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        bl.clicked.connect(lambda: self._rotate(-90))
        br.clicked.connect(lambda: self._rotate(90))
        bfull.clicked.connect(self._full)
        brest.clicked.connect(self._restore)
        self.canvas.changed.connect(self._upd)
        self._show()

    def _rotated(self) -> QImage | None:
        if self.base is None:
            return None
        from PySide6.QtGui import QTransform
        return self.base.transformed(QTransform().rotate(self.rotation)) if self.rotation else self.base

    def _show(self) -> None:
        img = self._rotated()
        if img is not None:
            self.canvas.set_image(img, self.result_crop)
        self._upd()

    def _upd(self) -> None:
        self.result_crop = self.canvas.crop
        tmp = ImageItem(**{**self.item.__dict__})
        tmp.rotation, tmp.crop = self.rotation, self.result_crop
        w, h = tmp.edited_size()
        self.size_lbl.setText(f"Resultado: {int(w)} × {int(h)} pixels")

    def _rotate(self, deg: int) -> None:
        c = self.canvas.crop
        # gira também o retângulo de recorte, para manter a mesma região
        if deg == 90:
            nc = Crop(1 - c.y - c.h, c.x, c.h, c.w)
        else:
            nc = Crop(c.y, 1 - c.x - c.w, c.h, c.w)
        self.rotation = (self.rotation + deg) % 360
        self.result_crop = nc.normalized()
        self._show()

    def _full(self) -> None:
        self.result_crop = Crop()
        self._show()

    def _restore(self) -> None:
        self.rotation = 0
        self.result_crop = Crop()
        self._show()


# ------------------------------------------------------------------ páginas p/ PDF
def parse_pages(text: str, n: int) -> list[int] | None:
    """'1-3, 5' → [0,1,2,4] (índices). None se inválido."""
    out: list[int] = []
    for part in (text or "").replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, _, b = part.partition("-")
            if not a.strip().isdigit() or not b.strip().isdigit():
                return None
            a, b = int(a), int(b)
            if a > b:
                a, b = b, a
            rng = range(a, b + 1)
        elif part.isdigit():
            rng = [int(part)]
        else:
            return None
        for k in rng:
            if not 1 <= k <= n:
                return None
            if k - 1 not in out:
                out.append(k - 1)
    return sorted(out) or None


class PagesChoiceDialog(QDialog):
    def __init__(self, n: int, title: str, parent=None, copies: bool = False):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.n = n
        lay = QVBoxLayout(self)
        self.all = QRadioButton(f"Todas as páginas ({n})")
        self.some = QRadioButton("Páginas:")
        self.all.setChecked(True)
        grp = QButtonGroup(self)
        grp.addButton(self.all)
        grp.addButton(self.some)
        self.txt = QLineEdit()
        self.txt.setPlaceholderText("ex.: 1-3, 5")
        self.txt.textEdited.connect(lambda _t: self.some.setChecked(True))
        lay.addWidget(self.all)
        row = QHBoxLayout()
        row.addWidget(self.some)
        row.addWidget(self.txt, 1)
        lay.addLayout(row)
        self.copies = None
        if copies:
            r2 = QHBoxLayout()
            r2.addWidget(QLabel("Cópias:"))
            self.copies = QSpinBox()
            self.copies.setRange(1, 99)
            r2.addWidget(self.copies)
            r2.addStretch(1)
            lay.addLayout(r2)
        self.err = QLabel("")
        self.err.setObjectName("warn")
        lay.addWidget(self.err)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.button(QDialogButtonBox.StandardButton.Ok).setObjectName("primary")
        bb.button(QDialogButtonBox.StandardButton.Ok).setText("Continuar")
        bb.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        bb.accepted.connect(self._ok)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.pages: list[int] = list(range(n))

    def _ok(self):
        if self.some.isChecked():
            p = parse_pages(self.txt.text(), self.n)
            if p is None:
                self.err.setText(f"Informe páginas entre 1 e {self.n} (ex.: 1-3, 5).")
                return
            self.pages = p
        self.accept()


# ------------------------------------------------------------------ sobre
class AboutDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Sobre o {APP_NAME}")
        self.setMinimumWidth(460)
        lay = QVBoxLayout(self)
        t = QLabel(f"<b style='font-size:15pt'>{APP_NAME}</b><br>Versão {__version__}")
        lay.addWidget(t)
        body = QLabel(
            "Organiza fotografias de exames, monta folhas A4 com a identidade visual da clínica "
            "e imprime ou gera PDF — 100% offline, sem login e sem internet.<br><br>"
            "Complementar ao Capture Pro: acompanha a pasta de capturas, sem alterar aquele programa.<br><br>"
            "As imagens originais nunca são alteradas: recortes e rotações ficam guardados como "
            "instruções dentro do exame.<br><br>"
            "Autor: Dr. Celso Matos do Nascimento Junior.<br>"
            "Componentes de terceiros e licenças: arquivo AVISOS-DE-TERCEIROS.md na pasta do programa.")
        body.setWordWrap(True)
        lay.addWidget(body)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        bb.button(QDialogButtonBox.StandardButton.Close).setText("Fechar")
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)


_unused = (QSize, QPixmap, ACCENT, os)


# ------------------------------------------------------------------ escolher foto (sem arrastar)
class PhotoPickerDialog(QDialog):
    """Escolhe uma foto da galeria para uma célula. Fotos já na impressão aparecem com a
    posição atual (escolhê-las MOVE ou TROCA a foto — nunca duplica)."""

    def __init__(self, exam, thumbs, title: str, parent=None):
        super().__init__(parent)
        from PySide6.QtWidgets import QListWidget, QListWidgetItem, QListView
        self.setWindowTitle(title)
        self.resize(820, 600)
        self.chosen: str | None = None
        lay = QVBoxLayout(self)
        tip = QLabel("Duplo clique para escolher. Fotos marcadas com “P·posição” já estão na impressão: "
                     "escolhê-las move ou troca de lugar.")
        tip.setObjectName("hint")
        tip.setWordWrap(True)
        lay.addWidget(tip)
        self.only_free = QCheckBox("Mostrar só as fotos ainda não usadas na impressão")
        self.only_free.setChecked(False)          # 1.4: qualquer foto pode ser usada de novo
        lay.addWidget(self.only_free)
        self.list = QListWidget()
        self.list.setViewMode(QListView.ViewMode.IconMode)
        self.list.setIconSize(QSize(150, 112))
        self.list.setGridSize(QSize(170, 150))
        self.list.setResizeMode(QListView.ResizeMode.Adjust)
        self.list.setMovement(QListView.Movement.Static)
        lay.addWidget(self.list, 1)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.button(QDialogButtonBox.StandardButton.Ok).setText("Escolher")
        bb.button(QDialogButtonBox.StandardButton.Ok).setObjectName("primary")
        bb.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        bb.accepted.connect(self._ok)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.exam, self.thumbs = exam, thumbs
        self._items: dict[str, QListWidgetItem] = {}
        self._QLWI = QListWidgetItem
        self.list.itemDoubleClicked.connect(lambda _i: self._ok())
        self.only_free.toggled.connect(self._fill)
        thumbs.ready.connect(self._thumb)
        self._fill()

    def _fill(self, *_):
        self.list.clear()
        self._items.clear()
        occ = self.exam.occurrences()
        for it in self.exam.images:
            if self.only_free.isChecked() and it.id in occ:
                continue
            label = it.original_name
            if it.id in occ:
                label += f"\n(usada {len(occ[it.id])}×)"
            item = self._QLWI(label)
            item.setData(Qt.ItemDataRole.UserRole, it.id)
            pm = self.thumbs.get(it)
            if pm is not None:
                item.setIcon(pm)
            self.list.addItem(item)
            self._items[it.id] = item
        if not self._items and self.only_free.isChecked():
            self.only_free.setText("Mostrar só as fotos ainda não usadas — todas já estão na impressão")

    def _thumb(self, iid: str):
        item = self._items.get(iid)
        it = self.exam.image(iid)
        if item is not None and it is not None:
            pm = self.thumbs.get(it)
            if pm is not None:
                item.setIcon(pm)

    def _ok(self):
        cur = self.list.currentItem()
        if cur is None:
            return
        self.chosen = cur.data(Qt.ItemDataRole.UserRole)
        self.accept()
