"""Autoteste de ponta a ponta (uso técnico): GaleriaProClinica.exe --autoteste <pasta>

Na <pasta> devem existir imagens (PNG/JPEG/BMP). O teste usa uma configuração e uma pasta
de exames temporárias dentro de <pasta>\\autoteste_saida — não toca nos dados reais.
Resultado: autoteste_saida\\relatorio.txt, tela.png e exemplo.pdf.
"""
from __future__ import annotations

import glob
import os
import time
import traceback


def run(win, src: str, out: str, app) -> int:
    from .core import composition as C
    from .core.store import ExamStore
    lines = []

    def ok(msg):
        lines.append("OK    " + msg)

    def pump(t=0.5):
        t0 = time.time()
        while time.time() - t0 < t:
            app.processEvents()
            time.sleep(0.01)

    try:
        files = sorted(f for e in ("*.png", "*.jpg", "*.jpeg", "*.bmp") for f in glob.glob(os.path.join(src, e)))
        assert files, "sem imagens na pasta"
        ex, folder = win.store().create("PACIENTE AUTOTESTE", "2026-10-20", win.s.identity(),
                                        win.s.logo_file(), "6")
        win.set_exam(ex, folder)
        ok(f"exame criado em {folder}")
        win.import_paths(files)
        t0 = time.time()
        while win.importers and time.time() - t0 < 120:
            pump(0.2)
        assert len(win.exam.images) == len(set(files)), f"importadas {len(win.exam.images)} de {len(files)}"
        ok(f"{len(win.exam.images)} imagens importadas em segundo plano")
        gal = [it.id for it in win.exam.images]
        from PySide6.QtCore import QEvent, QPointF, Qt
        from PySide6.QtGui import QMouseEvent
        from PySide6.QtWidgets import QApplication

        def mouse(row, seq):
            ix = win.gmodel.index(row)
            win.gview.scrollTo(ix)
            pump(0.05)
            vp = win.gview.viewport()
            pos = QPointF(win.gview.visualRect(ix).center())
            for t in seq:
                btns = Qt.MouseButton.NoButton if t == QEvent.Type.MouseButtonRelease else Qt.MouseButton.LeftButton
                QApplication.sendEvent(vp, QMouseEvent(t, pos, vp.mapToGlobal(pos.toPoint()).toPointF(),
                                                       Qt.MouseButton.LeftButton, btns, Qt.KeyboardModifier.NoModifier))
                pump(0.02)

        def click(row):
            mouse(row, (QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonRelease))

        def used():
            return [it.id for it in win.exam.sequence()]

        # 1. um clique acrescenta; outro clique na mesma foto acrescenta OUTRA ocorrência (1.4)
        click(0)
        assert used() == [gal[0]], "clique não incluiu"
        click(0)
        assert used() == [gal[0], gal[0]] and len(win.exam.images) == len(gal), "2º clique não repetiu"
        ok("1. um clique inclui a foto; o 2º clique na mesma foto a inclui de novo")
        # 1b. cliques rápidos (duplo clique do Windows) contam todos; a lupa amplia sem mudar nada
        from .ui import main_window as mw
        opened = []
        orig_exec = mw.ImageViewer.exec
        mw.ImageViewer.exec = lambda self: opened.append(1) or 0
        win.clear_composition()
        mouse(1, (QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonRelease,
                  QEvent.Type.MouseButtonDblClick, QEvent.Type.MouseButtonRelease))
        assert used() == [gal[1], gal[1]] and not opened, "duplo clique não contou 2 cliques"
        ix = win.gmodel.index(2)
        lp = QPointF(win.gview.delegate.lupa_rect(win.gview.visualRect(ix)).center())
        vp = win.gview.viewport()
        for t in (QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonRelease):
            btns = Qt.MouseButton.NoButton if t == QEvent.Type.MouseButtonRelease else Qt.MouseButton.LeftButton
            QApplication.sendEvent(vp, QMouseEvent(t, lp, vp.mapToGlobal(lp.toPoint()).toPointF(),
                                                   Qt.MouseButton.LeftButton, btns, Qt.KeyboardModifier.NoModifier))
        pump(0.05)
        mw.ImageViewer.exec = orig_exec
        assert opened and used() == [gal[1], gal[1]], "lupa alterou a impressão"
        ok("1b. dois cliques rápidos = 2 ocorrências; a lupa amplia sem mexer na impressão")
        win.clear_composition()
        # 2. seleção manual de 6 fotos por clique
        if len(gal) >= 6:
            for r in range(6):
                time.sleep(0.05)
                click(r)
            assert used() == gal[:6] and len(win.exam.pages) == 1, "seleção manual de 6"
            ok("2. seis fotos selecionadas com um clique cada: página 1 completa")
        else:
            lines.append("NÃO TESTADO  2. seleção manual de 6 (menos de 6 imagens)")
        # 3-4. automático 10 em 6
        want = min(10, len(gal))
        win.mutate("autoteste: selecionar fotos", lambda: C.auto_select(win.exam, gal, want, "6", "refazer"))
        n = len(used())
        assert n == want, f"seleção automática: {n} de {want}"
        per_page = [len(p.used()) for p in win.exam.pages]
        ok(f"3-4. Selecionar fotos ({want}, 6 por página): fotos por página = {per_page}")
        # 5. duas manuais por clique ocupam a página 2
        rest = [k for k, i in enumerate(gal) if not win.exam.is_used(i)]
        if len(rest) >= 2 and want == 10:
            time.sleep(0.6)
            click(rest[0])
            time.sleep(0.6)
            click(rest[1])
            assert win.exam.pages[1].slots[4:] == [gal[rest[0]], gal[rest[1]]], "manuais na página 2"
            ok("5. duas fotos acrescentadas por clique completaram a página 2")
        else:
            lines.append("NÃO TESTADO  5. inclusão manual na página 2 (são precisas 12 imagens)")
        # 6. trocar a ordem
        a, b = win.exam.pages[0].slots[0], win.exam.pages[-1].slots[0]
        win.drop_cell_on_cell(0, 0, len(win.exam.pages) - 1, 0)   # arrastar uma ocorrência na prévia
        assert win.exam.pages[0].slots[0] == b and win.exam.pages[-1].slots[0] == a, "troca"
        ok("6. duas fotos trocadas de posição (arrastar uma sobre a outra)")
        # 7. retirar uma da impressão sem apagar da galeria (na prévia: célula + Delete)
        victim = win.exam.pages[0].slots[2]
        cv = win.preview.canvas
        cv.select_cell((0, 2))
        cv.setFocus()
        _key(cv, Qt.Key.Key_Delete)
        assert not win.exam.is_used(victim) and win.exam.image(victim) is not None
        assert os.path.isfile(os.path.join(folder, win.exam.image(victim).file))
        s2 = used()
        ok(f"7. foto retirada da impressão (prévia + Delete); continua na galeria e no disco; {len(s2)} na impressão")
        pump(2)
        win.grab().save(os.path.join(out, "tela.png"))
        ok("captura de tela gravada")
        from .render import compose, output
        prov = compose.FileImageProvider(folder, ExamStore.logo_path(win.exam, folder))
        pdf = os.path.join(out, "exemplo.pdf")
        w = output.export_pdf(win.exam, prov, pdf)
        assert os.path.getsize(pdf) > 1000
        ok(f"8. PDF gerado ({os.path.getsize(pdf)} bytes), {len(win.exam.pages)} página(s), avisos={w}")
        # 9. repetição: seleção/troca de modelo/PDF várias vezes
        for k in range(5):
            win.mutate("rep", lambda k=k: C.auto_select(win.exam, gal, min(len(gal), 4 + k), ["6", "9", "12", "2", "1"][k], "refazer"))
            n0 = len(used())
            for r in range(0, len(gal), 3):
                click(r)
                time.sleep(0.02)
            assert len(used()) == n0 + len(range(0, len(gal), 3)), "clique perdido na repetição"
            output.export_pdf(win.exam, prov, os.path.join(out, f"repeticao_{k}.pdf"))
        assert len(win.exam.images) == len(gal)
        ok("9. cinco ciclos de seleção/troca de modelo/cliques/PDF sem perda nem travamento")
        # ---------------- 1.3: regressão das páginas independentes (6 / 9 / 12)
        if len(gal) >= 27:
            win.clear_composition()
            win.exam.pages = []
            win._changed()
            for t, rows in (("6", range(0, 6)), ("9", range(6, 15)), ("12", range(15, 27))):
                if win.exam.pages:
                    win.new_page_at_end(t)
                else:
                    win.apply_template_page(t)
                for r in rows:
                    click(r)
                    time.sleep(0.02)
            assert [p.template for p in win.exam.pages] == ["6", "9", "12"], "modelos 6/9/12"
            assert [len(p.used()) for p in win.exam.pages] == [6, 9, 12], "fotos 6/9/12"
            snap = [list(p.slots) for p in win.exam.pages]
            ok("R. páginas montadas uma a uma: 6, 9 e 12 fotos")
            for _ in range(5):
                for i, t in ((0, "6"), (1, "9"), (2, "12"), (1, "9")):
                    win.go_page(i)
                    pump(0.02)
                    assert win.cb_model.currentData() == t and win.pages.chosen() == t
            assert [list(p.slots) for p in win.exam.pages] == snap
            ok("R1-2. alternando entre as páginas, cada uma mostra e conserva o seu modelo")
            win.go_page(1)
            win.clear_current_page()
            assert win.exam.pages[1].used() == [] and win.exam.pages[1].template == "9"
            assert [list(p.slots) for p in win.exam.pages][0::2] == snap[0::2]
            ok("R3-4. LIMPAR PÁGINA 2: só a página 2 esvaziou; 1 e 3 intactas; galeria intacta")
            win.undo()
            assert [list(p.slots) for p in win.exam.pages] == snap
            ok("R5. Ctrl+Z restaurou a página 2")
            win.go_page(2)
            win._ask_excess = lambda n, where, tpl: "nova_pagina"
            win.apply_template_page("9")
            del win._ask_excess
            assert [list(p.slots) for p in win.exam.pages][:2] == snap[:2]
            assert [p.template for p in win.exam.pages] == ["6", "9", "9", "12"]
            ok("R7. página 3 mudou para 9 (excedentes numa página nova no final); 1 e 2 intactas")
            win.undo()
            assert win.save_exam()
            win.set_exam(None, "")
            assert win.load_exam(folder, prefer_draft=False)
            assert [p.template for p in win.exam.pages] == ["6", "9", "12"]
            assert [list(p.slots) for p in win.exam.pages] == snap
            ok("R8-9. salvo, fechado e reaberto: modelos 6/9/12 e posições preservados")
            prov = compose.FileImageProvider(folder, ExamStore.logo_path(win.exam, folder))
            pdf_r = os.path.join(out, "regressao_6_9_12.pdf")
            output.export_pdf(win.exam, prov, pdf_r)
            from pypdf import PdfReader
            import re as _re
            counts = [len(_re.findall(rb"/Im\w*\s+Do\b", pg.get_contents().get_data()))
                      for pg in PdfReader(pdf_r).pages]
            assert counts == [6, 9, 12], counts
            ok(f"R10. PDF com 3 páginas: imagens por página = {counts}")
        else:
            lines.append("NÃO TESTADO  regressão 6/9/12 (são precisas pelo menos 27 imagens)")
        assert win.save_exam()
        flow = [list(p.slots) for p in win.exam.pages]
        win.set_exam(None, "")
        assert win.load_exam(folder, prefer_draft=False)
        assert [list(p.slots) for p in win.exam.pages] == flow
        ok("salvo e reaberto com as mesmas posições e células vazias")
        _reuse(win, files, pump, ok, mouse, used, out)
        _stability(win, files, pump, ok, lines)
        from PySide6.QtPrintSupport import QPrinterInfo
        ok("impressoras visíveis: " + (", ".join(QPrinterInfo.availablePrinterNames()) or "(nenhuma)"))
        rc = 0
    except Exception:
        lines.append("FALHA " + traceback.format_exc())
        rc = 1
    with open(os.path.join(out, "relatorio.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return rc


def _key(widget, key) -> None:
    """Tecla real (pressionar e soltar) enviada ao componente — sem o módulo QtTest, que não
    faz parte da distribuição."""
    from PySide6.QtCore import QEvent, Qt
    from PySide6.QtGui import QKeyEvent
    from PySide6.QtWidgets import QApplication
    for t in (QEvent.Type.KeyPress, QEvent.Type.KeyRelease):
        QApplication.sendEvent(widget, QKeyEvent(t, key, Qt.KeyboardModifier.NoModifier))
    QApplication.processEvents()


def _stability(win, files, pump, ok, lines) -> None:
    """1.3.1 — estabilidade visual (piscadas). Exame pequeno (8 fotos, como no vídeo da 1.3.0)
    e a galeria varrida pixel a pixel na faixa em que a 1.3.0 oscilava; o programa parado não
    pode continuar se redesenhando. Mede também o tempo de processador parado."""
    import collections
    from PySide6.QtCore import QEvent, QObject
    from PySide6.QtWidgets import QApplication
    ex, folder = win.store().create("AUTOTESTE ESTABILIDADE", "2026-10-20", win.s.identity(),
                                    win.s.logo_file(), "6")
    win.set_exam(ex, folder)
    win.import_paths(files[:8])
    t0 = time.time()
    while (win.importers or win.thumbs.pending_count()) and time.time() - t0 < 60:
        pump(0.1)
    counts = collections.Counter()
    names = {id(win.gview.viewport()): "galeria", id(win.preview.canvas): "previa"}

    class Spy(QObject):
        def eventFilter(self, obj, e):
            if e.type() in (QEvent.Type.Paint, QEvent.Type.Resize):
                counts[(names.get(id(obj), "outros"), e.type().name)] += 1
            return False
    spy = Spy()
    app = QApplication.instance()
    win.gview.setFocus()        # o cursor de texto piscando no campo do paciente não conta
    app.installEventFilter(spy)
    unstable, n = [], 0
    try:
        win.showNormal()
        for hh in (860, 1000):
            win.resize(1920, hh)
            pump(0.3)
            for gw in range(250, 760, 2):
                sz = win.split.sizes()
                win.split.setSizes([gw, sum(sz) - gw - sz[2], sz[2]])
                pump(0.08)
                counts.clear()
                pump(0.12)
                n += 1
                if counts[("galeria", "Paint")] > 1 or counts[("previa", "Paint")] > 1 or counts[("galeria", "Resize")]:
                    pump(0.2)
                    counts.clear()
                    pump(0.6)
                    if counts[("galeria", "Paint")] > 1 or counts[("previa", "Paint")] > 1:
                        unstable.append((win.gview.width(), hh, dict(counts)))
        assert not unstable, f"redesenho contínuo: {unstable[:4]}"
        ok(f"E1. estabilidade: {n} larguras da galeria (2 alturas de janela), nenhuma com redesenho contínuo")
        # parado: 3 s sem nenhuma interação
        win.resize(1920, 860)
        sz = win.split.sizes()
        win.split.setSizes([470, sum(sz) - 470 - sz[2], sz[2]])
        pump(0.5)
        counts.clear()
        c0, t0 = time.process_time(), time.time()
        pump(3.0)
        cpu = 100 * (time.process_time() - c0) / (time.time() - t0)
        paints = sum(v for (k, t), v in counts.items() if t == "Paint")
        assert paints <= 3 and cpu < 20, f"parado: {paints} redesenhos, CPU {cpu:.1f}%"
        ok(f"E2. 3 s parado (galeria {win.gview.width()} px): {paints} redesenho(s), CPU {cpu:.1f}% de um núcleo")
        # seleção e desmarcação repetidas, troca 6/9/12, navegação: assenta após cada operação
        g = [it.id for it in win.exam.images]
        bad = []
        for k in range(13):
            win._gallery_click(g[k % 8])
            pump(0.03)
        for t in ("6", "9", "12", "9", "6", "12"):
            win.apply_template_page(t)
            pump(0.05)
        for i in range(3):
            win.new_page_at_end(("6", "9", "12")[i])
        transient = 0
        for i in (0, 1, 2, 3, 1, 0):
            win.go_page(i)
            pump(0.3)
            counts.clear()
            pump(0.5)
            if sum(v for (k, t), v in counts.items() if t == "Paint") > 3:
                # atualização única (aviso que se fecha sozinho, rascunho salvo) termina;
                # um laço de redesenho continua: confirma em 1 s
                transient += 1
                pump(0.3)
                counts.clear()
                pump(1.0)
                if sum(v for (k, t), v in counts.items() if t == "Paint") > 3:
                    bad.append((i, dict(counts)))
        assert not bad, bad
        ok("E3. depois de 13 cliques, trocas 6/9/12 e navegação, a janela assenta e fica parada"
           + (f" ({transient} atualização(ões) única(s) — aviso fechando/rascunho salvo — que terminaram sozinhas)"
              if transient else ""))
    finally:
        app.removeEventFilter(spy)
        win.dirty = False
        win.set_exam(None, "")


def _reuse(win, files, pump, ok, mouse, used, out) -> None:
    """1.4 — fotos reutilizáveis (testes obrigatórios 1-10 e o critério dos 10 cliques)."""
    import re as _re
    from PySide6.QtCore import QEvent, Qt
    from pypdf import PdfReader
    from .core.store import ExamStore
    from .render import compose, output
    ex, folder = win.store().create("AUTOTESTE REUSO", "2026-10-20", win.s.identity(), win.s.logo_file(), "6")
    win.set_exam(ex, folder)
    win.import_paths(files[:5])
    t0 = time.time()
    while win.importers and time.time() - t0 < 60:
        pump(0.1)
    g = [it.id for it in win.exam.images]
    win.pages.set_chosen("6")

    def click(row):
        mouse(row, (QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonRelease))

    def cells():
        return [list(p.slots) for p in win.exam.pages]
    # critério principal: 10 cliques (5 pares rápidos = duplo clique do Windows) = 10 usos
    for _ in range(5):
        mouse(0, (QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonRelease,
                  QEvent.Type.MouseButtonDblClick, QEvent.Type.MouseButtonRelease))
    assert used() == [g[0]] * 10, f"10 cliques: {len(used())} usos"
    assert win.gview.isEnabled() and win.exam.use_count(g[0]) == 10
    ok("U0. CRITÉRIO: 10 cliques rápidos na mesma foto = 10 ocorrências (6 + 4 numa página nova); "
       "nada retirado, miniatura livre")
    win.clear_composition()
    click(0)
    assert cells() == [[g[0]] + [None] * 5]
    ok("U1. um clique adicionou a foto")
    click(0)
    assert cells() == [[g[0], g[0]] + [None] * 4]
    ok("U2. clique de novo na mesma foto: aparece duas vezes")
    for _ in range(4):
        click(0)
    assert cells() == [[g[0]] * 6]
    ok("U3. a mesma foto 6 vezes na página de 6 posições")
    win.new_page_at_end("9")
    click(0)
    click(2)
    assert cells()[1][:2] == [g[0], g[2]] and win.exam.use_count(g[0]) == 7
    ok("U4. a mesma foto reutilizada em outra página")
    win.pages.chk_auto.setChecked(False)
    win.go_page(0)
    cv = win.preview.canvas
    cv.select_cell((0, 1))
    cv.setFocus()
    _key(cv, Qt.Key.Key_Delete)
    assert cells()[0] == [g[0], None, g[0], g[0], g[0], g[0]]
    ok("U5. retirada SÓ a 2ª ocorrência (prévia + Delete)")
    assert cells()[1][:2] == [g[0], g[2]] and win.exam.use_count(g[0]) == 6 and win.exam.image(g[0])
    ok("U6. as outras 5 ocorrências da página 1 e a da página 2 continuam intactas; foto na galeria")
    win.pages.chk_auto.setChecked(True)
    snap = cells()
    win.go_page(1)
    win.clear_current_page()
    assert cells()[1] == [None] * 9 and cells()[0] == snap[0]
    win.undo()
    assert cells() == snap
    ok("U7. Limpar página 2 não afetou a página 1 (Ctrl+Z restaurou)")
    assert win.save_exam()
    win.set_exam(None, "")
    assert win.load_exam(folder, prefer_draft=False)
    assert cells() == snap and len(os.listdir(os.path.join(folder, "imagens"))) == 5
    ok("U8. salvo e reaberto com as fotos repetidas; nenhum arquivo duplicado no disco")
    prov = compose.FileImageProvider(folder, ExamStore.logo_path(win.exam, folder))
    pdf = os.path.join(out, "reuso.pdf")
    output.export_pdf(win.exam, prov, pdf)
    counts = [len(_re.findall(rb"/Im\w*\s+Do\b", pg.get_contents().get_data())) for pg in PdfReader(pdf).pages]
    assert counts == [5, 2], counts
    ok(f"U9. PDF com todas as ocorrências: imagens por página = {counts}")
    d = win.gview.delegate
    from PySide6.QtCore import QRect
    from PySide6.QtGui import QImage, QPainter
    from PySide6.QtWidgets import QStyle, QStyleOptionViewItem

    def card(row):
        sz = win.gview.gridSize()
        img = QImage(sz, QImage.Format.Format_ARGB32)
        img.fill(0)
        p = QPainter(img)
        o = QStyleOptionViewItem()
        o.rect = QRect(0, 0, sz.width(), sz.height())
        o.state = QStyle.StateFlag.State_Enabled
        o.font = win.gview.font()
        d.paint(p, o, win.gmodel.index(row))
        p.end()
        return [img.pixelColor(x, y).name() for x in range(4, 10) for y in range(4, 10)]
    assert card(0) == card(4), "miniatura usada desenhada diferente"
    win.grab().save(os.path.join(out, "tela_reuso.png"))
    ok("U10. galeria livre: a miniatura usada 6× tem a mesma borda e fundo de uma nunca usada")
    win.dirty = False
    win.set_exam(None, "")
