"""Galeria Pro Clínica — organização e impressão de fotografias de exames."""
__version__ = "1.3.1"
APP_NAME = "Galeria Pro Clínica"
APP_ID = "GaleriaProClinica"
