"""Painel direito: modelos de página e lista de páginas."""
from __future__ import annotations

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtWidgets import (QButtonGroup, QFrame, QGridLayout, QHBoxLayout, QLabel,
                               QListWidget, QListWidgetItem, QPushButton, QSizePolicy,
                               QToolButton, QVBoxLayout, QWidget)

from ..core.model import TEMPLATES, TEMPLATE_LABEL, Exam, capacity
from . import icons


class PagesPanel(QFrame):
    template_page = Signal(str)        # aplicar à página atual
    template_all = Signal(str)         # aplicar a todas
    compact_requested = Signal()       # reorganizar e preencher espaços
    template_chosen = Signal(str)      # modelo escolhido (usado por Selecionar fotos)
    page_selected = Signal(int)
    add_page = Signal()
    delete_page = Signal()
    move_page = Signal(int)            # -1 sobe, +1 desce

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("panel")
        self.setMinimumWidth(176)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(8)

        t = QLabel("Fotos por página")
        self.t_hint = QLabel("vale só para a página atual")
        self.t_hint.setObjectName("hint")
        t.setObjectName("panelTitle")
        lay.addWidget(t)
        grid = QGridLayout()
        grid.setSpacing(5)
        self.group = QButtonGroup(self)
        self.group.setExclusive(True)
        self.tbtn: dict[str, QToolButton] = {}
        for k, tpl in enumerate(TEMPLATES):
            b = QToolButton()
            b.setObjectName("tpl")
            b.setCheckable(True)
            b.setIcon(icons.template_pixmap(tpl, 26))
            b.setIconSize(QSize(26, 37))
            b.setText(TEMPLATE_LABEL[tpl])
            b.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
            b.setToolTip(f"Modelo de {TEMPLATE_LABEL[tpl]} por página")
            b.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            self.group.addButton(b)
            self.tbtn[tpl] = b
            grid.addWidget(b, k // 3, k % 3)
        lay.addWidget(self.t_hint)
        lay.addLayout(grid)
        self.tbtn["6"].setChecked(True)
        self.group.buttonClicked.connect(lambda _b: self.template_chosen.emit(self.chosen()))

        self.btn_page = QPushButton("Aplicar nesta página")
        self.btn_page.setToolTip("Muda o modelo só da página atual. Se couber menos, o excedente "
                                 "passa para a página seguinte (nada se perde).")
        self.btn_all = QPushButton("Aplicar em todas")
        self.btn_all.setToolTip("Muda o modelo de todas as páginas, mantendo a sequência de impressão.")
        self.btn_compact = QPushButton(icons.icon("auto"), " Reorganizar e preencher espaços")
        self.btn_compact.setToolTip("Fecha as células vazias deslocando as fotos seguintes, na mesma "
                                    "sequência. É a única ação que reorganiza a impressão sozinha.")
        self.btn_page.hide()      # o próprio botão do modelo já aplica à página atual
        self.btn_compact.setToolTip("Fecha as células vazias em TODAS as páginas, puxando as fotos "
                                    "seguintes. Para uma página só, use “Reorganizar ao retirar foto”.")
        for b in (self.btn_all, self.btn_compact):
            lay.addWidget(b)
        from PySide6.QtWidgets import QCheckBox
        self.chk_auto = QCheckBox("Reorganizar ao retirar foto")
        self.chk_auto.setToolTip("Ligado: ao retirar uma foto, as seguintes sobem para ocupar o espaço.\n"
                                 "Desligado: o espaço fica vazio para você preencher depois.")
        lay.addWidget(self.chk_auto)
        self.btn_page.clicked.connect(lambda: self.template_page.emit(self.chosen()))
        self.btn_all.clicked.connect(lambda: self.template_all.emit(self.chosen()))
        self.btn_compact.clicked.connect(self.compact_requested.emit)

        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet("color:#D5DBE3")
        lay.addWidget(line)

        t2 = QLabel("Páginas")
        t2.setObjectName("panelTitle")
        lay.addWidget(t2)
        self.list = QListWidget()
        self.list.setIconSize(QSize(22, 31))
        self.list.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.list.currentRowChanged.connect(self._row_changed)
        lay.addWidget(self.list, 1)

        row = QHBoxLayout()
        row.setSpacing(4)
        self.b_add = self._tb("page_add", "Adicionar página após a atual")
        self.b_del = self._tb("page_del", "Excluir a página atual")
        self.b_up = self._tb("up", "Mover a página para cima")
        self.b_down = self._tb("down", "Mover a página para baixo")
        for b in (self.b_add, self.b_del, self.b_up, self.b_down):
            row.addWidget(b)
        lay.addLayout(row)
        self.b_add.clicked.connect(self.add_page.emit)
        self.b_del.clicked.connect(self.delete_page.emit)
        self.b_up.clicked.connect(lambda: self.move_page.emit(-1))
        self.b_down.clicked.connect(lambda: self.move_page.emit(1))

        self.info = QLabel("")
        self.info.setObjectName("hint")
        self.info.setWordWrap(True)
        lay.addWidget(self.info)
        self._block = False

    def resizeEvent(self, e):
        super().resizeEvent(e)
        narrow = self.width() < 226
        for t, b in self.tbtn.items():
            b.setText(t if narrow else TEMPLATE_LABEL[t])
        self.btn_page.setText("Nesta página" if narrow else "Aplicar nesta página")
        self.btn_all.setText("Em todas" if narrow else "Aplicar em todas")
        self.btn_compact.setText(" Reorganizar todas" if self.width() < 290 else " Reorganizar todas as páginas")

    def _tb(self, name: str, tip: str) -> QToolButton:
        b = QToolButton()
        b.setIcon(icons.icon(name))
        b.setIconSize(QSize(18, 18))
        b.setToolTip(tip)
        b.setAutoRaise(False)
        b.setStyleSheet("QToolButton{border:1px solid #C3CBD6;border-radius:6px;padding:4px;background:#fff}"
                        "QToolButton:hover{background:#F1F5FA}")
        b.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        return b

    def chosen(self) -> str:
        for t, b in self.tbtn.items():
            if b.isChecked():
                return t
        return "6"

    def set_chosen(self, t: str) -> None:
        if t in self.tbtn:
            self.tbtn[t].setChecked(True)

    def _row_changed(self, r: int) -> None:
        if not self._block and r >= 0:
            self.page_selected.emit(r)

    def refresh(self, exam: Exam | None, current: int) -> None:
        self._block = True
        # só reconstrói a lista quando o conteúdo dela muda (evita redesenhos à toa)
        sig = None if exam is None else tuple((pg.template, len(pg.used())) for pg in exam.pages)
        if sig != getattr(self, "_list_sig", object()) or exam is None:
            self._list_sig = sig
            self.list.clear()
            self._fill = True
        else:
            self._fill = False
        enabled = exam is not None
        for w in (self.btn_page, self.btn_all, self.btn_compact, self.b_add, self.b_del, self.b_up, self.b_down):
            w.setEnabled(enabled)
        if exam is None:
            self.info.setText("")
            self._block = False
            return
        for i, pg in enumerate(exam.pages if self._fill else []):
            n = len(pg.used())
            cap = capacity(pg.template)
            free = cap - n
            txt = f"Página {i + 1}\n{n} de {cap} fotos" + (f" · {free} vazia(s)" if free and n else "")
            if n == 0:
                txt = f"Página {i + 1}\nvazia ({TEMPLATE_LABEL[pg.template]})"
            it = QListWidgetItem(icons.template_pixmap(pg.template, 22), txt)
            self.list.addItem(it)
        if exam.pages:
            row = max(0, min(current, len(exam.pages) - 1))
            if self.list.currentRow() != row:
                self.list.setCurrentRow(row)
        has_pages = bool(exam.pages)
        self.btn_page.setEnabled(has_pages)
        self.btn_all.setEnabled(has_pages)
        self.btn_compact.setEnabled(has_pages and exam.free_cells() > 0)
        self.b_del.setEnabled(has_pages)
        self.b_up.setEnabled(has_pages and current > 0)
        self.b_down.setEnabled(has_pages and current < len(exam.pages) - 1)
        if not has_pages:
            self.info.setText("Escolha quantas fotos por página e use “Selecionar fotos”, ou marque "
                              "as fotos na galeria uma a uma.")
        else:
            self.info.setText("Ordem de leitura: esquerda → direita, de cima para baixo.")
        # o seletor mostra SEMPRE o modelo salvo da página atual
        if has_pages and 0 <= current < len(exam.pages):
            self.set_chosen(exam.pages[current].template)
        else:
            self.set_chosen(exam.default_template)
        self._block = False
