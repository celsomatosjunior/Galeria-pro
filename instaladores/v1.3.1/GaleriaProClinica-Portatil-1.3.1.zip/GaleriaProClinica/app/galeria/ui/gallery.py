"""Galeria: miniaturas com marcação, número da sequência, página onde está e avisos."""
from __future__ import annotations

from PySide6.QtCore import (QAbstractListModel, QByteArray, QEvent, QMimeData, QModelIndex,
                            QPoint, QRect, QRectF, QSize, Qt, Signal)
from PySide6.QtGui import (QColor, QDrag, QFont, QPainter, QPainterPath, QPen, QPixmap)
from PySide6.QtWidgets import (QAbstractItemView, QListView, QStyle, QStyledItemDelegate,
                               QStyleOptionViewItem)

from ..core.model import Exam
from . import icons
from .theme import ACCENT, ERR, WARN

MIME_IDS = "application/x-galeria-imagens"
ROLE_ID = Qt.ItemDataRole.UserRole + 1
CELL_W, CELL_H = 156, 136


class GalleryModel(QAbstractListModel):
    def __init__(self, thumbs, parent=None):
        super().__init__(parent)
        self.thumbs = thumbs
        self.exam: Exam | None = None
        self.cells: dict[str, tuple[int, int]] = {}   # id → (página, célula) na impressão
        self.order: dict[str, int] = {}               # id → nº na ordem de impressão
        self.lowres: set[str] = set()
        self.missing: set[str] = set()
        self.fresh: set[str] = set()       # chegaram pelo acompanhamento da pasta
        thumbs.ready.connect(self._thumb_ready)

    def set_exam(self, exam: Exam | None) -> None:
        self.beginResetModel()
        self.exam = exam
        self.fresh.clear()
        self._sigs = {}
        self.endResetModel()

    def refresh(self, cells, order, lowres, missing) -> None:
        """Atualiza as marcações e redesenha SÓ as miniaturas cujo estado mudou."""
        self.cells, self.order, self.lowres, self.missing = cells, order, lowres, missing
        if not self.exam or not self.rowCount():
            self._sigs = {}
            return
        prev = getattr(self, "_sigs", {})
        sigs = {}
        for r, it in enumerate(self.exam.images):
            i = it.id
            sg = (r, cells.get(i), order.get(i), i in lowres, i in missing, i in self.fresh,
                  it.rotation, repr(it.crop.to_dict()))
            sigs[i] = sg
            if prev.get(i) != sg:
                ix = self.index(r)
                self.dataChanged.emit(ix, ix)
        self._sigs = sigs

    def refresh_all(self) -> None:
        if self.rowCount():
            self.dataChanged.emit(self.index(0), self.index(self.rowCount() - 1))

    def reset_rows(self) -> None:
        self.beginResetModel()
        self._sigs = {}
        self.endResetModel()

    def _thumb_ready(self, iid: str) -> None:
        if not self.exam:
            return
        for r, it in enumerate(self.exam.images):
            if it.id == iid:
                ix = self.index(r)
                self.dataChanged.emit(ix, ix)
                return

    def rowCount(self, parent=QModelIndex()):
        return 0 if (parent.isValid() or not self.exam) else len(self.exam.images)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or not self.exam:
            return None
        it = self.exam.images[index.row()]
        if role == ROLE_ID:
            return it.id
        if role == Qt.ItemDataRole.ToolTipRole:
            w, h = it.edited_size()
            tip = [it.original_name, f"{int(w)} × {int(h)} pixels"]
            if it.rotation:
                tip.append(f"Girada {it.rotation}°")
            if not it.crop.is_full():
                tip.append("Recortada")
            if it.id in self.cells:
                pg, sl = self.cells[it.id]
                tip.append(f"Na impressão: página {pg + 1}, posição {sl + 1}")
            else:
                tip.append("Disponível (fora da impressão)")
            if it.id in self.lowres:
                tip.append("Resolução baixa para o tamanho impresso")
            if it.id in self.missing or it.id in self.thumbs.broken:
                tip.append("Arquivo ausente ou danificado")
            return "\n".join(tip)
        return None

    def flags(self, index):
        f = super().flags(index)
        if index.isValid():
            f |= Qt.ItemFlag.ItemIsDragEnabled
        return f | Qt.ItemFlag.ItemIsDropEnabled


class GalleryDelegate(QStyledItemDelegate):
    clicked_photo = Signal(str)

    CHECK = QRect(8, 8, 22, 22)

    def __init__(self, model: GalleryModel, parent=None):
        super().__init__(parent)
        self.m = model

    def sizeHint(self, option, index):
        v = self.parent()
        return v.gridSize() if v is not None else QSize(CELL_W, CELL_H)

    def paint(self, p: QPainter, opt: QStyleOptionViewItem, index):
        ex = self.m.exam
        if not ex:
            return
        it = ex.images[index.row()]
        used = it.id in self.m.cells
        r = opt.rect.adjusted(4, 4, -4, -4)
        p.save()
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        sel = bool(opt.state & QStyle.StateFlag.State_Selected)
        hover = bool(opt.state & QStyle.StateFlag.State_MouseOver)
        if used:
            bg = QColor("#D6E6FA")                     # selecionada: fundo azul claro
        else:
            bg = QColor("#EEF3FA") if (sel or hover) else QColor("#FFFFFF")
        border = QColor("#1A73E8") if used else (QColor("#9DB6D8") if (sel or hover) else QColor("#D5DBE3"))
        path = QPainterPath()
        path.addRoundedRect(QRectF(r).adjusted(1, 1, -1, -1), 6, 6)
        p.fillPath(path, bg)
        p.setPen(QPen(border, 4.0 if used else 1.2))
        p.drawPath(path)

        # miniatura
        area = r.adjusted(6, 6, -6, -24)
        pm = self.m.thumbs.get(it)
        if pm is not None:
            s = pm.size().scaled(area.size(), Qt.AspectRatioMode.KeepAspectRatio)
            tr = QRect(0, 0, s.width(), s.height())
            tr.moveCenter(area.center())
            p.drawPixmap(tr, pm)        # nunca desbotada: a imagem aparece sempre nítida
        else:
            p.setPen(QColor("#8A94A3"))
            txt = "Arquivo ausente" if (it.id in self.m.thumbs.broken) else "Carregando…"
            p.drawText(area, Qt.AlignmentFlag.AlignCenter, txt)

        # caixa de marcação
        cb = self.CHECK.translated(r.topLeft())
        p.setPen(QPen(QColor(ACCENT) if used else QColor("#8291A6"), 1.6))
        p.setBrush(QColor(ACCENT) if used else QColor(255, 255, 255, 235))
        p.drawRoundedRect(QRectF(cb), 4, 4)
        if used:
            pen = QPen(QColor("#FFFFFF"), 2.6)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            p.drawLine(cb.left() + 5, cb.center().y() + 1, cb.left() + 9, cb.bottom() - 6)
            p.drawLine(cb.left() + 9, cb.bottom() - 6, cb.right() - 5, cb.top() + 6)

        # número na sequência
        f = QFont(opt.font)
        n = self.m.order.get(it.id)
        if n is not None:
            f.setBold(True)
            f.setPointSizeF(9.5)
            p.setFont(f)
            txt = str(n)
            w = max(24, p.fontMetrics().horizontalAdvance(txt) + 12)
            badge = QRect(r.right() - w - 6, r.top() + 8, w, 22)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(ACCENT))
            p.drawRoundedRect(QRectF(badge), 11, 11)
            p.setPen(QColor("#FFFFFF"))
            p.drawText(badge, Qt.AlignmentFlag.AlignCenter, txt)

        # rodapé do cartão: página / avisos
        foot = QRect(r.left() + 7, r.bottom() - 20, r.width() - 14, 18)
        f.setBold(False)
        f.setPointSizeF(8)
        p.setFont(f)
        x = foot.left()
        if used:
            pg, sl = self.m.cells[it.id]
            p.setPen(QColor("#2F4D73"))
            f.setBold(True)
            p.setFont(f)
            t = f"P{pg + 1} · posição {sl + 1}"
            p.drawText(QRect(x, foot.top(), 120, 18), Qt.AlignmentFlag.AlignVCenter, t)
            f.setBold(False)
            p.setFont(f)
        else:
            p.setPen(QColor("#8A94A3"))
            p.drawText(QRect(x, foot.top(), 70, 18), Qt.AlignmentFlag.AlignVCenter, "disponível")
        right = foot.right()
        if it.id in self.m.fresh:
            p.setPen(QColor("#1E8E4E"))
            p.drawText(QRect(right - 40, foot.top(), 40, 18),
                       Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight, "nova")
            right -= 44
        if it.has_edits():
            p.drawPixmap(right - 16, foot.top() + 1, icons.pixmap("crop" if not it.crop.is_full() else "rotate", 16, "#5F6B7A"))
            right -= 20
        if it.id in self.m.lowres:
            p.drawPixmap(right - 16, foot.top() + 1, icons.pixmap("warn", 16, WARN))
            right -= 20
        if it.id in self.m.missing or it.id in self.m.thumbs.broken:
            p.drawPixmap(right - 16, foot.top() + 1, icons.pixmap("warn", 16, ERR))
        p.restore()

    def editorEvent(self, event, model, option, index):
        """Um clique em qualquer ponto da miniatura marca/desmarca (sem Ctrl/Shift).
        Arrastar não marca. No duplo clique, a 2ª soltura é ignorada (a janela desfaz a 1ª)."""
        t = event.type()
        if t == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
            self._skip_release = False      # novo clique: nada pendente do duplo clique anterior
            self._press_pos = event.position().toPoint()
            self._press_row = index.row()
            return False
        if t == QEvent.Type.MouseButtonDblClick and event.button() == Qt.MouseButton.LeftButton:
            self._skip_release = True
            return False
        if t == QEvent.Type.MouseButtonRelease and event.button() == Qt.MouseButton.LeftButton:
            if getattr(self, "_skip_release", False):
                self._skip_release = False
                return True
            mods = event.modifiers()
            if mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier):
                return False        # Ctrl/Shift: seleção múltipla para arrastar (opcional)
            pp = getattr(self, "_press_pos", None)
            if pp is None or getattr(self, "_press_row", -1) != index.row():
                return False
            if (event.position().toPoint() - pp).manhattanLength() > 6:
                return False        # foi um arraste
            self._press_pos = None
            self.clicked_photo.emit(index.data(ROLE_ID))
            return True
        return False


class GalleryView(QListView):
    toggle_requested = Signal(list)           # ids (Espaço)
    photo_clicked = Signal(str)               # um clique na miniatura
    reorder_requested = Signal(list, int)     # ids, antes da linha
    files_dropped = Signal(list)              # caminhos (arquivos e pastas)
    open_requested = Signal(str)              # duplo clique → ampliar
    context_requested = Signal(list, QPoint)  # ids, posição global
    delete_requested = Signal(list)           # Delete → retirar da composição

    def __init__(self, model: GalleryModel, parent=None):
        super().__init__(parent)
        self.m = model
        self.setModel(model)
        self.delegate = GalleryDelegate(model, self)
        self.delegate.clicked_photo.connect(self.photo_clicked.emit)
        self.setItemDelegate(self.delegate)
        self.setViewMode(QListView.ViewMode.IconMode)
        self.setFlow(QListView.Flow.LeftToRight)
        self.setWrapping(True)
        self.setResizeMode(QListView.ResizeMode.Adjust)
        self.setMovement(QListView.Movement.Snap)
        self.setUniformItemSizes(True)
        self.setGridSize(QSize(CELL_W, CELL_H))
        self.setSpacing(0)
        self.setMouseTracking(True)
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        self.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
        self.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        # barra vertical fixa: a largura útil da galeria não depende da quantidade de fotos
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._grid_w = -1
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._ctx)
        self.doubleClicked.connect(lambda ix: self.open_requested.emit(ix.data(ROLE_ID)))
        self._drop_row = -1

    # Causa das piscadas da 1.1 e da 1.3.0 (medida com tools/instrument_flicker.py): a grade era
    # recalculada pela largura do viewport, que depende de a barra de rolagem estar visível.
    # 3 colunas → miniaturas maiores → conteúdo mais alto → barra aparece → viewport mais
    # estreito → 2 colunas → conteúdo mais baixo → barra some → 3 colunas… (~480 vezes/s).
    # Correção: a barra vertical fica sempre presente (largura útil não depende do conteúdo) e
    # a grade só é recalculada quando a largura do próprio widget muda.
    def _grid_for_width(self) -> QSize:
        sb = self.verticalScrollBar().sizeHint().width()
        if self.verticalScrollBar().isVisible():
            sb = self.verticalScrollBar().width()
        vw = self.width() - 2 * self.frameWidth() - sb - 2
        cols = max(1, vw // 140)
        cw = max(120, vw // cols)
        return QSize(cw, int(cw * 0.86))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if e.oldSize().width() == e.size().width() and self._grid_w == e.size().width():
            return              # só a altura mudou: a grade continua a mesma
        self._grid_w = e.size().width()
        g = self._grid_for_width()
        if g != self.gridSize():
            self.setGridSize(g)

    def selected_ids(self) -> list[str]:
        rows = sorted(ix.row() for ix in self.selectionModel().selectedIndexes())
        return [self.m.index(r).data(ROLE_ID) for r in rows]

    def _ctx(self, pos: QPoint) -> None:
        ix = self.indexAt(pos)
        if not ix.isValid():
            return
        if not self.selectionModel().isSelected(ix):
            self.selectionModel().select(ix, self.selectionModel().SelectionFlag.ClearAndSelect)
        self.context_requested.emit(self.selected_ids(), self.viewport().mapToGlobal(pos))

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Space and self.selected_ids():
            self.toggle_requested.emit(self.selected_ids())
            return
        if e.key() == Qt.Key.Key_Delete and self.selected_ids():
            self.delete_requested.emit(self.selected_ids())
            return
        if e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and self.currentIndex().isValid():
            self.open_requested.emit(self.currentIndex().data(ROLE_ID))
            return
        super().keyPressEvent(e)

    # ---------------- arrastar
    def startDrag(self, actions):
        ids = self.selected_ids()
        if not ids:
            return
        md = QMimeData()
        md.setData(MIME_IDS, QByteArray("\n".join(ids).encode()))
        drag = QDrag(self)
        drag.setMimeData(md)
        it = self.m.exam.image(ids[0]) if self.m.exam else None
        pm = self.m.thumbs.get(it) if it else None
        if pm is not None:
            small = pm.scaled(110, 90, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            if len(ids) > 1:
                canvas = QPixmap(small.size() + QSize(14, 14))
                canvas.fill(Qt.GlobalColor.transparent)
                cp = QPainter(canvas)
                cp.drawPixmap(8, 8, small)
                cp.drawPixmap(0, 0, small)
                cp.setBrush(QColor(ACCENT))
                cp.setPen(Qt.PenStyle.NoPen)
                cp.drawEllipse(QRectF(canvas.width() - 26, 0, 26, 26))
                cp.setPen(QColor("#FFFFFF"))
                cp.drawText(QRectF(canvas.width() - 26, 0, 26, 26), Qt.AlignmentFlag.AlignCenter, str(len(ids)))
                cp.end()
                small = canvas
            drag.setPixmap(small)
            drag.setHotSpot(QPoint(small.width() // 2, small.height() // 2))
        drag.exec(Qt.DropAction.MoveAction | Qt.DropAction.CopyAction, Qt.DropAction.MoveAction)

    def _row_for(self, pos: QPoint) -> int:
        ix = self.indexAt(pos)
        if not ix.isValid():
            return self.m.rowCount()
        rect = self.visualRect(ix)
        return ix.row() + (1 if pos.x() > rect.center().x() else 0)

    def dragEnterEvent(self, e):
        md = e.mimeData()
        if md.hasFormat(MIME_IDS) or md.hasUrls():
            e.acceptProposedAction()
        else:
            e.ignore()

    def dragMoveEvent(self, e):
        md = e.mimeData()
        if md.hasFormat(MIME_IDS) or md.hasUrls():
            self._drop_row = self._row_for(e.position().toPoint()) if md.hasFormat(MIME_IDS) else -1
            self.viewport().update()
            e.acceptProposedAction()
        else:
            e.ignore()

    def dragLeaveEvent(self, e):
        self._drop_row = -1
        self.viewport().update()

    def dropEvent(self, e):
        md = e.mimeData()
        self._drop_row = -1
        self.viewport().update()
        if md.hasFormat(MIME_IDS):
            ids = bytes(md.data(MIME_IDS)).decode().split("\n")
            self.reorder_requested.emit(ids, self._row_for(e.position().toPoint()))
            e.acceptProposedAction()
        elif md.hasUrls():
            paths = [u.toLocalFile() for u in md.urls() if u.isLocalFile()]
            if paths:
                self.files_dropped.emit(paths)
            e.acceptProposedAction()

    def paintEvent(self, e):
        super().paintEvent(e)
        if self._drop_row >= 0 and self.m.rowCount():
            r = self._drop_row
            if r < self.m.rowCount():
                rect = self.visualRect(self.m.index(r))
                x = rect.left() + 1
            else:
                rect = self.visualRect(self.m.index(self.m.rowCount() - 1))
                x = rect.right() - 1
            p = QPainter(self.viewport())
            p.setPen(QPen(QColor(ACCENT), 3))
            p.drawLine(x, rect.top() + 6, x, rect.bottom() - 6)
            p.end()
