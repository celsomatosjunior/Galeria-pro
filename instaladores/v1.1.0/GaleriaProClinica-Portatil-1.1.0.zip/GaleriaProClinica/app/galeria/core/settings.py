"""Preferências persistentes (%APPDATA%\\GaleriaProClinica\\config.json) e sessão."""
from __future__ import annotations

import copy
import json
import os
import shutil

from .. import APP_ID
from .model import TEMPLATES, default_identity
from .store import atomic_write_json, read_json

SESSION_FILE = "sessao.json"


def config_dir() -> str:
    over = os.environ.get("GALERIA_CONFIG_DIR")
    if over:
        return over
    base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, APP_ID)


def documents_dir() -> str:
    try:
        from PySide6.QtCore import QStandardPaths
        d = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DocumentsLocation)
        if d:
            return d
    except Exception:
        pass
    return os.path.join(os.path.expanduser("~"), "Documents")


def capture_pro_folder() -> str:
    """Pasta de capturas configurada no Capture Pro (somente leitura) ou o padrão dele."""
    appdata = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".config")
    try:
        with open(os.path.join(appdata, "CapturePro", "config.json"), encoding="utf-8") as f:
            cfg = json.load(f)
        p = cfg.get("output_folder")
        if isinstance(p, str) and p:
            return p
    except (OSError, ValueError):
        pass
    home = os.path.expanduser("~")
    pics = os.path.join(home, "Pictures")
    return os.path.join(pics if os.path.isdir(pics) else home, "Capturas")


def defaults() -> dict:
    docs = os.path.join(documents_dir(), "Galeria Pro Clínica")
    return {
        "versao_config": 1,
        "pasta_capturas": capture_pro_folder(),
        "pasta_exames": os.path.join(docs, "Exames"),
        "pasta_pdfs": os.path.join(docs, "PDFs"),
        "modelo_inicial": "6",
        "quantidade_selecao": 6,
        "identidade": default_identity(),
        "logo_padrao": "",          # caminho da cópia em config_dir()/identidade
        "acompanhar_pasta": False,
        "impressora": "",
        "janela": {},
        "abrir_pdf_apos_gerar": True,
        "zoom": "pagina",
    }


class Settings:
    def __init__(self, folder: str | None = None):
        self.folder = folder or config_dir()
        self.path = os.path.join(self.folder, "config.json")
        self.data = defaults()
        self.load_note = ""
        self.load()

    def load(self) -> None:
        if not os.path.isfile(self.path):
            return
        try:
            loaded = read_json(self.path)
            if not isinstance(loaded, dict):
                raise ValueError
        except (OSError, ValueError):
            # configuração corrompida: guarda uma cópia e volta ao padrão
            try:
                shutil.copyfile(self.path, self.path + ".danificado")
            except OSError:
                pass
            self.load_note = "As configurações estavam danificadas e foram restauradas ao padrão."
            return
        d = defaults()
        ident = d["identidade"]
        ident.update(loaded.get("identidade") or {})
        d.update({k: v for k, v in loaded.items() if k in d and k != "identidade"})
        d["identidade"] = ident
        if d.get("modelo_inicial") not in TEMPLATES:
            d["modelo_inicial"] = "6"
        self.data = d

    def save(self) -> None:
        atomic_write_json(self.path, self.data)

    def __getitem__(self, k):
        return self.data[k]

    def __setitem__(self, k, v):
        self.data[k] = v

    def get(self, k, default=None):
        return self.data.get(k, default)

    def identity(self) -> dict:
        return copy.deepcopy(self.data["identidade"])

    def logo_file(self) -> str | None:
        p = self.data.get("logo_padrao") or ""
        return p if p and os.path.isfile(p) else None

    def store_logo(self, src: str) -> str:
        """Copia a logo escolhida para a pasta de configuração (o original pode sumir)."""
        d = os.path.join(self.folder, "identidade")
        os.makedirs(d, exist_ok=True)
        ext = os.path.splitext(src)[1].lower() or ".png"
        import uuid
        dest = os.path.join(d, f"logo_{uuid.uuid4().hex[:6]}{ext}")
        shutil.copyfile(src, dest)
        return dest

    # --------------------------------------------------------------- sessão
    def session_path(self) -> str:
        return os.path.join(self.folder, SESSION_FILE)

    def begin_session(self, exam_folder: str | None) -> None:
        try:
            atomic_write_json(self.session_path(), {"pasta_exame": exam_folder or "", "pid": os.getpid()})
        except OSError:
            pass

    def end_session(self) -> None:
        try:
            os.remove(self.session_path())
        except OSError:
            pass

    def interrupted_session(self) -> str | None:
        """Pasta do exame da sessão anterior que não foi encerrada normalmente."""
        try:
            d = read_json(self.session_path())
        except (OSError, ValueError):
            return None
        p = d.get("pasta_exame") or ""
        return p if p and os.path.isdir(p) else None
