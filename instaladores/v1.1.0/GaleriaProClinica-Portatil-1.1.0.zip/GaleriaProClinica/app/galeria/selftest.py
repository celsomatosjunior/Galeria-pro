"""Autoteste de ponta a ponta (uso técnico): GaleriaProClinica.exe --autoteste <pasta>

Na <pasta> devem existir imagens (PNG/JPEG/BMP). O teste usa uma configuração e uma pasta
de exames temporárias dentro de <pasta>\\autoteste_saida — não toca nos dados reais.
Resultado: autoteste_saida\\relatorio.txt, tela.png e exemplo.pdf.
"""
from __future__ import annotations

import glob
import os
import time
import traceback


def run(win, src: str, out: str, app) -> int:
    from .core import composition as C
    from .core.store import ExamStore
    lines = []

    def ok(msg):
        lines.append("OK    " + msg)

    def pump(t=0.5):
        t0 = time.time()
        while time.time() - t0 < t:
            app.processEvents()
            time.sleep(0.01)

    try:
        files = sorted(f for e in ("*.png", "*.jpg", "*.jpeg", "*.bmp") for f in glob.glob(os.path.join(src, e)))
        assert files, "sem imagens na pasta"
        ex, folder = win.store().create("PACIENTE AUTOTESTE", "2026-10-20", win.s.identity(),
                                        win.s.logo_file(), "6")
        win.set_exam(ex, folder)
        ok(f"exame criado em {folder}")
        win.import_paths(files)
        t0 = time.time()
        while win.importers and time.time() - t0 < 120:
            pump(0.2)
        assert len(win.exam.images) == len(set(files)), f"importadas {len(win.exam.images)} de {len(files)}"
        ok(f"{len(win.exam.images)} imagens importadas em segundo plano")
        gal = [it.id for it in win.exam.images]
        want = min(10, len(gal))
        C.auto_select(win.exam, gal, want, "6", "refazer")
        win._changed()
        n = len(win.exam.sequence())
        assert n == want, f"seleção automática: {n} de {want}"
        free = win.exam.free_cells()
        rest = [i for i in gal if not win.exam.is_used(i)]
        ok(f"Selecionar fotos: {want} fotos em {len(win.exam.pages)} página(s), {free} célula(s) vazia(s)")
        if rest:
            first = C.first_free(win.exam)
            C.add_to_composition(win.exam, rest[:1])
            assert win.exam.pages[first[0]].slots[first[1]] == rest[0]
            ok(f"inclusão manual ocupou a primeira célula vazia (P{first[0] + 1} · posição {first[1] + 1})")
        else:
            lines.append("NÃO TESTADO  inclusão manual (a pasta não tem mais que 10 imagens)")
        win.current_page = 0
        win.apply_template_page("2")
        assert len(win.exam.sequence()) == n + (1 if rest else 0), "foto perdida na troca de modelo"
        ok("modelo da página 1 trocado para 2 fotos sem perder fotos")
        pump(2)
        win.grab().save(os.path.join(out, "tela.png"))
        ok("captura de tela gravada")
        from .render import compose, output
        prov = compose.FileImageProvider(folder, ExamStore.logo_path(win.exam, folder))
        pdf = os.path.join(out, "exemplo.pdf")
        w = output.export_pdf(win.exam, prov, pdf)
        assert os.path.getsize(pdf) > 1000
        ok(f"PDF gerado ({os.path.getsize(pdf)} bytes) avisos={w}")
        assert win.save_exam()
        flow = [list(p.slots) for p in win.exam.pages]
        win.set_exam(None, "")
        assert win.load_exam(folder, prefer_draft=False)
        assert [list(p.slots) for p in win.exam.pages] == flow
        ok("salvo e reaberto com as mesmas posições e células vazias")
        from PySide6.QtPrintSupport import QPrinterInfo
        ok("impressoras visíveis: " + (", ".join(QPrinterInfo.availablePrinterNames()) or "(nenhuma)"))
        rc = 0
    except Exception:
        lines.append("FALHA " + traceback.format_exc())
        rc = 1
    with open(os.path.join(out, "relatorio.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return rc
