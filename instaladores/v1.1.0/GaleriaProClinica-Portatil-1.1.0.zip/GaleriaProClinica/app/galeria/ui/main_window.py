"""Janela principal do Galeria Pro Clínica."""
from __future__ import annotations

import base64
import datetime as _dt
import os

from PySide6.QtCore import QByteArray, QDate, QSize, Qt, QTimer, QUrl
from PySide6.QtGui import QAction, QDesktopServices, QKeySequence
from PySide6.QtWidgets import (QApplication, QDateEdit, QFileDialog, QFrame, QHBoxLayout, QLabel,
                               QLineEdit, QMainWindow, QMenu, QMessageBox, QProgressDialog,
                               QPushButton, QSizePolicy, QSlider, QSplitter, QToolBar, QToolButton,
                               QVBoxLayout, QWidget)

from .. import APP_NAME, __version__
from ..core import layout as L
from ..core import composition as C
from ..core.model import TEMPLATE_LABEL, TEMPLATES, Exam, ImageItem, Crop, capacity
from ..core.settings import Settings
from ..core.store import ExamStore, StoreError
from ..render import compose
from . import icons
from .dialogs import (AboutDialog, CropDialog, ImageViewer, NewExamDialog, OpenExamDialog,
                      PagesChoiceDialog, PhotoPickerDialog)
from .gallery import GalleryModel, GalleryView
from .pages_panel import PagesPanel
from .preview import PreviewArea
from .thumbs import ThumbService
from .workers import ImportWorker, PdfWorker

UNDO_LIMIT = 200
IMG_FILTER = "Imagens (*.png *.jpg *.jpeg *.bmp)"


class MainWindow(QMainWindow):
    def __init__(self, settings: Settings):
        super().__init__()
        self.s = settings
        self.setWindowTitle(APP_NAME)
        self.setMinimumSize(980, 600)
        self.exam: Exam | None = None
        self.folder = ""
        self.provider: compose.FileImageProvider | None = None
        self.undo_stack: list[tuple[str, dict]] = []
        self.redo_stack: list[tuple[str, dict]] = []
        self.dirty = False
        self.save_error = ""
        self.last_autosave = ""
        self.watcher = None
        self.importers: list[ImportWorker] = []
        self.pdf_worker: PdfWorker | None = None
        self.current_page = 0

        self.thumbs = ThumbService(self)
        self._build_actions()
        self._build_ui()
        self._autosave_timer = QTimer(self)
        self._autosave_timer.setSingleShot(True)
        self._autosave_timer.setInterval(1500)
        self._autosave_timer.timeout.connect(self.autosave)
        self._meta_timer = QTimer(self)
        self._meta_timer.setSingleShot(True)
        self._meta_timer.setInterval(40)
        self._meta_timer.timeout.connect(self._refresh_meta)
        self._restore_window()
        self.set_exam(None, "")

    # ================================================================ construção
    def _act(self, text, icon_name, slot, shortcut=None, tip=None, color="#2B3A55") -> QAction:
        a = QAction(icons.icon(icon_name, color), text, self)
        a.triggered.connect(slot)
        if shortcut:
            a.setShortcut(QKeySequence(shortcut))
            a.setShortcutContext(Qt.ShortcutContext.WindowShortcut)
        if tip:
            a.setToolTip(tip)
        self.addAction(a)
        return a

    def _build_actions(self) -> None:
        self.a_new = self._act("Novo exame", "new", self.new_exam, "Ctrl+N", "Novo exame (Ctrl+N)")
        self.a_open = self._act("Abrir exame", "open", self.open_exam, "Ctrl+O", "Abrir exame salvo (Ctrl+O)")
        self.a_save = self._act("Salvar exame", "save", self.save_exam, "Ctrl+S", "Salvar exame (Ctrl+S)")
        self.a_pdf = self._act("Gerar PDF", "pdf", self.export_pdf, None, "Gerar PDF das páginas")
        self.a_print = self._act("Imprimir", "print", self.print_exam, "Ctrl+P", "Imprimir (Ctrl+P)")
        self.a_settings = self._act("Configurações", "settings", self.open_settings, None,
                                    "Identidade da clínica, rodapé, página e pastas")
        self.a_about = self._act("Sobre", "about", lambda: AboutDialog(self).exec())
        self.a_undo = self._act("Desfazer", "undo", self.undo, "Ctrl+Z", "Desfazer (Ctrl+Z)")
        self.a_redo = self._act("Refazer", "redo", self.redo, "Ctrl+Y", "Refazer (Ctrl+Y)")
        self.a_redo.setShortcuts([QKeySequence("Ctrl+Y"), QKeySequence("Ctrl+Shift+Z")])

    def _build_ui(self) -> None:
        tb = QToolBar("Principal")
        tb.setMovable(False)
        tb.setIconSize(QSize(22, 22))
        tb.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        for a in (self.a_new, self.a_open, self.a_save):
            tb.addAction(a)
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        tb.addWidget(spacer)
        for a in (self.a_pdf, self.a_print, self.a_settings, self.a_about):
            tb.addAction(a)
        self.addToolBar(tb)
        for a in (self.a_pdf, self.a_print):
            w = tb.widgetForAction(a)
            if w:
                w.setObjectName("primaryTool")
                w.style().unpolish(w)
                w.style().polish(w)
        self.a_pdf.setIcon(icons.icon("pdf", "#FFFFFF"))
        self.a_print.setIcon(icons.icon("print", "#FFFFFF"))

        root = QWidget()
        root.setObjectName("root")
        self.setCentralWidget(root)
        v = QVBoxLayout(root)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)

        # faixa de identificação
        strip = QFrame()
        strip.setObjectName("idstrip")
        h = QHBoxLayout(strip)
        h.setContentsMargins(12, 8, 12, 8)
        h.addWidget(QLabel("Nome do paciente:"))
        self.e_name = QLineEdit()
        self.e_name.setObjectName("patientName")
        self.e_name.setPlaceholderText("Crie ou abra um exame")
        self.e_name.setMaxLength(160)
        h.addWidget(self.e_name, 1)
        h.addSpacing(12)
        h.addWidget(QLabel("Data do exame:"))
        self.e_date = QDateEdit()
        self.e_date.setCalendarPopup(True)
        self.e_date.setDisplayFormat("dd/MM/yyyy")
        self.e_date.setMinimumWidth(130)
        h.addWidget(self.e_date)
        v.addWidget(strip)
        self._name_timer = QTimer(self)
        self._name_timer.setSingleShot(True)
        self._name_timer.setInterval(400)
        self._name_timer.timeout.connect(self._apply_ident_fields)
        self.e_name.textEdited.connect(lambda _t: self._name_timer.start())
        self.e_name.editingFinished.connect(self._apply_ident_fields)
        self.e_date.dateChanged.connect(lambda _d: self._apply_ident_fields())

        # área de trabalho
        self.split = QSplitter(Qt.Orientation.Horizontal)
        self.split.setHandleWidth(6)
        self.split.setChildrenCollapsible(False)
        work = QWidget()
        wl = QVBoxLayout(work)
        wl.setContentsMargins(8, 8, 8, 8)
        wl.addWidget(self.split)
        v.addWidget(work, 1)

        # -- galeria
        gal = QFrame()
        gal.setObjectName("panel")
        gal.setMinimumWidth(250)
        gl = QVBoxLayout(gal)
        gl.setContentsMargins(10, 10, 10, 10)
        gl.setSpacing(6)
        t = QLabel("Galeria")
        t.setObjectName("panelTitle")
        gl.addWidget(t)
        from PySide6.QtWidgets import QGridLayout
        self.gal_grid = QGridLayout()
        self.gal_grid.setSpacing(6)
        self.b_add = QPushButton(icons.icon("add", "#FFFFFF"), " Adicionar fotos")
        self.b_add.setObjectName("primary")
        self.b_add.setToolTip("Escolher arquivos de imagem (PNG, JPEG, BMP). Também é possível "
                              "arrastar arquivos e pastas para a galeria.")
        self.b_capfolder = QPushButton(icons.icon("folder"), " Abrir pasta de capturas")
        self.b_capfolder.setToolTip("Escolher imagens na pasta do Capture Pro")
        from PySide6.QtWidgets import QComboBox, QSpinBox
        self.b_select = QPushButton(icons.icon("check_all"), " Selecionar fotos")
        self.b_select.setToolTip("Seleciona automaticamente o TOTAL de fotos indicado em “Quantidade”, "
                                 "na ordem visível da galeria, e monta as páginas no modelo escolhido "
                                 "em “Fotos por página”.")
        self.sp_qty = QSpinBox()
        self.sp_qty.setRange(1, 999)
        self.sp_qty.setPrefix("Quantidade: ")
        self.sp_qty.setToolTip("Total de fotos a selecionar (não é por página)")
        self.sp_qty.setValue(int(self.s.get("quantidade_selecao", 6) or 6))
        self.sel_box = QWidget()
        sb_l = QHBoxLayout(self.sel_box)
        sb_l.setContentsMargins(0, 0, 0, 0)
        sb_l.setSpacing(4)
        sb_l.addWidget(self.b_select, 1)
        sb_l.addWidget(self.sp_qty)
        self.b_none = QPushButton(icons.icon("uncheck_all"), " Desmarcar todas")
        self.b_none.setToolTip("Retira todas as fotos da impressão (continuam na galeria)")
        self._gal_buttons = [self.b_add, self.b_capfolder, self.sel_box, self.b_none]
        self._gal_cols = 0
        gl.addLayout(self.gal_grid)
        gal.installEventFilter(self)
        self._gal_panel = gal
        self._layout_gallery_buttons(2)
        r_sort = QHBoxLayout()
        r_sort.addWidget(QLabel("Ordenar galeria:"))
        self.cb_sort = QComboBox()
        for k, v in (("importacao", "Ordem de importação"), ("nome", "Nome do arquivo"),
                     ("captura", "Data de captura"), ("personalizada", "Personalizada (arrastar)")):
            self.cb_sort.addItem(v, k)
        self.cb_sort.setToolTip("Muda só a ordem da galeria. A impressão não é alterada.")
        r_sort.addWidget(self.cb_sort, 1)
        gl.addLayout(r_sort)
        r3 = QHBoxLayout()
        self.b_watch = QPushButton(icons.icon("watch"), " Acompanhar capturas")
        self.b_watch.setCheckable(True)
        self.b_watch.setToolTip("Mostra na galeria, automaticamente, as novas fotos salvas pelo Capture Pro "
                                "(entram como disponíveis, sem marcar).")
        self.l_watch = QLabel("")
        self.l_watch.setObjectName("hint")
        self.l_watch.setWordWrap(True)
        r3.addWidget(self.b_watch)
        r3.addWidget(self.l_watch, 1)
        gl.addLayout(r3)
        self.gmodel = GalleryModel(self.thumbs, self)
        self.gview = GalleryView(self.gmodel)
        gl.addWidget(self.gview, 1)
        self.l_import = QLabel("")
        self.l_import.setObjectName("hint")
        gl.addWidget(self.l_import)
        self.split.addWidget(gal)

        # -- prévia
        pv = QFrame()
        pv.setObjectName("panel")
        pl = QVBoxLayout(pv)
        pl.setContentsMargins(8, 8, 8, 8)
        pl.setSpacing(6)
        bar = QHBoxLayout()
        t2 = QLabel("Prévia da folha")
        t2.setObjectName("panelTitle")
        bar.addWidget(t2)
        bar.addStretch(1)
        self.b_prev = self._tool("prev", "Página anterior (Page Up)")
        self.l_page = QLabel("—")
        self.l_page.setMinimumWidth(110)
        self.l_page.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.b_next = self._tool("next", "Próxima página (Page Down)")
        self.b_fitp = self._tool("fit_page", "Ajustar à página", True)
        self.b_fitw = self._tool("fit_width", "Ajustar à largura", True)
        self.b_zout = self._tool("zoom_out", "Reduzir (Ctrl + roda do mouse)")
        self.b_zin = self._tool("zoom_in", "Ampliar (Ctrl + roda do mouse)")
        self.b_undo = self._tool("undo", "Desfazer (Ctrl+Z)")
        self.b_redo = self._tool("redo", "Refazer (Ctrl+Y)")
        for w in (self.b_undo, self.b_redo):
            bar.addWidget(w)
        bar.addSpacing(10)
        for w in (self.b_prev, self.l_page, self.b_next):
            bar.addWidget(w)
        bar.addSpacing(10)
        for w in (self.b_fitp, self.b_fitw, self.b_zout, self.b_zin):
            bar.addWidget(w)
        pl.addLayout(bar)
        self.banner = QFrame()
        self.banner.setObjectName("infoBanner")
        bl = QHBoxLayout(self.banner)
        bl.setContentsMargins(10, 5, 6, 5)
        self.l_banner = QLabel("")
        self.l_banner.setWordWrap(True)
        bx = QToolButton()
        bx.setText("×")
        bx.setAutoRaise(True)
        bx.clicked.connect(self.banner.hide)
        bl.addWidget(self.l_banner, 1)
        bl.addWidget(bx)
        self.banner.hide()
        self._banner_timer = QTimer(self)
        self._banner_timer.setSingleShot(True)
        self._banner_timer.timeout.connect(self.banner.hide)
        pl.addWidget(self.banner)
        self.preview = PreviewArea()
        pl.addWidget(self.preview, 1)
        self.split.addWidget(pv)

        # -- páginas
        self.pages = PagesPanel()
        self.split.addWidget(self.pages)
        self.split.setStretchFactor(0, 30)
        self.split.setStretchFactor(1, 55)
        self.split.setStretchFactor(2, 15)
        self.split.setSizes([400, 760, 250])

        # barra inferior
        sb = self.statusBar()
        sb.setSizeGripEnabled(True)
        self.l_avail = QLabel()
        self.l_sel = QLabel()
        self.l_pages = QLabel()
        self.l_save = QLabel()
        for w in (self.l_avail, self.l_sel, self.l_pages):
            sb.addWidget(w)
        sb.addWidget(self.l_save, 1)
        self.zoom = QSlider(Qt.Orientation.Horizontal)
        self.zoom.setRange(25, 400)
        self.zoom.setFixedWidth(150)
        self.zoom.setToolTip("Zoom da prévia")
        self.l_zoom = QLabel("100%")
        self.l_zoom.setMinimumWidth(48)
        sb.addPermanentWidget(QLabel("Zoom:"))
        sb.addPermanentWidget(self.zoom)
        sb.addPermanentWidget(self.l_zoom)

        # ligações
        self.b_add.clicked.connect(self.add_photos)
        self.b_capfolder.clicked.connect(self.pick_from_capture_folder)
        self.b_select.clicked.connect(self.select_photos)
        self.b_none.clicked.connect(self.clear_composition)
        self.cb_sort.activated.connect(lambda _i: self.sort_gallery(self.cb_sort.currentData()))
        self.sp_qty.valueChanged.connect(lambda v: self.s.data.__setitem__("quantidade_selecao", v))
        self.b_watch.toggled.connect(self.toggle_watch)
        self.gview.toggle_requested.connect(self.toggle_ids)
        self.gview.reorder_requested.connect(self.reorder_gallery)
        self.gview.files_dropped.connect(self.import_paths)
        self.gview.open_requested.connect(self.view_image)
        self.gview.context_requested.connect(self.gallery_menu)
        self.gview.delete_requested.connect(self.remove_from_print)
        c = self.preview.canvas
        c.drop_requested.connect(self.drop_on_cell)
        c.open_requested.connect(self.view_image)
        c.context_requested.connect(self.preview_menu)
        c.delete_requested.connect(self.remove_from_print)
        c.page_clicked.connect(self._page_from_preview)
        c.cell_selected.connect(self._cell_from_preview)
        self.preview.current_page_changed.connect(self._page_scrolled)
        self.preview.zoom_changed.connect(self._zoom_changed)
        self.b_prev.clicked.connect(lambda: self.go_page(self.current_page - 1))
        self.b_next.clicked.connect(lambda: self.go_page(self.current_page + 1))
        self.b_fitp.clicked.connect(lambda: self._fit("pagina"))
        self.b_fitw.clicked.connect(lambda: self._fit("largura"))
        self.b_zin.clicked.connect(lambda: self.preview.zoom_by(1.2))
        self.b_zout.clicked.connect(lambda: self.preview.zoom_by(1 / 1.2))
        self.b_undo.clicked.connect(self.undo)
        self.b_redo.clicked.connect(self.redo)
        self.zoom.valueChanged.connect(self._slider_zoom)
        self.pages.template_page.connect(self.apply_template_page)
        self.pages.template_all.connect(self.apply_template_all)
        self.pages.compact_requested.connect(self.compact)
        self.pages.template_chosen.connect(lambda t: setattr(self.exam, "default_template", t) if self.exam else None)
        self.pages.page_selected.connect(self.go_page)
        self.pages.add_page.connect(self.add_page)
        self.pages.delete_page.connect(self.delete_page)
        self.pages.move_page.connect(self.move_page)
        for key, d in ((Qt.Key.Key_PageUp, -1), (Qt.Key.Key_PageDown, 1)):
            a = QAction(self)
            a.setShortcut(QKeySequence(key))
            a.triggered.connect(lambda _c=False, d=d: self.go_page(self.current_page + d))
            self.addAction(a)

    def _layout_gallery_buttons(self, cols: int) -> None:
        if cols == self._gal_cols:
            return
        self._gal_cols = cols
        for b in self._gal_buttons:
            self.gal_grid.removeWidget(b)
        for k, b in enumerate(self._gal_buttons):
            self.gal_grid.addWidget(b, k // cols, k % cols)

    def eventFilter(self, obj, ev):
        from PySide6.QtCore import QEvent
        if obj is getattr(self, "_gal_panel", None) and ev.type() == QEvent.Type.Resize:
            need = max(b.sizeHint().width() for b in self._gal_buttons) * 2 + 30
            self._layout_gallery_buttons(2 if obj.width() >= need else 1)
        return super().eventFilter(obj, ev)

    def _tool(self, name: str, tip: str, checkable: bool = False) -> QToolButton:
        b = QToolButton()
        b.setIcon(icons.icon(name))
        b.setIconSize(QSize(18, 18))
        b.setToolTip(tip)
        b.setCheckable(checkable)
        b.setAutoRaise(True)
        return b

    # ================================================================ janela
    def _restore_window(self) -> None:
        j = self.s.get("janela") or {}
        try:
            if j.get("geometria"):
                self.restoreGeometry(QByteArray(base64.b64decode(j["geometria"])))
            else:
                self.resize(1440, 900)
            sizes = j.get("divisores")
            if isinstance(sizes, list) and len(sizes) == 3 and all(isinstance(x, int) and x > 50 for x in sizes):
                self.split.setSizes(sizes)
        except Exception:
            self.resize(1440, 900)
        self.preview.mode = self.s.get("zoom") if self.s.get("zoom") in ("pagina", "largura") else "pagina"
        self.b_fitp.setChecked(self.preview.mode == "pagina")
        self.b_fitw.setChecked(self.preview.mode == "largura")

    def _store_window(self) -> None:
        self.s["janela"] = {
            "geometria": base64.b64encode(bytes(self.saveGeometry())).decode(),
            "divisores": self.split.sizes(),
        }
        self.s["zoom"] = self.preview.mode if self.preview.mode in ("pagina", "largura") else "pagina"
        try:
            self.s.save()
        except OSError:
            pass

    # ================================================================ exame atual
    def store(self) -> ExamStore:
        return ExamStore(self.s["pasta_exames"])

    def set_exam(self, exam: Exam | None, folder: str, dirty: bool = False) -> None:
        self.exam = exam
        self.folder = folder
        self.undo_stack.clear()
        self.redo_stack.clear()
        self.dirty = dirty
        self.save_error = ""
        self.current_page = 0
        self.thumbs.reset(folder)
        if exam is not None:
            self.provider = compose.FileImageProvider(folder, ExamStore.logo_path(exam, folder))
            self.s.begin_session(folder)
        else:
            # sem exame aberto: a sessão só é encerrada no fechamento normal do programa
            # (a de uma queda anterior precisa continuar visível para a recuperação)
            self.provider = None
        self.gmodel.set_exam(exam)
        self.preview.canvas.set_exam(exam, self.provider)
        self._fill_ident_fields()
        self._sync_sort_combo()
        has = exam is not None
        for w in (self.a_save, self.a_pdf, self.a_print, self.b_add, self.b_capfolder, self.b_select,
                  self.sp_qty, self.b_none, self.cb_sort, self.e_name, self.e_date, self.b_watch):
            w.setEnabled(has)
        self.pages.set_chosen(exam.default_template if exam else self.s["modelo_inicial"])
        self._refresh_meta()
        QTimer.singleShot(0, self.preview.apply_fit)
        self._update_title()
        if has and self.s.get("acompanhar_pasta"):
            self.start_watch(silent=True)
        elif not has:
            self.stop_watch()

    def _fill_ident_fields(self) -> None:
        for w in (self.e_name, self.e_date):
            w.blockSignals(True)
        if self.exam:
            self.e_name.setText(self.exam.patient)
            try:
                d = _dt.date.fromisoformat(self.exam.date)
                self.e_date.setDate(QDate(d.year, d.month, d.day))
            except ValueError:
                self.e_date.setDate(QDate.currentDate())
        else:
            self.e_name.clear()
            self.e_date.setDate(QDate.currentDate())
        for w in (self.e_name, self.e_date):
            w.blockSignals(False)

    def _apply_ident_fields(self) -> None:
        if not self.exam:
            return
        name = " ".join(self.e_name.text().split())
        q = self.e_date.date()
        date = _dt.date(q.year(), q.month(), q.day()).isoformat()
        if not name:
            return  # nome vazio não é aplicado (mantém o anterior)
        if name != self.exam.patient or date != self.exam.date:
            self.exam.patient = name
            self.exam.date = date
            self._changed()

    def _update_title(self) -> None:
        if self.exam:
            mark = " •" if self.dirty else ""
            self.setWindowTitle(f"{self.exam.patient} — {self.exam.date_br()}{mark} — {APP_NAME}")
        else:
            self.setWindowTitle(f"{APP_NAME} {__version__}")

    # ================================================================ mudanças
    def mutate(self, label: str, fn) -> C.Report | None:
        if not self.exam:
            return None
        before = self.exam.snapshot()
        rep = fn()
        if self.exam.snapshot() == before:
            if rep is not None and rep.text():
                self.info(rep.text(), warn=bool(rep.error))
            return rep
        self.undo_stack.append((label, before))
        del self.undo_stack[:-UNDO_LIMIT]
        self.redo_stack.clear()
        self._changed()
        if rep is not None and rep.text():
            self.info(rep.text(), warn=bool(rep.error))
        return rep

    def _changed(self) -> None:
        self.dirty = True
        self.preview.canvas.invalidate()
        self._meta_timer.start()
        self._autosave_timer.start()
        self._update_title()

    def _restore_snapshot(self, snap: dict) -> None:
        # imagens importadas depois do instantâneo continuam na galeria (disponíveis)
        known = {x["id"] for x in snap["imagens"]}
        extra = [it for it in self.exam.images if it.id not in known]
        self.exam.restore(snap)
        self.exam.images.extend(extra)
        self.exam.sanitize_slots()
        self.provider.invalidate()
        self.gmodel.reset_rows()
        self._sync_sort_combo()
        self._changed()

    def undo(self) -> None:
        if not self.exam or not self.undo_stack:
            return
        label, snap = self.undo_stack.pop()
        self.redo_stack.append((label, self.exam.snapshot()))
        self._restore_snapshot(snap)
        self.info(f"Desfeito: {label}")

    def redo(self) -> None:
        if not self.exam or not self.redo_stack:
            return
        label, snap = self.redo_stack.pop()
        self.undo_stack.append((label, self.exam.snapshot()))
        self._restore_snapshot(snap)
        self.info(f"Refeito: {label}")

    def _refresh_meta(self) -> None:
        ex = self.exam
        self.a_undo.setEnabled(bool(ex and self.undo_stack))
        self.a_redo.setEnabled(bool(ex and self.redo_stack))
        self.b_undo.setEnabled(self.a_undo.isEnabled())
        self.b_redo.setEnabled(self.a_redo.isEnabled())
        if not ex:
            self.gmodel.refresh({}, {}, set(), set())
            self.pages.refresh(None, 0)
            self.l_avail.setText("Fotos na galeria: 0")
            self.l_sel.setText("")
            self.l_pages.setText("")
            self._set_save_label()
            self.l_page.setText("—")
            return
        seq = ex.sequence()
        order = {it.id: k + 1 for k, it in enumerate(seq)}
        cells = ex.placements()
        lowres: set[str] = set()
        logo = self.provider.logo() if self.provider else None
        for i in range(len(ex.pages)):
            for pl in compose.plan_page(ex, i, logo).placed:
                if pl.dpi and pl.dpi < L.LOW_DPI:
                    lowres.add(pl.image_id)
        missing = {it.id for it in ex.images if not os.path.isfile(os.path.join(self.folder, it.file))}
        self.gmodel.refresh(cells, order, lowres, missing)
        n = len(ex.pages)
        self.current_page = max(0, min(self.current_page, max(0, n - 1)))
        self.pages.refresh(ex, self.current_page)
        self.l_avail.setText(f"Fotos na galeria: {len(ex.images)}")
        self.l_sel.setText(C.status_text(ex))
        self.l_pages.setText("")
        self.l_page.setText(f"Página {self.current_page + 1} de {n}" if n else "Sem páginas")
        self.b_prev.setEnabled(self.current_page > 0)
        self.b_next.setEnabled(self.current_page < n - 1)
        self._set_save_label()

    def _set_save_label(self) -> None:
        if not self.exam:
            self.l_save.setText("")
            return
        if self.save_error:
            self.l_save.setObjectName("statusErr")
            self.l_save.setText(f"⚠ Falha ao salvar: {self.save_error}")
        elif self.dirty:
            self.l_save.setObjectName("statusPending")
            extra = f" (rascunho salvo às {self.last_autosave[:5]})" if self.last_autosave else ""
            self.l_save.setText(f"● Alterações pendentes{extra}")
        else:
            never = not self.store().is_saved(self.folder) if self.folder else False
            self.l_save.setObjectName("statusOk" if not never else "muted")
            self.l_save.setText("✓ Exame salvo" if not never else "Exame novo (ainda não salvo)")
        self.l_save.style().unpolish(self.l_save)
        self.l_save.style().polish(self.l_save)

    def info(self, text: str, warn: bool = False, ms: int = 9000) -> None:
        self.banner.setObjectName("banner" if warn else "infoBanner")
        self.banner.style().unpolish(self.banner)
        self.banner.style().polish(self.banner)
        self.l_banner.setText(text)
        self.banner.show()
        self._banner_timer.start(ms)

    # ================================================================ salvamento
    def autosave(self) -> None:
        if not self.exam or not self.dirty:
            return
        try:
            self.store().autosave(self.exam, self.folder)
            self.save_error = ""
            self.last_autosave = _dt.datetime.now().strftime("%H:%M:%S")
        except StoreError as e:
            first = not self.save_error
            self.save_error = str(e)
            if first:
                QMessageBox.warning(self, "Salvamento automático", str(e))
        self._set_save_label()

    def save_exam(self) -> bool:
        if not self.exam:
            return False
        self._apply_ident_fields()
        try:
            self.store().save(self.exam, self.folder)
        except StoreError as e:
            self.save_error = str(e)
            self._set_save_label()
            QMessageBox.critical(self, "Salvar exame", str(e))
            return False
        self.dirty = False
        self.save_error = ""
        self.last_autosave = ""
        self._autosave_timer.stop()
        self._set_save_label()
        self._update_title()
        self.info("Exame salvo.", ms=3000)
        return True

    def maybe_close_exam(self) -> bool:
        """Trata alterações pendentes. True = pode prosseguir."""
        if not self.exam:
            return True
        self._apply_ident_fields()
        st = self.store()
        never = not st.is_saved(self.folder)
        if never and not self.exam.images:
            # exame criado e não usado: nada a perder
            try:
                st.discard(self.folder)
            except OSError:
                pass
            return True
        if not self.dirty and not never:
            return True
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Question)
        box.setWindowTitle("Alterações pendentes")
        box.setText(f"Salvar o exame de <b>{self.exam.patient}</b> ({self.exam.date_br()})?")
        box.setInformativeText("Se não salvar, as alterações desde o último salvamento serão descartadas."
                               + (" Este exame nunca foi salvo: ele irá para a pasta "
                                  "“_descartados” dos exames." if never else ""))
        b_save = box.addButton("Salvar", QMessageBox.ButtonRole.AcceptRole)
        b_disc = box.addButton("Não salvar", QMessageBox.ButtonRole.DestructiveRole)
        box.addButton("Cancelar", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(b_save)
        box.exec()
        if box.clickedButton() is b_save:
            return self.save_exam()
        if box.clickedButton() is b_disc:
            try:
                if never:
                    st.discard(self.folder)
                else:
                    st.discard_draft(self.folder)
            except OSError:
                pass
            self.dirty = False
            return True
        return False

    # ================================================================ novo / abrir
    def new_exam(self) -> None:
        if not self.maybe_close_exam():
            return
        dlg = NewExamDialog(self)
        if not dlg.exec():
            return
        name, date = dlg.values()
        try:
            exam, folder = self.store().create(name, date, self.s.identity(), self.s.logo_file(),
                                               self.s["modelo_inicial"])
        except StoreError as e:
            QMessageBox.critical(self, "Novo exame", str(e))
            return
        self.set_exam(exam, folder)
        if self.watcher is not None:
            self.watcher.request_reset()
            self.info("Novo exame: o acompanhamento da pasta recomeçou — só entram capturas feitas a partir de agora.")

    def open_exam(self) -> None:
        dlg = OpenExamDialog(self.store().list_exams(), self)
        if not dlg.exec() or not dlg.chosen:
            return
        summ = dlg.chosen
        if self.exam and os.path.normcase(os.path.abspath(summ.folder)) == os.path.normcase(os.path.abspath(self.folder)):
            pass
        elif not self.maybe_close_exam() or not self.load_exam(summ.folder):
            return
        if dlg.action == "pdf":
            self.export_pdf()
        elif dlg.action == "imprimir":
            self.print_exam()

    def load_exam(self, folder: str, prefer_draft: bool | None = None) -> bool:
        st = self.store()
        if prefer_draft is None and st.has_draft(folder) and st.is_saved(folder):
            box = QMessageBox(self)
            box.setWindowTitle("Abrir exame")
            box.setText("Este exame tem alterações que não foram salvas (rascunho automático).")
            b1 = box.addButton("Abrir com as alterações", QMessageBox.ButtonRole.AcceptRole)
            box.addButton("Abrir a versão salva", QMessageBox.ButtonRole.RejectRole)
            box.exec()
            prefer_draft = box.clickedButton() is b1
        try:
            exam, notes = st.load(folder, prefer_draft=bool(prefer_draft))
        except StoreError as e:
            QMessageBox.critical(self, "Abrir exame", str(e))
            return False
        dirty = bool(prefer_draft) or not st.is_saved(folder)
        self.set_exam(exam, folder, dirty=dirty)
        if not prefer_draft:
            st.discard_draft(folder) if st.is_saved(folder) else None
        if notes:
            self.info(" ".join(notes), warn=True, ms=15000)
        return True

    def offer_recovery(self) -> None:
        folder = self.s.interrupted_session()
        if not folder:
            return
        st = self.store()
        if not st.has_draft(folder):
            self.s.end_session()
            return
        try:
            exam, _ = st.load(folder, prefer_draft=True)
        except StoreError:
            return
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Warning)
        box.setWindowTitle("Recuperar trabalho")
        box.setText(f"O programa foi fechado sem salvar o exame de <b>{exam.patient}</b> "
                    f"({exam.date_br()}).")
        box.setInformativeText("Deseja recuperar o trabalho a partir do último rascunho automático?")
        b1 = box.addButton("Recuperar", QMessageBox.ButtonRole.AcceptRole)
        box.addButton("Agora não", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        if box.clickedButton() is b1:
            self.load_exam(folder, prefer_draft=True)
            self.info("Trabalho recuperado do rascunho automático. Clique em “Salvar exame” para confirmar.",
                      ms=15000)
        else:
            self.s.end_session()
            self.info("O rascunho continua guardado e aparece em “Abrir exame”.", ms=8000)

    # ================================================================ importação
    def add_photos(self) -> None:
        if not self.exam:
            return
        start = self.s.get("ultima_pasta_fotos") or self.s["pasta_capturas"]
        paths, _ = QFileDialog.getOpenFileNames(self, "Adicionar fotos", start, IMG_FILTER)
        if paths:
            self.s["ultima_pasta_fotos"] = os.path.dirname(paths[0])
            self.import_paths(paths)

    def pick_from_capture_folder(self) -> None:
        if not self.exam:
            return
        folder = self.s["pasta_capturas"]
        if not os.path.isdir(folder):
            QMessageBox.information(self, "Pasta de capturas",
                                    f"A pasta de capturas não foi encontrada:\n{folder}\n\n"
                                    "Ajuste em Configurações → Pastas.")
            return
        paths, _ = QFileDialog.getOpenFileNames(self, "Escolher capturas", folder, IMG_FILTER)
        if paths:
            self.import_paths(paths)

    def import_paths(self, paths: list[str], from_watch: bool = False) -> None:
        if not self.exam or not paths:
            return
        w = ImportWorker(self.store(), self.exam, self.folder, paths, from_watch, self)
        exam_id = self.exam.id
        w.item_ready.connect(lambda it, fw, eid=exam_id: self._imported(it, fw, eid))
        w.progress.connect(lambda a, b: self.l_import.setText(f"Importando {a} de {b}…" if a < b else ""))
        w.finished_report.connect(lambda rep, fw=from_watch, ww=w: self._import_done(rep, fw, ww))
        self.importers.append(w)
        w.start()

    def _imported(self, it: ImageItem, from_watch: bool, exam_id: str) -> None:
        if not self.exam or self.exam.id != exam_id:
            return  # exame trocado durante a importação
        if self.exam.find_by_hash(it.sha256):
            return
        row = len(self.exam.images)
        self.gmodel.beginInsertRows(self.gmodel.index(0).parent(), row, row)
        self.exam.images.append(it)
        self.gmodel.endInsertRows()
        if from_watch:
            self.gmodel.fresh.add(it.id)
            self.gview.scrollToBottom()
        self._changed()

    def _import_done(self, rep: dict, from_watch: bool, w: ImportWorker) -> None:
        if w in self.importers:
            self.importers.remove(w)
        self.l_import.setText("")
        parts = []
        if rep.get("importadas"):
            parts.append(f"{rep['importadas']} foto(s) adicionada(s)" + (" (nova captura)" if from_watch else ""))
        if rep.get("duplicadas"):
            parts.append(f"{rep['duplicadas']} já estava(m) no exame (não repetida(s))")
        if rep.get("falhas"):
            parts.append(f"{len(rep['falhas'])} ignorada(s): " + "; ".join(rep["falhas"][:3]))
        if rep.get("erro"):
            QMessageBox.warning(self, "Importação", rep["erro"])
        if not rep.get("total") and not from_watch:
            parts.append("Nenhum arquivo PNG, JPEG ou BMP encontrado")
        if parts:
            self.info(" · ".join(parts), warn=bool(rep.get("falhas")) or not rep.get("total"))
        if rep.get("importadas") and not from_watch and not self.exam.sequence():
            self.info(" · ".join(parts) + ". Marque as fotos (clique na caixa ou tecla Espaço) para "
                      "colocá-las nas páginas.")

    # ================================================================ acompanhamento
    def toggle_watch(self, on: bool) -> None:
        if on:
            self.start_watch(silent=False)
        else:
            self.stop_watch()
            self.s["acompanhar_pasta"] = False

    def start_watch(self, silent: bool) -> None:
        if not self.exam:
            self.b_watch.setChecked(False)
            return
        if self.watcher is not None:
            self.watcher.request_reset()
            return
        folder = self.s["pasta_capturas"]
        if not os.path.isdir(folder):
            self.b_watch.blockSignals(True)
            self.b_watch.setChecked(False)
            self.b_watch.blockSignals(False)
            if not silent:
                QMessageBox.information(self, "Acompanhar capturas",
                                        f"A pasta de capturas não foi encontrada:\n{folder}\n\n"
                                        "Escolha a pasta em Configurações → Pastas.")
            self.l_watch.setText("pasta não encontrada")
            return
        from ..core.watcher import FolderWatcherThread
        w = FolderWatcherThread(folder, parent=self)
        n = w.scanner.reset_baseline()
        w.found.connect(lambda paths: self.import_paths(paths, from_watch=True))
        w.problem.connect(lambda msg: self.l_watch.setText(msg or self._watch_text()))
        self.watcher = w
        w.start()
        self.s["acompanhar_pasta"] = True
        self.b_watch.blockSignals(True)
        self.b_watch.setChecked(True)
        self.b_watch.setIcon(icons.icon("watch", "#1E8E4E"))
        self.b_watch.blockSignals(False)
        self.l_watch.setText(self._watch_text())
        if n and not silent:
            box = QMessageBox(self)
            box.setWindowTitle("Acompanhar capturas")
            box.setText(f"A pasta de capturas já tem {n} imagem(ns) de antes.")
            box.setInformativeText("Elas não serão incluídas automaticamente, para não misturar pacientes. "
                                   "Só as novas capturas aparecerão na galeria.")
            box.addButton("Somente novas capturas", QMessageBox.ButtonRole.AcceptRole)
            b2 = box.addButton("Escolher entre as existentes…", QMessageBox.ButtonRole.ActionRole)
            box.exec()
            if box.clickedButton() is b2:
                self.pick_from_capture_folder()

    def _watch_text(self) -> str:
        return f"acompanhando: {os.path.basename(self.s['pasta_capturas'].rstrip(os.sep)) or self.s['pasta_capturas']}"

    def stop_watch(self) -> None:
        if self.watcher is not None:
            self.watcher.stop()
            self.watcher = None
        self.b_watch.blockSignals(True)
        self.b_watch.setChecked(False)
        self.b_watch.setIcon(icons.icon("watch"))
        self.b_watch.blockSignals(False)
        self.l_watch.setText("pausado" if self.exam else "")

    # ================================================================ seleção e ordem
    def toggle_ids(self, ids: list[str]) -> None:
        """Marcar = incluir na impressão (próxima célula vazia, ou a célula vazia selecionada
        na prévia); desmarcar = retirar (a célula fica vazia)."""
        if not self.exam:
            return
        ids = [i for i in ids if self.exam.image(i)]
        unused = [i for i in ids if not self.exam.is_used(i)]
        if unused:
            target = self.preview.canvas.selected_empty_cell()
            tpl = self.pages.chosen()
            self.mutate("Incluir na impressão",
                        lambda: C.add_to_composition(self.exam, unused, target=target, template=tpl))
            if target:
                self.preview.canvas.select_cell(None)
            for i in unused:
                self.gmodel.fresh.discard(i)
        else:
            self.remove_from_print(ids)

    def remove_from_print(self, ids: list[str]) -> None:
        """Retirar da página: a foto continua na galeria; a célula fica vazia."""
        if self.exam:
            used = [i for i in ids if self.exam.is_used(i)]
            if used:
                self.mutate("Retirar da página", lambda: C.remove_from_composition(self.exam, used))

    def clear_composition(self) -> None:
        if self.exam and self.exam.pages:
            self.mutate("Desmarcar todas", lambda: C.clear_composition(self.exam))
            self.preview.canvas.select_cell(None)

    def select_photos(self) -> None:
        """Selecionar fotos: TOTAL = quantidade; modelo = Fotos por página."""
        if not self.exam:
            return
        n = self.sp_qty.value()
        tpl = self.pages.chosen()
        gallery_ids = [it.id for it in self.exam.images]
        mode = "refazer"
        if self.exam.sequence():
            box = QMessageBox(self)
            box.setWindowTitle("Selecionar fotos")
            box.setText(f"Já existe uma composição com {len(self.exam.sequence())} foto(s).")
            box.setInformativeText("Escolha o que fazer:")
            b_comp = box.addButton(f"Completar seleção até {n} fotos", QMessageBox.ButtonRole.AcceptRole)
            b_redo = box.addButton(f"Refazer seleção com {n} fotos", QMessageBox.ButtonRole.DestructiveRole)
            box.addButton("Cancelar", QMessageBox.ButtonRole.RejectRole)
            box.setDefaultButton(b_comp)
            box.exec()
            if box.clickedButton() is b_comp:
                mode = "completar"
            elif box.clickedButton() is b_redo:
                mode = "refazer"
            else:
                return
        label = f"Selecionar fotos ({n}, {TEMPLATE_LABEL[tpl]} por página)"
        self.mutate(label, lambda: C.auto_select(self.exam, gallery_ids, n, tpl, mode))
        self.preview.canvas.select_cell(None)
        if mode == "refazer":
            self.go_page(0)

    def sort_gallery(self, mode: str) -> None:
        if not self.exam or not mode:
            return
        if mode == "personalizada":
            self.exam.gallery_sort = mode
            return
        self.mutate("Ordenar galeria", lambda: C.sort_gallery(self.exam, mode))
        self.gmodel.reset_rows()

    def _sync_sort_combo(self) -> None:
        if self.exam:
            i = self.cb_sort.findData(self.exam.gallery_sort)
            self.cb_sort.setCurrentIndex(max(0, i))

    def reorder_gallery(self, ids: list[str], before_row: int) -> None:
        """Arrastar na galeria muda só a ordem da galeria (nunca a impressão)."""
        self.mutate("Reordenar galeria", lambda: C.move_images(self.exam, ids, before_row))
        self.gmodel.reset_rows()
        self._sync_sort_combo()
        sm = self.gview.selectionModel()
        for r, it in enumerate(self.exam.images):
            if it.id in ids:
                sm.select(self.gmodel.index(r), sm.SelectionFlag.Select)

    def drop_on_cell(self, ids: list[str], page: int, slot: int) -> None:
        """Soltar na prévia: vazia → colocar/mover; ocupada → trocar (foto já na impressão) ou
        substituir (a anterior volta para a galeria). Várias fotos: a partir desta célula."""
        if not self.exam or not ids:
            return
        if len(ids) == 1:
            kind = C.classify_drop(self.exam, ids[0], (page, slot))
            labels = {"colocar": "Colocar foto", "mover": "Mover foto", "trocar": "Trocar fotos",
                      "substituir": "Substituir foto"}
            if kind in labels:
                self.mutate(labels[kind], lambda: C.place(self.exam, ids[0], (page, slot)))
        else:
            new = [i for i in ids if not self.exam.is_used(i)]
            tgt = (page, slot) if not self.exam.pages[page].slots[slot] else None
            self.mutate("Colocar fotos",
                        lambda: C.add_to_composition(self.exam, new, target=tgt, template=self.pages.chosen()))
        for i in ids:
            self.gmodel.fresh.discard(i)
        self.preview.canvas.select_cell((page, slot))

    def choose_for_cell(self, page: int, slot: int) -> None:
        """Escolher (sem arrastar) a foto de uma célula, vazia ou ocupada."""
        if not self.exam:
            return
        cur = self.exam.pages[page].slots[slot]
        title = f"Escolher foto para P{page + 1} · posição {slot + 1}" if not cur else \
            f"Substituir a foto de P{page + 1} · posição {slot + 1}"
        dlg = PhotoPickerDialog(self.exam, self.thumbs, title, self)
        if dlg.exec() and dlg.chosen:
            iid = dlg.chosen
            kind = C.classify_drop(self.exam, iid, (page, slot))
            if kind != "nada":
                self.mutate({"colocar": "Colocar foto", "mover": "Mover foto", "trocar": "Trocar fotos",
                             "substituir": "Substituir foto"}[kind],
                            lambda: C.place(self.exam, iid, (page, slot)))

    def compact(self) -> None:
        if self.exam and self.exam.pages:
            self.mutate("Reorganizar e preencher espaços", lambda: C.compact(self.exam))

    # ================================================================ páginas
    def go_page(self, i: int) -> None:
        if not self.exam:
            return
        n = compose.page_count(self.exam)
        i = max(0, min(n - 1, i))
        self.current_page = i
        self.preview.go_to(i)
        self._refresh_meta()

    def _page_from_preview(self, i: int) -> None:
        self.current_page = i
        self._refresh_meta()

    def _page_scrolled(self, i: int) -> None:
        if self.current_page != i:
            self.current_page = i
            self.preview.canvas.current_page = i
            self.preview.canvas.update()
            self._refresh_meta()

    def _cell_from_preview(self, page: int, slot: int, iid: str) -> None:
        if iid:
            for r, it in enumerate(self.exam.images):
                if it.id == iid:
                    ix = self.gmodel.index(r)
                    self.gview.setCurrentIndex(ix)
                    self.gview.scrollTo(ix)
                    break
        elif page >= 0:
            self.info(f"Célula vazia selecionada: P{page + 1} · posição {slot + 1}. Marque uma foto na "
                      "galeria (ou arraste-a) para colocá-la aqui. Esc cancela.", ms=7000)


    def apply_template_page(self, tpl: str) -> None:
        if not self.exam or not self.exam.pages:
            return
        p = self.current_page
        self.mutate(f"Modelo da página {p + 1}", lambda: C.set_template(self.exam, p, tpl))

    def apply_template_all(self, tpl: str) -> None:
        if self.exam:
            self.mutate("Modelo de todas as páginas", lambda: C.set_template_all(self.exam, tpl))

    def add_page(self) -> None:
        if not self.exam:
            return
        tpl = self.pages.chosen()
        after = self.current_page if self.exam.pages else -1
        self.mutate("Adicionar página", lambda: C.add_page(self.exam, after, tpl))
        self.go_page(after + 1)

    def delete_page(self) -> None:
        if not self.exam or not self.exam.pages:
            return
        i = self.current_page
        ids = self.exam.pages[i].used()
        keep = False
        if ids:
            box = QMessageBox(self)
            box.setWindowTitle("Excluir página")
            box.setText(f"A página {i + 1} tem {len(ids)} foto(s). O que fazer com elas?")
            b1 = box.addButton("Devolver à galeria", QMessageBox.ButtonRole.AcceptRole)
            b2 = box.addButton("Passar para as páginas seguintes", QMessageBox.ButtonRole.ActionRole)
            box.addButton("Cancelar", QMessageBox.ButtonRole.RejectRole)
            box.exec()
            if box.clickedButton() not in (b1, b2):
                return
            keep = box.clickedButton() is b2
        self.mutate("Excluir página", lambda: C.delete_page(self.exam, i, keep))
        self.go_page(min(i, max(0, len(self.exam.pages) - 1)))

    def move_page(self, d: int) -> None:
        if not self.exam:
            return
        i = self.current_page
        j = i + d
        if not 0 <= j < len(self.exam.pages):
            return
        self.mutate("Mover página", lambda: C.move_page(self.exam, i, j))
        self.go_page(j)

    # ================================================================ edição
    def view_image(self, iid: str) -> None:
        it = self.exam.image(iid) if self.exam else None
        if not it:
            return
        img = self.provider.edited(it, None)
        if img is None:
            QMessageBox.warning(self, "Ampliar", "A imagem não foi encontrada na pasta do exame.")
            return
        ImageViewer(img, it.original_name, self).exec()

    def crop_image(self, iid: str) -> None:
        it = self.exam.image(iid) if self.exam else None
        if not it:
            return
        dlg = CropDialog(it, self.provider.path_of(it), self)
        if dlg.base is None or not dlg.exec():
            return
        rot, crop = dlg.rotation, dlg.result_crop.normalized()

        def run():
            it2 = self.exam.image(iid)
            it2.rotation, it2.crop = rot, crop
        self.mutate("Recortar/girar", run)

    def rotate(self, ids: list[str], deg: int) -> None:
        def run():
            for i in ids:
                it = self.exam.image(i)
                c = it.crop
                it.crop = (Crop(1 - c.y - c.h, c.x, c.h, c.w) if deg == 90 else
                           Crop(c.y, 1 - c.x - c.w, c.h, c.w)).normalized()
                it.rotation = (it.rotation + deg) % 360
        self.mutate("Girar", run)

    def restore_original(self, ids: list[str]) -> None:
        def run():
            for i in ids:
                it = self.exam.image(i)
                it.rotation, it.crop = 0, Crop()
        self.mutate("Restaurar original", run)

    def remove_from_exam(self, ids: list[str]) -> None:
        n = len(ids)
        used = [self.exam.placements()[i] for i in ids if self.exam.is_used(i)]
        extra = ""
        if used:
            where = ", ".join(f"P{p + 1}·{s + 1}" for p, s in used[:6]) + ("…" if len(used) > 6 else "")
            extra = (f"\n\nAtenção: {len(used)} delas estão na impressão ({where}); as células ficarão vazias.")
        r = QMessageBox.question(
            self, "Remover da galeria deste exame",
            f"Remover {n} foto(s) da galeria deste exame?{extra}\n\nO arquivo original no computador NÃO é "
            "apagado. É possível desfazer (Ctrl+Z).")
        if r != QMessageBox.StandardButton.Yes:
            return
        self.mutate("Remover da galeria deste exame", lambda: C.remove_images(self.exam, ids))
        self.gmodel.reset_rows()

    def _common_menu(self, m: QMenu, ids: list[str]) -> None:
        one = len(ids) == 1
        a = m.addAction(icons.icon("expand"), "Ampliar")
        a.setEnabled(one)
        a.triggered.connect(lambda: self.view_image(ids[0]))
        a = m.addAction(icons.icon("crop"), "Recortar…")
        a.setEnabled(one)
        a.triggered.connect(lambda: self.crop_image(ids[0]))
        sub = m.addMenu(icons.icon("rotate"), "Girar")
        sub.addAction(icons.icon("rotate"), "90° à direita", lambda: self.rotate(ids, 90))
        sub.addAction(icons.icon("rotate_l"), "90° à esquerda", lambda: self.rotate(ids, -90))
        sub.addAction("180°", lambda: (self.rotate(ids, 90), self.rotate(ids, 90)))
        a = m.addAction(icons.icon("restore"), "Restaurar original")
        a.setEnabled(any(self.exam.image(i).has_edits() for i in ids))
        a.triggered.connect(lambda: self.restore_original(ids))

    def gallery_menu(self, ids: list[str], pos) -> None:
        if not self.exam or not ids:
            return
        m = QMenu(self)
        self._common_menu(m, ids)
        m.addSeparator()
        used = [i for i in ids if self.exam.is_used(i)]
        unused = [i for i in ids if not self.exam.is_used(i)]
        target = self.preview.canvas.selected_empty_cell()
        if unused:
            m.addAction("Incluir na impressão\tEspaço", lambda: self.toggle_ids(unused))
            if target and len(unused) == 1:
                m.addAction(f"Colocar na célula selecionada (P{target[0] + 1} · posição {target[1] + 1})",
                            lambda: self.drop_on_cell(unused, target[0], target[1]))
        if used:
            m.addAction("Retirar da página\tDelete", lambda: self.remove_from_print(used))
        m.addSeparator()
        m.addAction(icons.icon("remove"), "Remover da galeria deste exame…", lambda: self.remove_from_exam(ids))
        m.exec(pos)

    def preview_menu(self, iid: str, page: int, slot: int, pos) -> None:
        if not self.exam:
            return
        m = QMenu(self)
        real = page < len(self.exam.pages)
        if iid:
            self._common_menu(m, [iid])
            m.addSeparator()
            m.addAction("Substituir por outra foto…", lambda: self.choose_for_cell(page, slot))
            m.addAction(icons.icon("prev"), "Trocar com a posição anterior",
                        lambda: self.mutate("Trocar posição", lambda: C.shift(self.exam, iid, -1)))
            m.addAction(icons.icon("next"), "Trocar com a posição seguinte",
                        lambda: self.mutate("Trocar posição", lambda: C.shift(self.exam, iid, +1)))
            mv = m.addMenu("Mover para a página")
            for k, pg in enumerate(self.exam.pages):
                free = pg.free()
                a = mv.addAction(f"Página {k + 1}" + ("  (cheia)" if not free else f"  ({free} vazia(s))"))
                a.setEnabled(k != page and free > 0)
                a.triggered.connect(lambda _c=False, k=k: self.mutate(
                    "Mover para outra página", lambda: C.move_to_page(self.exam, iid, k)))
            m.addAction("Retirar da página\tDelete", lambda: self.remove_from_print([iid]))
            m.addSeparator()
        elif real and slot >= 0:
            m.addAction("Escolher foto para esta posição…", lambda: self.choose_for_cell(page, slot))
            m.addSeparator()
        if real:
            sub = m.addMenu(f"Fotos por página (página {page + 1})")
            for t in TEMPLATES:
                a = sub.addAction(icons.template_pixmap(t, 18), TEMPLATE_LABEL[t])
                a.triggered.connect(lambda _c=False, t=t, p=page: self.mutate(
                    f"Modelo da página {p + 1}", lambda: C.set_template(self.exam, p, t)))
            m.addAction(icons.icon("auto"), "Reorganizar e preencher espaços", self.compact)
        m.addAction(icons.icon("page_add"), "Adicionar página depois desta", self.add_page)
        if real:
            m.addAction(icons.icon("page_del"), "Excluir esta página…", self.delete_page)
        m.exec(pos)

    # ================================================================ zoom
    def _fit(self, mode: str) -> None:
        self.preview.set_mode(mode)
        self.b_fitp.setChecked(mode == "pagina")
        self.b_fitw.setChecked(mode == "largura")

    def _zoom_changed(self, pct: int) -> None:
        self.zoom.blockSignals(True)
        self.zoom.setValue(max(25, min(400, pct)))
        self.zoom.blockSignals(False)
        self.l_zoom.setText(f"{pct}%")
        self.b_fitp.setChecked(self.preview.mode == "pagina")
        self.b_fitw.setChecked(self.preview.mode == "largura")

    def _slider_zoom(self, v: int) -> None:
        self.preview.set_percent(v)
        self.b_fitp.setChecked(False)
        self.b_fitw.setChecked(False)

    # ================================================================ saídas
    def _ready_for_output(self) -> bool:
        if not self.exam:
            return False
        self._apply_ident_fields()
        self._skip_pages: set[int] = set()
        if not self.exam.sequence():
            QMessageBox.information(self, APP_NAME, "Nenhuma foto na impressão. Use “Selecionar fotos” ou "
                                                    "marque as fotos na galeria.")
            return False
        empty = [i for i, pg in enumerate(self.exam.pages) if not pg.used()]
        if empty:
            box = QMessageBox(self)
            box.setWindowTitle("Páginas vazias")
            box.setText("Página(s) sem fotos: " + ", ".join(str(i + 1) for i in empty) + ".")
            b_skip = box.addButton("Ignorar páginas vazias", QMessageBox.ButtonRole.AcceptRole)
            b_keep = box.addButton("Incluir assim mesmo", QMessageBox.ButtonRole.ActionRole)
            box.addButton("Cancelar", QMessageBox.ButtonRole.RejectRole)
            box.setDefaultButton(b_skip)
            box.exec()
            if box.clickedButton() is b_skip:
                self._skip_pages = set(empty)
            elif box.clickedButton() is not b_keep:
                return False
        missing = [it.original_name for it in self.exam.sequence()
                   if not os.path.isfile(os.path.join(self.folder, it.file))]
        if missing:
            r = QMessageBox.warning(self, "Imagens ausentes",
                                    f"{len(missing)} foto(s) não foram encontradas na pasta do exame e "
                                    "aparecerão como “Imagem ausente”. Continuar?",
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if r != QMessageBox.StandardButton.Yes:
                return False
        return True

    def _output_exam(self, pages: list[int]) -> tuple[Exam, list[int]]:
        """Cópia do exame para a saída. Páginas vazias ignoradas saem da cópia, para que a
        numeração "Página X de Y" conte só as páginas impressas."""
        if not self._skip_pages:
            return self.exam, pages
        out = Exam.from_dict(self.exam.to_dict())
        keep = [i for i in range(len(out.pages)) if i not in self._skip_pages]
        new_index = {old: k for k, old in enumerate(keep)}
        out.pages = [out.pages[i] for i in keep]
        return out, [new_index[i] for i in pages if i in new_index]

    def export_pdf(self) -> None:
        if not self._ready_for_output() or self.pdf_worker is not None:
            return
        n = compose.page_count(self.exam)
        pages = list(range(n))
        if n > 1:
            d = PagesChoiceDialog(n, "Gerar PDF", self)
            if not d.exec():
                return
            pages = d.pages
        out_exam, pages = self._output_exam(pages)
        if not pages:
            return
        from ..render.output import suggested_pdf_name
        folder = self.s["pasta_pdfs"]
        try:
            os.makedirs(folder, exist_ok=True)
        except OSError:
            folder = os.path.expanduser("~")
        path, _ = QFileDialog.getSaveFileName(self, "Salvar PDF", os.path.join(folder, suggested_pdf_name(self.exam)),
                                              "PDF (*.pdf)")
        if not path:
            return
        if not path.lower().endswith(".pdf"):
            path += ".pdf"
            if os.path.exists(path):
                r = QMessageBox.question(self, "Substituir PDF", f"O arquivo já existe:\n{path}\n\nSubstituir?")
                if r != QMessageBox.StandardButton.Yes:
                    return
        prog = QProgressDialog("Gerando PDF…", None, 0, len(pages) + 1, self)
        prog.setWindowTitle("Gerar PDF")
        prog.setWindowModality(Qt.WindowModality.WindowModal)
        prog.setMinimumDuration(300)
        w = PdfWorker(out_exam, self.folder, ExamStore.logo_path(self.exam, self.folder), path, pages, self)
        w.progress.connect(lambda a, b: prog.setValue(a))
        w.done.connect(lambda warns, err, p=path, pr=prog: self._pdf_done(warns, err, p, pr))
        self.pdf_worker = w
        QApplication.setOverrideCursor(Qt.CursorShape.BusyCursor)
        w.start()

    def _pdf_done(self, warns: list, err: str, path: str, prog: QProgressDialog) -> None:
        QApplication.restoreOverrideCursor()
        prog.close()
        self.pdf_worker = None
        if err:
            QMessageBox.critical(self, "Gerar PDF", err)
            return
        self.s["pasta_pdfs"] = os.path.dirname(path)
        msg = f"PDF gerado: {os.path.basename(path)}"
        if warns:
            msg += " · " + " · ".join(warns)
        self.info(msg, warn=bool(warns), ms=12000)
        if self.s.get("abrir_pdf_apos_gerar", True):
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def print_exam(self) -> None:
        if not self._ready_for_output():
            return
        from PySide6.QtPrintSupport import QPrintDialog, QPrinter
        from ..render.output import print_pages
        n = compose.page_count(self.exam)
        printer = QPrinter(QPrinter.PrinterMode.HighResolution)
        if self.s.get("impressora"):
            printer.setPrinterName(self.s["impressora"])
        printer.setDocName(f"{self.exam.patient} {self.exam.date_br()}")
        printer.setFromTo(1, n)
        dlg = QPrintDialog(printer, self)
        dlg.setWindowTitle("Imprimir")
        dlg.setMinMax(1, n)
        dlg.setOption(QPrintDialog.PrintDialogOption.PrintPageRange, True)
        dlg.setOption(QPrintDialog.PrintDialogOption.PrintToFile, False)
        dlg.setOption(QPrintDialog.PrintDialogOption.PrintCollateCopies, False)
        if not dlg.exec():
            return
        if printer.printRange() == QPrinter.PrintRange.PageRange:
            a, b = printer.fromPage(), printer.toPage()
            pages = list(range(max(1, a) - 1, min(n, b)))
        else:
            pages = list(range(n))
        out_exam, pages = self._output_exam(pages)
        if not pages:
            return
        copies = max(1, printer.copyCount())
        QApplication.setOverrideCursor(Qt.CursorShape.BusyCursor)
        try:
            warns = print_pages(out_exam, self.provider, printer, pages, copies)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Imprimir", f"Falha na impressão: {e}")
            return
        QApplication.restoreOverrideCursor()
        self.info(f"Enviado para a impressora: {len(pages)} página(s) × {copies} cópia(s)"
                  + (" · " + " · ".join(warns) if warns else ""), warn=bool(warns), ms=12000)

    # ================================================================ configurações
    def open_settings(self) -> None:
        from .settings_dialog import SettingsDialog
        old_exams = self.s["pasta_exames"]
        old_cap = self.s["pasta_capturas"]
        dlg = SettingsDialog(self.s, self)
        if not dlg.exec():
            return
        if self.exam:
            r = QMessageBox.question(
                self, "Identidade visual",
                "Aplicar a nova identidade visual (logo, cabeçalho, rodapé, margens) também ao "
                "exame aberto?\n\nExames antigos não mudam: cada exame guarda a identidade com que foi feito.")
            if r == QMessageBox.StandardButton.Yes:
                try:
                    self.store().apply_identity(self.exam, self.folder, self.s.identity(), self.s.logo_file())
                except OSError as e:
                    QMessageBox.warning(self, "Identidade visual", str(e))
                self.provider.set_logo_path(ExamStore.logo_path(self.exam, self.folder))
                self._changed()
        if old_exams != self.s["pasta_exames"] and self.exam:
            self.info("A nova pasta de exames vale para os próximos exames. O exame aberto continua na pasta atual.")
        if old_cap != self.s["pasta_capturas"] and self.watcher is not None:
            self.stop_watch()
            self.start_watch(silent=False)

    # ================================================================ fechar
    def closeEvent(self, e):
        if not self.maybe_close_exam():
            e.ignore()
            return
        self.stop_watch()
        for w in list(self.importers):
            w.cancel()
            w.wait(3000)
        if self.pdf_worker is not None:
            self.pdf_worker.wait(30000)
        self._store_window()
        self.s.end_session()
        e.accept()
